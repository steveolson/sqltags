/* $Id: ClassMutator.java,v 1.9 2003/05/17 03:22:33 solson Exp $
 * $Log: ClassMutator.java,v $
 * Revision 1.9  2003/05/17 03:22:33  solson
 * Major rewrite to support replacement of ColumnProperties with SQLTagsColumns;
 * which now supports native DATE, TIME, TIMESTAMP, and NUMBER conversions
 * in Java and not in the database queries.
 *
 * Revision 1.8  2002/10/16 18:49:34  solson
 * whenever an explicit call to a mutator for a column is called, the ignoreArrayIndex
 * flag is set so that all subsequent "gets" on that column will return the set
 * value regardless of ArrayIndex.  This is to support processing of master-
 * detail forms where the FK column can be set on the child record (related to
 * the parent row) once for all child rows processed.
 *
 * Revision 1.7  2002/03/15 14:23:44  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.generator;
import java.util.Enumeration;
import java.util.logging.Logger;

/**
 * <code>ClassMutator</code>  
 * <p>  
 * This class is responsible for creating the class mutator methods.
 * </p>  
 * @param  <code>none</code>  
 * @return <code>none</code>
 */
public class ClassMutator{
    //***************************************************************************
    // Class Variables
    //***************************************************************************
    private static Logger log = Logger.getLogger("com.aitworks.sqltags.generator.ClassMutator");
    private StringBuffer buffer=new StringBuffer();;
    private HeaderDefinition header;
    private String spacer="   //---------------------------------------------------------------------------\n";
    private SQLTagsGeneratorTable sqlTagsGeneratorTable;
    
   //***************************************************************************  
   // Class Constructors  
   //***************************************************************************  
   /**  
    * <code>ClassMutator</code>  
    * <p>  
    * Class constructor. Responsible for controlling creation of the mutators.
    * </p>  
    * @param sqlTagsGeneratorTable<code>SQLTagsGeneratorTable</code>table data.
    */  
   //---------------------------------------------------------------------------
   public ClassMutator(SQLTagsGeneratorTable sqlTagsGeneratorTable){
      this.sqlTagsGeneratorTable=sqlTagsGeneratorTable;
      createClassMutator();
   }// ClassMutator() ENDS

   //***************************************************************************  
   // Public Methods  
   //***************************************************************************  
   /**  
    * <code>main</code>  
    * <p>  
    * This method is used for testing and stand-alone fuctionality.
    * </p>  
    * @param args <code>String[]</code> command line arguments.  
    * @return  <code>none</code>
    */  
   //---------------------------------------------------------------------------
   public static void main(String[] args){
       SQLTagsGeneratorTable sqlTagsGeneratorTable=new SQLTagsGeneratorTable();
       ClassMutator classMutator=new ClassMutator(sqlTagsGeneratorTable);
       System.out.println(classMutator.getClassMutator());
   }// main() ENDS

   /**  
    * <code>toString</code>  
    * <p>  
    * This method returns the state of the class variables.
    * </p>  
    * @param  <code>none</code>
    * @return  <code>none</code>
    */  
   public String toString(){
       StringBuffer buff=new StringBuffer("\n*****ClassMutator: ");
       buff.append("\tbuffer="+buffer.toString());
       buff.append("\theaderDefinition="+header);
       buff.append("\tsqlTagsGeneratorTable="+sqlTagsGeneratorTable);
       return buff.toString();
   }//toString() ENDS

   //***************************************************************************  
   // Friendly Methods  
   //***************************************************************************  
   /**  
    * <code>getClassMutator</code>  
    * <p> 
    * This method returns the mutator methods which were created.
    * </p>  
    * @param  <code>none/code>
    * @return  <code>none</code>
    */  
   String getClassMutator(){
       return buffer.toString();
   }//getClassMutator() ENDS

   //***************************************************************************  
   // Private Methods  
   //***************************************************************************  
   /**  
    * <code>createClassAccessor</code>  
    * <p>  
    * This method creates the accessor methods.
    * </p>  
    * @param  <code>none</code> 
    * @return  <code>none</code>
    */  
   //---------------------------------------------------------------------------
   private void createClassMutator(){
       Enumeration enum=sqlTagsGeneratorTable.getColumns();
       
       for(;enum.hasMoreElements();){
           String column=(String)enum.nextElement();
           buffer.append(createMethodHeader(column));
           buffer.append(spacer);
           buffer.append("   public void set"+column+"(String string){\n");
           buffer.append(spacer);
           buffer.append("      setString(\""+column+"\",string);\n");
           buffer.append("      // setColumnProperty(\"ignoreArrayIndex\",\""+column+"\",\"true\");\n");
           buffer.append("      return;\n");
           buffer.append("   }// set"+column+"() ENDS\n\n");
           
           // Special Methods for DATE, TIME, and TIMESTAMP datatypes
           SQLTagsGeneratorColumn c = sqlTagsGeneratorTable.getColumn(column);
           if(    c.getDataType().equalsIgnoreCase("DATE")
               || c.getDataType().equalsIgnoreCase("TIME")
               || c.getDataType().equalsIgnoreCase("TIMESTAMP")) {
               // OK, a DATE-DATA type, ... need all of those Extra Setters and Getters
               writeDateSetMethods(c.getColumnName(), c.getDataType() );
           }
       }
   }// createClassAccessor() ENDS

   /**  
    * <code>createMethodHeader</code>  
    * <p>  
    * This method creates the method header.
    * </p>  
    * @param  <code>none</code> 
    * @return  <code>none</code>
    */  
   //---------------------------------------------------------------------------
	private String createMethodHeader(String column){		
      header=new HeaderDefinition("SQLTags Generator","1.0","1.3",  
      "set"+column,  
      "This method is responsible for setting the value of the "+  
      column.toLowerCase()+" column.", 1);  
      header.createParameters("String","string","param",column.toLowerCase()+
         "'s new value.",1);  
      header.createParameters("","none","return","",1);  
      return header.getHeader();
	}// createMethodHeader() ENDS
        
        private void writeDateSetMethods(String columnName, String dataType) {
            // Write the Setters for DATE Columns ... ouch!
            writeDateSetMethod(columnName, dataType, "YYYY");
            writeDateSetMethod(columnName, dataType, "MM");
            writeDateSetMethod(columnName, dataType, "DD");
            writeDateSetMethod(columnName, dataType, "HH24");
            writeDateSetMethod(columnName, dataType, "HH");
            writeDateSetMethod(columnName, dataType, "MI");
            writeDateSetMethod(columnName, dataType, "SS");
            writeDateSetMethod(columnName, dataType, "MS");
            writeDateSetMethod(columnName, dataType, "AMPM");
        }
        private void writeDateSetMethod(String col, String dataType, String postFix){
            buffer.append("   public void set" + col+"_"+postFix+"(String string){\n");
            buffer.append("       setDateField(\""+col+"\",string,\""+postFix+"\");\n");
            buffer.append("   }\n");
        }
}//ClassMutator ENDS
