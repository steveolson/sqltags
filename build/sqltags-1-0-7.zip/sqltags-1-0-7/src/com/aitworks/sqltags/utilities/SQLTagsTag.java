/* $Id: SQLTagsTag.java,v 1.35 2003/11/13 03:36:27 solson Exp $
 * $Log: SQLTagsTag.java,v $
 * Revision 1.35  2003/11/13 03:36:27  solson
 * changed initializeHashTables from public to protected
 *
 * Revision 1.34  2003/11/12 20:30:03  solson
 * some cleanup on SQLTags (removed unused variables)
 * moved output from doFinally to doAfterBody ... should work ..
 * added bodyContent.clearBody() call to cleanup output for pooled tags
 *
 * Revision 1.33  2003/10/26 05:50:56  solson
 * changed call fo FK based on tableAlias not Id
 *
 * Revision 1.32  2003/10/01 16:03:09  solson
 * changes to logging for exceptions
 *
 * Revision 1.31  2003/06/18 17:58:50  solson
 * added check in doEndTag (or doFinally) to test for not null enclosingWriter() to fix bug
 * when bodyContent has no writer.
 *
 * Revision 1.30  2003/05/22 18:12:21  solson
 * updated logging
 *
 * Revision 1.29  2003/05/17 03:24:17  solson
 * Major rewrite to support replacement of ColumnProperties with SQLTagsColumns;
 * which now supports native DATE, TIME, TIMESTAMP, and NUMBER conversions
 * in Java and not in the database queries.
 *
 * Revision 1.28  2003/03/20 14:42:36  solson
 * changed signature of call to callFKMethod
 *
 * Revision 1.27  2003/02/24 08:15:15  solson
 * added support for TryCatchFinally Implementation
 *
 * Revision 1.26  2003/01/20 22:08:58  solson
 * upgraded tag methods to return newer values based on changes to JSP specs
 * AND ... added call to setBeanProperties() method from doStart()
 *
 * Revision 1.25  2002/11/11 20:31:27  jpoon
 * change ConnectionTag as parameters and class variable
 * to super class SQLTagsConnection
 *
 * Revision 1.24  2002/10/17 01:54:39  solson
 * added support for operation="loop" which allows a SQLTag Tag to loop
 * over the items submitted in an Array within the RequestObject
 *
 * Revision 1.23  2002/08/16 15:46:55  jpoon
 * make sure startRow is not null
 *
 * Revision 1.22  2002/08/07 15:13:10  jpoon
 * re-construct connection manager
 *
 * Revision 1.21  2002/07/24 19:16:49  jpoon
 * fix paging
 *
 * Revision 1.20  2002/07/17 19:23:58  solson
 * cleaned up the Handler calls.  Modified calls to the handler class and fixed
 * parameters to class ... changed parameter from "Object" to "SQLTags"
 *
 * Revision 1.19  2002/07/02 19:10:21  jpoon
 * change SQLTagsRequest to HttpServletRequest
 *
 * Revision 1.18  2002/06/27 13:34:06  jpoon
 * add setPaging(this.paging)
 * to make sure setPaging is called after setStartRowParameter
 *
 * Revision 1.17  2002/06/24 23:17:19  jpoon
 * remove sqlTagsHandler
 *
 * Revision 1.16  2002/05/23 15:51:11  solson
 * removed all references to caching implementation
 *
 * Revision 1.15  2002/04/10 17:36:52  booker
 * Modifed code to work with the binding of values
 * to the column properties object.
 *
 * Revision 1.14  2002/04/03 14:49:24  booker
 * Worked on adding Object to ColumnProperties.
 *
 * Revision 1.13  2002/03/15 14:33:31  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.utilities;
import com.aitworks.sqltags.jsptags.*;
import java.io.IOException;
import java.util.Enumeration;
import java.sql.Connection;
import javax.servlet.ServletRequest;
import javax.servlet.jsp.tagext.TryCatchFinally;
import javax.servlet.http.HttpServletRequest;
import java.util.logging.Logger;
/**
 * <code>SQLTagsTag</code>
 * <p>
 * This class handles the Jsp Tag Support for our SQLTagsTables.
 * </p>
 * @author Booker Northington II
 * @version 1.0
 * @since 1.3 */  
//------------------------------------------------------------------------------  
public abstract class SQLTagsTag 
        extends SQLTags 
        implements TryCatchFinally 
{
//------------------------------------------------------------------------------  
    private static Logger log = Logger.getLogger("com.aitworks.sqltags.utilities.SQLTagsTag");
    /** <code>doAfterBody</code>
     * <p>
     * This method is executed after the body has been evaluated. If SKIP_BODY
     * is returned or the tags body is empty, this method is not called. It is
     * invoked after the body has been evaluated and is initially invoked by
     * doStartTag.
     * </p>
     * @since 1.3
     * @return value <code>int</code> Indicates whether to continue evaluating
     *        the body. */
   //---------------------------------------------------------------------------
   public int doAfterBody(){
   //---------------------------------------------------------------------------
       log.fine("Entering doAfterBody: "+ getClass() );
      int returnCode=SKIP_BODY;
      if(getWhere().equals("")||isFetch()) {
          if( arrayIndexEnumeration==null || !arrayIndexEnumeration.hasMoreElements()){
              returnCode = SKIP_BODY;
              arrayIndexEnumeration = null;
              setLastRecord(true);
          }
          else {
              setArrayIndex( (String)arrayIndexEnumeration.nextElement() );
              returnCode= EVAL_BODY_AGAIN;
          }
      }
      else if(fetch())
         returnCode=EVAL_BODY_AGAIN;
      else
         setLastRecord(true);
      if(!getSQLTagsHandler().afterBody(this)) {
          setLastRecord(true);
          close();
          returnCode=SKIP_BODY;
      }
       try{
           // if( bodyContent!=null && getPreviousOut()!=null)
           if( bodyContent!=null )
           {
               bodyContent.writeOut(getPreviousOut());
               bodyContent.clearBody();
           }
       }
       catch(IOException exception){
           log.severe(getTableName()+".doAfterBody(): "+exception+", CAUSE: " + exception.getCause() );
       }
      return returnCode;
   }// doAfterBody() ENDS

   /** <code>doStartTag</code>
    * <p>
    * This method is called when the start tag of the jsp is encountered.  We
    * make the assumptin that all of your mutators have been set prior to entering
    * this method. The body of the tag has not been processed you this method
    * is invoked.
    * </p>
    * @since 1.3
    * @return value <code>int</code> Indicates whether to prosses the body. */
   //---------------------------------------------------------------------------
   public int doStartTag(){ 
   //---------------------------------------------------------------------------
       log.fine("Entering doStartTag: "+ getClass() );
       int returnCode=SKIP_BODY;
       // int returnCode=EVAL_BODY_BUFFERED;
       
       Object bean = pageContext.findAttribute( getId() );
       if( bean != null && bean instanceof SQLTags) {
           log.info("found bean attribute, done.");
           // OK, got a Bean ... let's use it and skip all this nonsense.
           setBeanProperties( bean );
           return EVAL_BODY_BUFFERED;
       }
       
       pageContext.setAttribute(getId(),this);
      /*
      //sqlTagRequest=new SQLTagsRequest(pageContext);
      sqlTagRequest=(HttpServletRequest)pageContext.getRequest();
      sqlTagHandler=getSQLTagsHandler();
       */
       if(getPaging().equalsIgnoreCase("true")){
           setStartRow(Utilities.nvl((String)pageContext.getRequest().getParameter(getStartRowParameter()), "0"));
       }
       else {
           setPageSize("0");
       }
       sqlTagsConnection=(SQLTagsConnection)findAncestorWithClass(this,ConnectionTag.class);
       if( sqlTagsConnection == null ) {
           //connectionValid=false;
           log.warning("doStartTag:"+getClass()+":no database connection available");
           returnCode=SKIP_BODY;
       }
       
       // setColumnTypes();
       setFirstRecord(true);
       setLastRecord(false);
       
       if(getProperties().toLowerCase().equals("true")) {
           setRequestProperties();
       }
       
       if(!getParentName().equals("")&&!getForeignKey().equals("")){
           Object sqlTag=null;
           sqlTag=(Object)pageContext.getAttribute(getParentName() );
           Utilities util = new Utilities(); 
           setWhere(util.callFKWhere(sqlTag,getForeignKey(),getTableAlias())+" "+getWhere());
       }
       if( !getSQLTagsHandler().start(this) ) {
           return SKIP_BODY;
       }
       
       if(! doArrayOperations()) {
           log.warning("doStart:doArrayOperations failed, returning.");
           // sqlTagHandler.onError(this);
           return EVAL_BODY_BUFFERED;
       }
       
       // Is there any reason not to do this???
       setArrayIndex("0");
       
       if(getWhere().equals("")) {
           // arrayIndexEnumeration is set by doArrayOperations
           if( arrayIndexEnumeration == null ) {
               returnCode=EVAL_BODY_BUFFERED;
           } else {
               if( arrayIndexEnumeration.hasMoreElements() ) {
                   setArrayIndex(  (String)arrayIndexEnumeration.nextElement() );
                   returnCode=EVAL_BODY_BUFFERED;
               } else {
                   log.info("doStart: empty arrayEnumeration, done.");
                   arrayIndexEnumeration = null;
                   setLastRecord(true);
                   returnCode=SKIP_BODY;
               }
           }
       }
       else if(!select(getWhere())) {
           log.finer("failed using where: " +getWhere() + ": skipping body");
           returnCode=SKIP_BODY;
       }
       else if(fetch()) {
           returnCode=EVAL_BODY_BUFFERED;
       }
       log.finer("doStartTag done: " + returnCode);
       return returnCode;
   }// doStartTag() ENDS

   /** <code>doEndTag</code>
    * <p>
    * This method is called when the end tag is encountered. Any post processing
    * can be acomplished here.
    * </p>
    * @since 1.3
    * @return value <code>int</code> flag indicating your done. */
   //---------------------------------------------------------------------------
   public int doEndTag(){
   //---------------------------------------------------------------------------
       log.fine("Entering doEndTag: "+ getClass() );
       int returnCode=SKIP_BODY;
       getSQLTagsHandler().end(this);
       returnCode=EVAL_PAGE;
       return returnCode;
       
   }// doEndTag() ENDS
      
   /** <code>doCatch</code>
    * <p>
    * This method is called when an exception is encountered within the TAG context
    * </p>
    * @since 1.3
    * @return void
    */
   //---------------------------------------------------------------------------
   public void doCatch(Throwable t) throws Throwable {
   //---------------------------------------------------------------------------
       Exception e = new Exception (t);
       setException(e);
       log.warning("doCatch:"+getClass()+":"+e+ ", CAUSE: " + e.getCause());
       
       // would prefer to send this to the logger ... but how??
       e.printStackTrace( System.out );
       // throw e;
   }
      
   /** <code>doFinally</code>
    * <p>
    * This method is called after the TAG context (exception or not) should be
    * after the doEnd() method ... 
    * </p>
    * @return void
    */
   //---------------------------------------------------------------------------
   public void doFinally() {
   //---------------------------------------------------------------------------
       log.finest("Entering doFinally: "+ getClass() );
       /*
       try{
           // if(!connectionValid)
           //     connectionValid=true;
           // else 
           if(bodyContent!=null && bodyContent.getEnclosingWriter()!=null){
               bodyContent.writeOut(bodyContent.getEnclosingWriter());
           }
       }
       catch(IOException exception){
           log.severe(getTableName()+".doEndTag(): "+exception+", CAUSE: " + exception.getCause() );
       }
       */
       pageContext.removeAttribute(getId());
       init();
       return;
   }
   
   public void release(){
       log.finer("releaseTag: "+ getClass() );
       super.release();
   }
   
}//SQLTagsTag() ENDS
