/* $Id: SQLTagsConnection.java,v 1.11 2003/11/21 20:29:50 solson Exp $
 * $Log: SQLTagsConnection.java,v $
 * Revision 1.11  2003/11/21 20:29:50  solson
 * added setException, implementation for iExceptionHandler
 * also modified when getConnectionDS is called ... not only when useCM is true
 * but also if a dataSource attribute has be explicitly set on the tag
 *
 * Revision 1.10  2003/09/26 18:54:33  solson
 * Added dataSource property (and attribute to Tag) to choose DataSource for
 * each connection tag.  Also, did a little cleanup in the getDSConnection Method
 *
 * Revision 1.9  2003/09/25 11:32:31  solson
 * changed log level of nested log messages from INFO to FINE
 *
 * Revision 1.8  2003/09/25 11:29:16  solson
 * limited connections to 1 per request so nested pages use same connection as
 * outer page.  uses a REQUEST_SCOPE'd attribute to accomplish this based on
 * the connection's ID; therefore, for this to work the connections in each page need
 * to use the same connection ID name  ... id="con" ... for example.
 *
 * Revision 1.7  2003/09/24 14:45:39  solson
 * some minor tweaks for more accurate logging
 *
 * Revision 1.6  2003/09/24 13:52:07  solson
 * added support for DataSource in lieu of ConnectionManager.  Added new properties:
 * SQLTags.dataSource - name of DataSource, defaults to: jdbc/SQLTagsDS
 * SQLTags.useCM - use ConnectionManager, defaults to "true" (the existence of a
 * SQLTags.dataSource property changes the default to "false")
 * Also, cleaned up the code a bit.
 *
 * Revision 1.5  2003/06/09 21:28:12  solson
 * added java.util.logging support and removed reference to exceptionString
 *
 * Revision 1.4  2002/09/23 15:59:56  jpoon
 * in finalize, if connection is not null, do a roll back
 *
 * Revision 1.3  2002/09/04 18:36:15  jpoon
 * fix connection bug/clean up
 *
 * Revision 1.2  2002/08/19 20:21:44  jpoon
 * fix bug for setters
 *
 * Revision 1.1  2002/08/16 15:44:54  jpoon
 * new class for connection
 *
 * Revision 1.17  2002/08/13 17:57:17  jpoon
 * fix bug on getConnection()
 *
 * Revision 1.16  2002/08/12 16:47:39  jpoon
 * remove getTagConnection
 *
 * Revision 1.15  2002/08/07 15:13:11  jpoon
 * re-construct connection manager
 *
 * Revision 1.14  2002/06/20 21:00:49  jpoon
 * fix init id and name
 *
 * Revision 1.13  2002/04/06 18:04:52  booker
 * No exception is thrown in setAutoCommit(). Removed
 * Threw Exception in setReadOnly.
 * Modified structure of doStartTag.
 *
 * Revision 1.12  2002/04/05 01:09:53  solson
 * Added commit to doEnd when autoCommit is false to make sure stuff is
 * committed before releasing the connection.  Also pulled in the
 * connectionManager's exception on failure.
 *
 * Revision 1.11  2002/04/03 19:22:05  solson
 * small fix to setAutoCommit(bool) ... set class variable because JSP is calling
 * the boolean method (not the string) one.
 *
 * Revision 1.10  2002/03/20 12:37:21  booker
 * code cleanup.
 *
 * Revision 1.9  2002/03/15 14:27:59  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.utilities;  
import javax.servlet.jsp.JspException;  
import javax.servlet.jsp.PageContext;  
import javax.servlet.jsp.tagext.BodyContent;  
import javax.servlet.jsp.tagext.BodyTagSupport;  
import javax.servlet.http.*;  
import javax.servlet.*;  
import javax.naming.*;
import java.sql.*;  
import javax.sql.*;
import java.util.*;  
import java.io.*;  
import java.util.logging.Logger;
  
/**  
 * <code>SQLTagsConnection</code>  
 * <p>  
 * This class is used to establish a connection to the database.  
 * </p>  
 * @author  Booker Northington II  
 * @version 1.0       
 * @since   1.3        
 * @param none <code>none</code> none.  
 * @see TagSupport <code>TagSupport</code> For more information.  
 * @return none <code>none</code> none.  
 */  
//---------------------------------------------------------------------------  
public class SQLTagsConnection extends Initialize{
//---------------------------------------------------------------------------  
   //**************************************************************************  
   // Class Variables   
   //**************************************************************************  
   private static final Logger log = Logger.getLogger("com.aitworks.sqltags.utilities.SQLTagsConnection");
   protected boolean              autoCommit=true;  
   protected Connection           connection;  
   protected String               name="";  
   protected boolean              readOnly=false;  
   private boolean                useCM=true;
   private boolean                isNestedConnection=false;
   private String dataSource=null;
   private Exception              exception; 
   //**************************************************************************  
   // Constructors   
   //**************************************************************************  
   /**  
    * <code>SQLTagsConnection</code>  
    * <p>  
    * This constructor is responsible for returning an instance of the class.  
    * </p>  
    * @param none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public SQLTagsConnection(){  
   //---------------------------------------------------------------------------  
   }// SQLTagsConnection Constructor() ENDS  
  
   //---------------------------------------------------------------------------  
   public SQLTagsConnection(String initSrc){  
   //---------------------------------------------------------------------------  
       this.initSrc=initSrc;
       init();
   }// SQLTagsConnection Constructor() ENDS  
   
   //**************************************************************************  
   // Finalize Method  
   //**************************************************************************  
   /**  
    * <code>finalize</code>  
    * <p>  
    * This method is called when the object is destroyed.  
    * </p>  
    * @since   1.3  
    * @param <code>none</code>  
    */  
   //---------------------------------------------------------------------------  
   protected void finalize() throws Throwable{  
   //--------------------------------------------------------------------------- 
       try {
           if(connection!=null) {
               if(!connection.isClosed()) {
                   connection.rollback();
               }
               close();
           }
      }
      catch(SQLException exception) {
          log.warning("SQLTagsConnection.finalize: Cannot rollback/close Connection: "+exception);
          setException(exception);
      }
      super.finalize();
   }//finalize() ENDS  
  
   //**************************************************************************  
   // Public Methods  
   //**************************************************************************  
   /**
    * <code>getConnection</code>  
    * <p>  
    * This method returns the connection for this tag.  
    * </p>  
    * @param none <code>none</code> none.  
    * @return connection <code>Connection</code> The connection for this   
    *        tag.  
    */  
   //---------------------------------------------------------------------------  
   public Connection getConnection(){  
   //---------------------------------------------------------------------------  
       try {
           if(connection!=null && !connection.isClosed()) {
               // OPEN Connection & not null, return it!
               return connection;
           }
           if(connection!=null && connection.isClosed()) {
               // CLOSED Connection, kill it and start over ...
               close(); // close will set connection to null
           }
           //
           // Only 1 Connection per Request ... 
           //
           Object o = pageContext.getAttribute(getId(), pageContext.REQUEST_SCOPE);
           if( o instanceof SQLTagsConnection && o != this) {
               SQLTagsConnection c = (SQLTagsConnection)o;
               log.fine("SQLTagsConnection:getConnection():Nested Connection");
               isNestedConnection=true;
               return c.getConnection();
           }
           if(useCM && getDataSource()==null) {
               log.fine("getConnection():Using CM Connection" );
               connection=ConnectionManager.getConnection(initializationProperties);
           } else {
               log.fine("getConnection():Using DS Connection" );
               connection=getDSConnection(initializationProperties);
           }
       }
       catch (Exception exception) {
           setException(exception);
           log.severe("SQLTagsConnection: getConnection(): " + exception);
           // exception.printStackTrace();
           return null;
       }
       pageContext.setAttribute(getId(), this, pageContext.REQUEST_SCOPE);
       return connection;
   }// getConnection() ENDS  
   
   public Connection getDSConnection(Properties iProp) throws Exception {
       Context ctx = null;
       try {
           ctx = new InitialContext();
       } catch (NamingException ne) {
           setException(ne);
           log.severe("getDSConnection: no InitialContext: " + ne);
           throw new Exception(ne);
       }
       
       if(ctx == null ) {
           Exception exception = new Exception("SQLTagsConnection: getDatasourceConnection: no initialContext"); 
           setException(exception);
           throw exception;
       }
       
       String sqltagsDS = getDataSource();
       if(sqltagsDS==null) {
           sqltagsDS = iProp.getProperty("SQLTags.dataSource","jdbc/SQLTagsDS");
       }
       log.fine("DataSource = " + sqltagsDS );
       DataSource ds = (DataSource)ctx.lookup("java:comp/env/" + sqltagsDS);
       
       if(ds==null) {
           Exception exception = new Exception("SQLTagsConnection: getDSConnection() no DataSource");
           setException(exception);
           throw exception;
       }
       
       return ds.getConnection();
   }

   /**  
    * <code>close</code>  
    * <p>  
    * This method is called to close the connection and give it back to the pool
    * </p>  
    * @param none <code>none</code> none.  
    * @return value <code>boolean</code> true means success, false means failure  
    */  
   //---------------------------------------------------------------------------
   public boolean close(){
   //---------------------------------------------------------------------------
       if(isNestedConnection){
           // We didn't open it, we don't close it!
           log.fine("SQLTagsConnection:close():nested connected, ignored.");
           connection=null;
           return true;
       }
       
       if(!getAutoCommit()){
           try {
               commit();
           }
           catch (SQLException e) {
               setException(e);
               log.warning("SQLTagsConnection.doEndTag: SQLException: "+e);
           }
       }
       
       try {
           if(useCM) {
               ConnectionManager.releaseConnection(connection);
           } else {
               if(connection!=null) {
                   connection.close();
               }
           }
           connection=null;
       }
       catch(SQLException exception) {
           setException(exception);
           log.warning("SQLTagsConnection.doEndTag: Cannot release Connection: "+exception);
           return false;
       }
       
       return true;
   }// doEndTag() ENDS  
  
   /**  
    * <code>setReadOnly</code>  
    * <p>  
    * This method sets the state of the auto-commit flag.  
    * </p>  
    * @param state <code>String</code> true, if auto-commit is on.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setReadOnly(String string){  
   //---------------------------------------------------------------------------  
       try {
           if(string.toLowerCase().equals("true"))
               setReadOnly(true);
           else
               setReadOnly(false);
       }
       
       catch (SQLException exception) {
           setException(exception);
           log.warning("SQLTagsConnection.setReadOnly: "+exception);
       }
   }//setReadOnly() ENDS  

   /**  
    * <code>setAutoCommit</code>  
    * <p>  
    * This method sets the current value of auto-commit.  
    * </p>  
    * @param state <code>boolean</code> The new auto-commit state.  
    * @throws exception <code>SQLException</code> Throws an SQLException   
    *        if something gose wrong.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setReadOnly(boolean bool)throws SQLException{  
   //---------------------------------------------------------------------------  
       readOnly=bool;
   }//setAutoCommit() ENDS  
   
   /**  
    * <code>getReadOnly</code>  
    * <p>  
    * This method returns the value of the auto commit flag.  
    * </p>  
    * @none none <code>none</code> none.  
    * @return readOnly <code>boolean</code> true, if auto-commit is on.  
    */  
   //---------------------------------------------------------------------------  
   public boolean getReadOnly(){  
   //---------------------------------------------------------------------------  
      return readOnly;  
   }//getReadOnly() ENDS  
  
   /**  
    * <code>setReadOnly</code>  
    * <p>  
    * This method uses the connection to set the auto-commit state.  
    * </p>  
    * @param none <code>none</code> none.  
    * @throws exception <code>SQLException</code> Throws an SQLException   
    *        if something gose wrong.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   protected void setReadOnly()throws SQLException{  
   //---------------------------------------------------------------------------  
        if(connection!=null)
            connection.setReadOnly(readOnly);  
        else {
            SQLException e = new SQLException("SQLTagsConnection.setReadOnly: connection null");
            setException(e);
            throw e;
        }
   }//setReadOnly() ENDS  
  
   /**  
    * <code>setAutoCommit</code>  
    * <p>  
    * This method sets the state of the auto-commit flag.  
    * </p>  
    * @param state <code>String</code> The new state of the auto-commit   
    *        flag.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setAutoCommit(String string){  
   //---------------------------------------------------------------------------  
       try {
           if(string.toLowerCase().equals("true"))
               setAutoCommit(true);
           else
               setAutoCommit(false);
       }
       
       catch (SQLException exception) {
           setException(exception);
           log.warning("SQLTagsConnection.setAutoCommit: "+exception);
       }
   }//setAutoCommit() ENDS  
  
   /**  
    * <code>setAutoCommit</code>  
    * <p>  
    * This method uses the connection to set the auto-commit state.  
    * </p>  
    * @param none <code>none</code> none.  
    * @throws exception <code>SQLException</code> Throws an SQLException   
    *        if something gose wrong.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   protected void setAutoCommit()throws SQLException{  
   //--------------------------------------------------------------------------- 
       if(connection!=null)
           connection.setAutoCommit(autoCommit);
       else {
           SQLException e = new SQLException("SQLTagsConnection.setAutoCommit: connection null");
           setException(e);
           throw e;
       }
   }//setAutoCommit() ENDS     
   
   /**  
    * <code>setAutoCommit</code>  
    * <p>  
    * This method sets the current value of auto-commit.  
    * </p>  
    * @param state <code>boolean</code> The new auto-commit state.  
    * @throws exception <code>SQLException</code> Throws an SQLException   
    *        if something gose wrong.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setAutoCommit(boolean bool)throws SQLException{  
   //---------------------------------------------------------------------------  
       autoCommit=bool;
   }//setAutoCommit() ENDS  
  
   /**  
    * <code>getAutoCommit</code>  
    * <p>  
    * This method returns the current state of auto commit.  
    * </p>  
    * @param none <code>none</code> none.  
    * @return autoCommit <code>boolean</code> true, if auto commit is on.  
    */  
   //---------------------------------------------------------------------------  
   public boolean getAutoCommit(){  
   //---------------------------------------------------------------------------  
      return autoCommit;  
   }//getAutoCommit() ENDS  
  
   /**  
    * <code>init</code>  called to prepare settings
    * @param none <code>none</code> none.  
    * @return value <code>int</code> Indicates whether to prosses the body.  
    */  
   //---------------------------------------------------------------------------  
   public void init() {  
   //---------------------------------------------------------------------------
       try {
           setInitializationProperties();
           
           // Ok, checking to see which connection source we use ...
           // ConnectionManager or DataSource ...
           
           String defaultCM="true";  // overall default, for backward compat
           if( initializationProperties.getProperty("SQLTags.dataSource") !=null) {
               defaultCM="false";
               // change default to false if we have a DataSource
           }
           
           // If we have an actual useCM property, that always wins!
           if( initializationProperties.getProperty("SQLTags.useCM",defaultCM).equalsIgnoreCase("true")) {
               useCM=true;
           } else {
               useCM=false;
           }
       }
       catch(JspException exception) {
           setException(exception);
           log.warning("SQLTagsConnection:init(): " + exception);
       }
   }// init() ENDS  
   
   /**  
    * <code>commit</code>  
    * <p>  
    * This method commits a record to the database.  
    * </p>  
    * @param none <code>none</code> none.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void commit()throws SQLException{  
   //---------------------------------------------------------------------------  
       if(connection!=null)
           connection.commit();
       else {
           SQLException e = new SQLException("SQLTagsConnection.commit: connection null");
           setException(e);
           throw e;
       }
   }//commit() ENDS  
  
   /**  
    * The <b>getName</b>  
    * PCM-1  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public String getName(){  
   //---------------------------------------------------------------------------  
      return name;  
   }// getName() ENDS  
  
  
   /**  
    * <code>rollback</code>  
    * <p>  
    * This method generates a database rollback.  
    * </p>  
    * @param none <code>none</code> none.  
    * @return none <code>none</code> none.  
    * @throws SQLException <code>SQLException</code> Generates an SQLException   
    *        if something gose wrong.  
    */  
   //---------------------------------------------------------------------------  
   public void rollback()throws SQLException{  
   //---------------------------------------------------------------------------  
       if(connection!=null)
           connection.rollback();
       else {
           SQLException e = new SQLException("SQLTagsConnection.rollback: connection null");
           setException(e);
           throw e;
       }
   }//rollback() ENDS  
  
   /**  
    * The <b>setName</b>  
    * PCM-1  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public void setName(String string){  
   //---------------------------------------------------------------------------
      name=string.trim();  
      setInitId(name);// compat w/ InitializeTag!
   }// setName() ENDS
   
   /**  
    * <code>toString</code>  
    * <p>  
    * This method provides a default print for the class.  
    * </p>  
    * @param <code>none</code>  
    */  
   //---------------------------------------------------------------------------  
   public String toString(){  
   //---------------------------------------------------------------------------  
      StringBuffer buffer=new StringBuffer("\n*****SQLTagsConnection: ");  
      buffer.append("\tid="+id);  
      buffer.append("\tautoCommit="+autoCommit);  
      //buffer.append("\tconnected+="+connected);  
      buffer.append("\tconnection+="+connection);   
      buffer.append("\tinitializationProperties="+initializationProperties);  
      buffer.append("\tinitSrc="+initSrc);  
      buffer.append("\tname="+name);  
      buffer.append("\treadOnly="+readOnly);  
      return buffer.toString();  
   }
   
   /** Getter for property dataSource.
    * @return Value of property dataSource.
    *
    */
   public String getDataSource() {
       return this.dataSource;
   }
   
   /** Setter for property dataSource.
    * @param dataSource New value of property dataSource.
    *
    */
   public void setDataSource(String dataSource) {
       this.dataSource = dataSource;
   }
   
   /**  
    * <code>getException</code>  
    * <p>  
    * This method gets the encountered exception for later retrival.  
    * </p>  
    * @param none  
    * @return Exception.  
    */  
   //---------------------------------------------------------------------------  
   public Exception getException(){  
   //---------------------------------------------------------------------------  
      return this.exception;
   }// setException() ENDS  
   /**  
    * <code>setException</code>  
    * <p>  
    * This method sets the encountered exception for later retrival.  
    * </p>  
    * @param exception <code>Exception</code> The exception generated.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setException(Exception exception){  
   //---------------------------------------------------------------------------  
      this.exception=exception;  
      log.warning("setException:"+this.getClass()+": " +exception+", CAUSE: " + exception.getCause());
   }// setException() ENDS  
     
   /**  
    * <code>setExceptionString</code>  
    * <p>  
    * This method creates a user defined exception and sets it as the current  
    * exception.  
    * </p>  
    * @param message <code>String</code> The exception message.  
    * @return true <code>boolean</code> true if exception successfully set.  
    */  
   //---------------------------------------------------------------------------  
   public boolean setExceptionString(String message){  
      boolean returnValue=true;  
        
      try{  
         Exception exception=new Exception(message);  
         setException(exception);  
      }  
      catch(Exception exception){  
         returnValue=false;  
      }  
        
      return returnValue;  
   }// setException() ENDS  
   
   
}// SQLTagsConnection() ENDS  