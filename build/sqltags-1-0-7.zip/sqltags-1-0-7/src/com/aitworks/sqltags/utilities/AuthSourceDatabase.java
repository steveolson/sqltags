/*
 * AuthSourceDatabase.java
 *
 * Created on June 19, 2002, 11:24 AM
 */

package com.aitworks.sqltags.utilities;
import com.aitworks.sqltags.interfaces.*;
import java.util.*;
import java.sql.*;
import javax.servlet.jsp.*;

/**
 *
 * @author  jpoon
 */
public abstract class AuthSourceDatabase implements AuthSource {
    
    /** Creates a new instance of AuthSourceDatabase */
    public AuthSourceDatabase() {
    }

    /**
     * This method returns the authentication method
     * @author  John Poon
     * @param none.
     * @version 1.0
     * @return  The authentication method
     * @since   JDK1.3
     */
    public String getAuthSource() {
        return AUTH_SOURCE;
    }
    
    /**
     * This method returns the authentication method
     * @author  John Poon
     * @param none.
     * @version 1.0
     * @return  The authentication method
     * @since   JDK1.3
     */
    public boolean changePassword(String remoteUser, String oldPassword, String newPassword) {
        return true;                    
    }
    
    /**
     * This method returns the authentication method
     * @author  John Poon
     * @param none.
     * @version 1.0
     * @return  The authentication method
     * @since   JDK1.3
     */
    public String getError() {
        return this.error;
    }

   /**  
    * This method sets the authentication method
    * @author  John Poon
    * @param (String) authentication method.  
    * @version 1.0  
    * @return  None
    * @since   JDK1.3  
    */  
   //-------------------------------------------------------------------------  
   public void setSQLTagsConnection(SQLTagsConnection sqlTagsConnection) { 
   //-------------------------------------------------------------------------  
       this.sqlTagsConnection=sqlTagsConnection;
   }
 
    /**
     * This method returns the authentication method
     * @author  John Poon
     * @param none.
     * @version 1.0
     * @return  The authentication method
     * @since   JDK1.3
     */
    protected void setError(String error) {
        this.error=error;
    }
    
    /**
     * This method sets the properties
     * @author  John Poon
     * @param (String) authentication method.
     * @version 1.0
     * @return  None
     * @since   JDK1.3
     */
    public void setProperties(Properties properties) {
        this.properties=properties;
    }
    
    /**
     * This method returns the authentication method
     * @author  John Poon
     * @param none.
     * @version 1.0
     * @return  The authentication method
     * @since   JDK1.3
     */
    public int getDaysToExpire() {
       return 0;
    }
    
    /**
     * This method Authorize the remote user
     * @author  John Poon
     * @param none.
     * @version 1.0
     * @return  (boolean) The result
     * @since   JDK1.3
     */
    public String validate(String remoteUser, String password) {
       return AuthSource.AUTHORIZED;          
    }
    
    /** Holds value of property pageContext. */
    private final static String     AUTH_SOURCE="DATABASE";
    protected SQLTagsConnection       sqlTagsConnection=null;
    private String                  error="";
    private Properties              properties=null;
    
}
