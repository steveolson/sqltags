/* $Id: AllowTag.java,v 1.3 2003/02/23 21:48:52 solson Exp $
 * $Log: AllowTag.java,v $
 * Revision 1.3  2003/02/23 21:48:52  solson
 * added doEnd method to force output ...
 *
 * Revision 1.2  2003/02/23 21:15:09  solson
 * fixed CVS keywords ...
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 */
package com.aitworks.sqltags.jsptags;
import com.aitworks.sqltags.utilities.SQLTags;  
import java.io.IOException;
import javax.servlet.jsp.JspWriter;  
import javax.servlet.jsp.tagext.BodyContent;  
import javax.servlet.jsp.tagext.BodyTagSupport;
import java.util.StringTokenizer;

/**
 * <code>AllowTag</code>
 * <p>
 * This class creates a tag which talks to the jsp. It is used to restrict access
 * to portions of a page based on AuthorizeTag's hasPriv's ...
 * </p>
 * @author Steve Olson
 * @see BodyTagSupport <code>BodyTagSupport</code> For more information.
 */  
public class AllowTag extends BodyTagSupport{
    
    /** Holds value of property name. */
    private String name;
    
    /** Holds value of property tokens. */
    private String tokens;
    
   //---------------------------------------------------------------------------
   public int doStartTag(){
   //---------------------------------------------------------------------------
      AuthorizeTag parent=(AuthorizeTag)pageContext.getAttribute(getName());
      if(parent==null) {
          return SKIP_BODY;
      }
      
      StringTokenizer tok = new StringTokenizer( getTokens(), " ,");
      while( tok.hasMoreElements() ) {
          if( parent.hasPermission( (String)tok.nextElement() ) ) {
              return EVAL_BODY_BUFFERED;
          }
      }
      return SKIP_BODY;
   }
   //---------------------------------------------------------------------------
   public int doEndTag(){
   //---------------------------------------------------------------------------
       int returnCode=SKIP_BODY;
       try{
           if(bodyContent!=null){
               bodyContent.writeOut(bodyContent.getEnclosingWriter());
           }
       }
       catch(IOException exception){
           ;
       }
       returnCode=EVAL_PAGE;
       return returnCode;
       
   }// doEndTag() ENDS   
   /** Getter for property name.
    * @return Value of property name.
    *
    */
   public String getName() {
       return this.name;
   }
   
   /** Setter for property name.
    * @param name New value of property name.
    *
    */
   public void setName(String name) {
       this.name = name;
   }
   
   /** Getter for property tokens.
    * @return Value of property tokens.
    *
    */
   public String getTokens() {
       return this.tokens;
   }
   
   /** Setter for property tokens.
    * @param tokens New value of property tokens.
    *
    */
   public void setTokens(String tokens) {
       this.tokens = tokens;
   }
   
// doStartTag() ENDS  
}
