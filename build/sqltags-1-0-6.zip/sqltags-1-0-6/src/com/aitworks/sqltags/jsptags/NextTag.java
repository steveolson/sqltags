/* $Id: NextTag.java,v 1.20 2003/05/30 01:54:25 solson Exp $
 * $Log: NextTag.java,v $
 * Revision 1.20  2003/05/30 01:54:25  solson
 * added setId()
 *
 * Revision 1.19  2003/05/21 20:54:17  solson
 * needs extraInfo, so added back the setAttribute(getId()) ... :)
 *
 * Revision 1.18  2003/05/19 14:49:56  jpoon
 * no message
 *
 * Revision 1.17  2003/05/17 03:20:55  solson
 * fixed bug with getId() ... NPE due to jsp 1.2 has built-in getId() in super class
 *
 * Revision 1.16  2003/05/06 18:48:27  jpoon
 * add id to url
 *
 * Revision 1.15  2003/03/26 19:26:08  jpoon
 * fix more bugs and add paging to cursor tag
 *
 * Revision 1.14  2003/03/26 18:16:26  jpoon
 * more changing
 *
 * Revision 1.12  2003/03/20 14:18:12  jpoon
 * added target
 *
 * Revision 1.11  2003/03/04 19:51:58  jpoon
 * added display which could be use as display of link instead of using body content
 *
 * Revision 1.10  2003/03/04 19:26:26  jpoon
 * updated next and prev tag. add attribute showLink
 *
 * Revision 1.9  2003/01/20 22:10:42  solson
 * updated return codes from tag methods based on updated JSP specs.
 *
 * Revision 1.8  2002/07/24 19:16:48  jpoon
 * fix paging
 *
 * Revision 1.7  2002/07/17 19:23:58  solson
 * cleaned up the Handler calls.  Modified calls to the handler class and fixed
 * parameters to class ... changed parameter from "Object" to "SQLTags"
 *
 * Revision 1.6  2002/06/25 16:05:53  jpoon
 * fix paging code
 *
 * Revision 1.5  2002/05/23 20:30:26  solson
 * formatting fixes, removed incorrect handler references in first,last,next,
 * previous, etc.
 *
 * Revision 1.4  2002/05/23 15:50:26  solson
 * removed all references to caching implementation
 *
 * Revision 1.3  2002/03/15 14:27:59  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.jsptags;  
import com.aitworks.sqltags.utilities.Utilities;  
import com.aitworks.sqltags.utilities.SQLTags;  
import com.aitworks.sqltags.utilities.SQLTagsHandler;  
import java.io.IOException;  
import java.sql.SQLException;  
import java.util.Calendar;  
import javax.servlet.jsp.JspWriter;  
import javax.servlet.jsp.tagext.BodyContent;  
import javax.servlet.jsp.tagext.BodyTagSupport;  
import java.util.logging.Logger;
  
/**  
 * The <b>NextTag</b> class displays a link which references  
 * the next page within a set of pages.  
 * @param   none  
 * @return    
 */  
//---------------------------------------------------------------------------  
final public class NextTag extends BodyTagSupport{  
    //***************************************************************************
    //                      Class variable section
    //***************************************************************************
    private static Logger log = Logger.getLogger("com.aitworks.sqltags.jsptags.NextTag");
    private BodyContent  body;
    private boolean      hasNextLink=true;
    private String       href="";
    private String       id="next";
    private StringBuffer nextLink=new StringBuffer();
    private SQLTags      parent=null;
    private String       parentName="";
    private String       showLink="true";
    private String       target="";
    private String       display="";
   //***************************************************************************  
   //                      Constructor section  
   //***************************************************************************  
   /**  
    * The <b>NextTag</b> class constructor.  
    * PCM-1  
    * @param   none  
    * @return    
    */  
   //---------------------------------------------------------------------------  
   public NextTag(){  
   //---------------------------------------------------------------------------  
   }//Constructor ENDS()  
   //***************************************************************************  
   //                      Class method section  
   //***************************************************************************  
   /**  
    * The <b>doAfterBody</b> method is called after the body of the  
    * tag has been processed.  
    * PCM-3  
    * @see     BodyTagSupport  
    * @return  none  
    * @since   JDK1.3  
    */  
   //---------------------------------------------------------------------------  
   public int doAfterBody(){  
   //---------------------------------------------------------------------------  
      log.fine("doAfterBody:"+getClass());
      body=bodyContent;
      return SKIP_BODY;  
   }// doAfterBody() ENDS  
  
   /**  
    * This <b>doEndTag</b> is called when the end tag is hit.  
    * @param   none  
    * @return  The loop status.  
    */  
   //---------------------------------------------------------------------------  
   public int doEndTag(){  
   //---------------------------------------------------------------------------  
      log.fine("doEndTag:"+getClass());
       if(body!=null){
           String next=body.getString();
           if(next.trim().length()==0)
               next="Next";
           if(isNextLink()) {
               if(showLink.equals("true")) {
                   if(display.equals(""))
                       writeToBrowser(nextLink.toString()+next+"</a>");
                   else
                       writeToBrowser(nextLink.toString());
               }
           }
       }
       return EVAL_PAGE;
   }// doEndTag() ENDS  
  
   /**  
    * The <b>doStartTag</b> method is called when the start tag is encountered.  
    * @param   none  
    * @return  the eval state  
    */  
   //---------------------------------------------------------------------------  
   public int doStartTag(){  
   //---------------------------------------------------------------------------  
      log.fine("doStartTag:"+getClass());
       
      pageContext.setAttribute(getId(),this);
      Utilities utilities=new Utilities();  
      int returnCode=EVAL_BODY_BUFFERED;  
      parent=(SQLTags)pageContext.getAttribute(getParentName()); 
      if(parent==null) {
          log.warning("NextTag:can't find parent tag");
          return SKIP_BODY;
      }
      String paging=utilities.nvl(parent.getPaging(), "false");
      if(paging.equals("true"))
            hasNextLink(true); 
      else
          hasNextLink(false);
      int pageSize=parent.getPageSize();  
      int sizeOfCursor=parent.getResultSetSize();
      

      int startRow=utilities.stringToInt(parent.getStartRow());  

      {
            if((startRow+pageSize)>sizeOfCursor && paging.equals("true"))  
                hasNextLink(false);  

            nextLink.setLength(0);  

            if(!parent.isNextPage())  
                returnCode=SKIP_BODY;  
            else{  
                if((pageSize+startRow)>=sizeOfCursor && paging.equals("true"))  
                    hasNextLink(false);  

                startRow=startRow+pageSize;  

                if(href.indexOf("?")<0)  
                    nextLink.append("<a href='"+href+"?"+parent.getStartRowParameter()+"=");  
                else  
                    nextLink.append("<a href='"+href+"&"+parent.getStartRowParameter()+"=");  

                nextLink.append(startRow);  
                nextLink.append("'");
                if(!target.equals("")) 
                    nextLink.append(" target='"+target+"'");
                if(!id.equals("")) 
                    nextLink.append(" id='"+id+"'");                
                nextLink.append(">");  
                if(!display.equals("")) 
                    nextLink.append(display+"</a>");                
            }  
      }  
  
      return returnCode;  
   }// doStartTag() ENDS  
  
   /**  
    * <code>hasNextLink</code>  
    * <p>  
    * This method is used to determin if the next link hyperlink should be  
    * displayed  
    * </p>  
    * @param hasNextLink <code>boolean</code> true if the next link should be shown.  
    * @return <code>none</code>   
    */  
   //---------------------------------------------------------------------------  
   private void hasNextLink(boolean hasNextLink){  
   //---------------------------------------------------------------------------  
      this.hasNextLink=hasNextLink;  
   }// hasNextLink() ENDS  
  
   /**  
    * <code>isNextLink</code>  
    * <p>  
    * This method is used to return the state of the hasNextLink member.  
    * </p>  
    * @param <code>none</code>   
    * @return hasNextLink<code>boolean</code> true if we are displaying the next link.  
    */  
   //---------------------------------------------------------------------------  
   private boolean isNextLink(){  
   //---------------------------------------------------------------------------  
      return hasNextLink;  
   }// isNextLink() ENDS  
  
   /**  
    * <code>log</code>  
    * <p>  
    * This method logs errors to netscapes error log.  
    * </p>  
    * @param message <code>String</code> the error to log.  
    * @return true <code>boolean</code> If there are more records to fetch.  
    */  
   /**
    *
   //---------------------------------------------------------------------------  
   public void log(String message){  
   //---------------------------------------------------------------------------  
      StringBuffer buffer=new StringBuffer(  
         Calendar.getInstance().getTime().toString()+": "+message);  
      pageContext.getServletContext().log(buffer.toString());  
      return;  
   }// log() ENDS  
    *
    */
  
   /**  
    * <code>writeToBrowser</code>  
    * <p>  
    * This method writes to the browser  
    * </p>  
    * @param message <code>String</code> the message to write.  
    * @return <code>none</code>   
    */  
   //---------------------------------------------------------------------------  
   public void writeToBrowser(String message){  
   //---------------------------------------------------------------------------  
      try{  
	      pageContext.getOut().println(message);  
      }  
      catch(IOException exception){  
         log.warning("NextTag.writeToBrowser: "+exception);  
      }  
   }// writeToBrowser() ENDS  
  
   //***************************************************************************  
   //                      Accessor section  
   //***************************************************************************  
   /**  
    * The <b>getHref</b> method return the href.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public String getHref(){  
   //---------------------------------------------------------------------------  
      return href;  
   }// getHref() ENDS  
   
   /**  
    * The <b>getId</b> method return the id.  
    * @param   none  
    * @return  the id value  
    */  
   //---------------------------------------------------------------------------  
   public String getId(){  
   //---------------------------------------------------------------------------  
      return id;  
   }// getId() ENDS  

   /**  
    * The <b>getShowLink</b> method return the showLink.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public String getShowLink(){  
   //---------------------------------------------------------------------------  
      return showLink;  
   }// getShowLink() ENDS  

   /**  
    * The <b>getDisplay</b> method return the display
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public String getDisplay(){  
   //---------------------------------------------------------------------------  
      return display;  
   }// getDisplay() ENDS 
   
   /**  
    * The <b>getTarget</b> method return the target
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public String getTarget(){  
   //---------------------------------------------------------------------------  
      return target;  
   }// getTarget() ENDS 
   
   /**  
    * The <b>getNextLink</b> method is used to return the name attribute.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public String getNextLink(){  
   //---------------------------------------------------------------------------  
      return nextLink.toString();  
   }// getName() ENDS  
   
   /**  
    * The <b>getParentName</b> method is used to return the parentName attribute.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public String getParentName(){  
   //---------------------------------------------------------------------------  
      return parentName;  
   }// getParentName() ENDS 
  
   //***************************************************************************  
   //                      Mutator section  
   //***************************************************************************  
   /**  
    * The <b>setHref</b> method is used to set the href attribute.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public void setHref(String href){  
   //---------------------------------------------------------------------------  
       this.href=href;  
   }// setHref() ENDS   

   /**  
    * The <b>setId</b> method return the id.  
    * @param   value to be set  
    * @return  none
    */  
   //---------------------------------------------------------------------------
   public void setId(String id){
      this.id = id;
   }// getId() ENDS
   
   /**  
    * The <b>setShowLink</b> method is used to set the href attribute.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public void setShowLink(String showLink){  
   //---------------------------------------------------------------------------
       this.showLink=showLink;  
   }// setShowLink() ENDS  

   /**  
    * The <b>setDisplay</b> method is used to set the display attribute.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public void setDisplay(String display){  
   //---------------------------------------------------------------------------  
       this.display=display;  
   }// setDisplay() ENDS  

   /**  
    * The <b>setTarget</b> method is used to set the target attribute.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public void setTarget(String target){  
   //---------------------------------------------------------------------------  
       this.target=target;  
   }// setTarget() ENDS  
   
   /**  
    * The <b>setParentName</b> method is used to set the parentName attribute.  
    * @param   none  
    * @return  the name value  
    */  
   //---------------------------------------------------------------------------  
   public void setParentName(String parentName){  
   //---------------------------------------------------------------------------  
      this.parentName=parentName;  
   }// setParentName() ENDS  
  
   /**  
    * <code>toString</code>  
    * <p>  
    * This method provides a default print for the class.  
    * </p>  
    * @param <code>none</code>  
    */  
   //---------------------------------------------------------------------------  
   public String toString(){  
   //---------------------------------------------------------------------------  
      StringBuffer buffer=new StringBuffer("\n*****NextTag: ");  
      buffer.append("\tbody="+body);  
      buffer.append("\tdisplay="+display);      
      buffer.append("\thasNextLink="+hasNextLink);  
      buffer.append("\thref="+href);  
      buffer.append("\tnextLink="+nextLink);  
      buffer.append("\tparentName="+parentName);   
      buffer.append("\tshowLink="+showLink);
      buffer.append("\ttarget="+target);
      buffer.append("\tparent="+parent);  
      return buffer.toString();  
   }// toString() ENDS  
}//NextTag() ENDS  
