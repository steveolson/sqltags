/* $Id: CursorTag.java,v 1.18 2003/11/12 20:30:04 solson Exp $
 * $Log: CursorTag.java,v $
 * Revision 1.18  2003/11/12 20:30:04  solson
 * some cleanup on SQLTags (removed unused variables)
 * moved output from doFinally to doAfterBody ... should work ..
 * added bodyContent.clearBody() call to cleanup output for pooled tags
 *
 * Revision 1.17  2003/06/19 05:43:06  solson
 * removed log.info() call in doEnd
 *
 * Revision 1.16  2003/06/18 17:58:50  solson
 * added check in doEndTag (or doFinally) to test for not null enclosingWriter() to fix bug
 * when bodyContent has no writer.
 *
 * Revision 1.15  2003/05/22 17:57:12  solson
 * added java.util.logging.Logger; removed finalize(); moved class properties to top;
 *
 * Revision 1.14  2003/05/17 03:23:35  solson
 * Major rewrite to support replacement of ColumnProperties with SQLTagsColumns;
 * which now supports native DATE, TIME, TIMESTAMP, and NUMBER conversions
 * in Java and not in the database queries.
 *
 * Revision 1.13  2003/03/26 19:26:08  jpoon
 * fix more bugs and add paging to cursor tag
 *
 * Revision 1.12  2003/01/20 22:10:42  solson
 * updated return codes from tag methods based on updated JSP specs.
 *
 * Revision 1.11  2002/11/11 20:34:12  jpoon
 * fix bug,
 * findAncestorWithClass(this, ConnectionTag.class);
 * not
 * findAncestorWithClass(this, SQLTagsConnection.class);
 *
 * Revision 1.10  2002/11/11 20:31:27  jpoon
 * change ConnectionTag as parameters and class variable
 * to super class SQLTagsConnection
 *
 * Revision 1.9  2002/08/13 17:58:38  jpoon
 * fixed bug sql declare "" instead of null
 *
 * Revision 1.8  2002/08/08 19:38:38  jpoon
 * add hasFetch for cursorTag
 *
 * Revision 1.7  2002/08/08 18:13:14  jpoon
 * fix bug, sql="..." will loop
 *
 * Revision 1.6  2002/08/07 15:13:11  jpoon
 * re-construct connection manager
 *
 * Revision 1.5  2002/07/17 19:23:59  solson
 * cleaned up the Handler calls.  Modified calls to the handler class and fixed
 * parameters to class ... changed parameter from "Object" to "SQLTags"
 *
 * Revision 1.4  2002/05/23 15:50:26  solson
 * removed all references to caching implementation
 *
 * Revision 1.3  2002/03/15 14:27:59  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.jsptags;  
import com.aitworks.sqltags.utilities.*;  
import java.io.*;  
import javax.servlet.jsp.*;  
import javax.servlet.jsp.tagext.*;  
import java.util.logging.Logger;
  
/**  
 * <code>CursorTag</code>  
 * <p>  
 * This class creates a tag which talks to the jsp. It is used to create the   
 * actual cursor tag which communicates with the database.  
 * </p>  
 * @author  Booker Northington II  
 * @version 1.0  
 * @since   1.3  
 * @param none <code>none</code> none.  
 * @see Cursor <code>Cursor</code> For more information.  
 * @return none <code>none</code> none.  
 */  
//---------------------------------------------------------------------------  
final public class CursorTag extends Cursor
    implements TryCatchFinally 
    {  
//---------------------------------------------------------------------------  
   //**************************************************************************  
   // Class Variables   
   //**************************************************************************  
    private static Logger log = Logger.getLogger("com.aitworks.sqltags.jsptags.CursorTag");
    private String sql="";
    private String id;
   // private SQLTags parent;  
    
   //**************************************************************************  
   // Constructor  
   //**************************************************************************  
   /**  
    * <code>CursorTag</code>  
    * <p>  
    * This is the default class constructor and is used to return an instance   
    * of the class.  
    * </p>  
    * PCM-1  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public CursorTag(){  
   //---------------------------------------------------------------------------  
   }  
  
   //**************************************************************************  
   // Public Methods  
   //**************************************************************************  
   /**  
    * <code>setSql</code>  
    * <p>  
    * This method sets sql statement.  
    * </p>  
    * PCM-1  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param item <code>String</code> The new sql statement.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setSql(String string){  
   //---------------------------------------------------------------------------  
      sql=string;  
   }  
  
   /**  
    * <code>getSql</code>  
    * <p>  
    * This method returns the sql statement associated with this instance..  
    * </p>  
    * PCM-1  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return sql <code>String</code> The current sql statement.  
    */  
   //---------------------------------------------------------------------------  
   public String getSql(){  
   //---------------------------------------------------------------------------  
      return sql;  
   }  
  
   /**  
    * <code>setID</code>  
    * <p>  
    * This method sets the name of the scripting variable associated with this   
    * tag.  
    * </p>  
    * PCM-1  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param id <code>String</code> The name of the scripting variable.  
    * @return none <code>none</code> none.  
    */  
   /*
   //---------------------------------------------------------------------------  
   public void setId(String string){  
   //---------------------------------------------------------------------------  
      id=string;  
   }// setId() ENDS  
    */
  
   /**  
    * <code>getID</code>  
    * <p>  
    * This method returns the scripting variable associated with the class.  
    * </p>  
    * PCM-1  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return id <code>String</code> The scripting variable name.  
    */  
   /*
   //---------------------------------------------------------------------------  
   public String getId(){  
   //---------------------------------------------------------------------------  
      return id;  
   }// getId() ENDS  
    */
  
   /**  
    * <code>doEndTag</code>  
    * <p>  
    * This method is called when the end tag is encountered. Any post processing   
    * can be acomplished here.  
    * </p>  
    * PCM-8  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return value <code>int</code> flag indicating your done.  
    */  
   /***
   //---------------------------------------------------------------------------  
   public int doEndTag(){  
   //---------------------------------------------------------------------------  
       int returnCode=SKIP_BODY;
       try{
           if(bodyContent!=null && bodyContent.getEnclosingWriter()!=null)
               bodyContent.writeOut(bodyContent.getEnclosingWriter());
       }
       catch(IOException exception){
           log.warning("CursorTag.doEndTag: "+exception);
       }
       
       pageContext.removeAttribute(getId());
       close();
       
       returnCode=EVAL_PAGE;
       return returnCode;
   }// doEndTag() ENDS  
    *
    */
  
   /**  
    * <code>doStartTag</code>  
    * <p>  
    * This method is called when the start tag of the jsp is encountered.  We   
    * make the assumption that all of your mutators have been set prior   
    * to entering  this method. The body of the tag has not been   
    * processed you this method   
    * is invoked.  
    * </p>  
    * PCM-4  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return value <code>int</code> Indicates whether to prosses the body.  
    */  
   //---------------------------------------------------------------------------  
   public int doStartTag(){  
   //---------------------------------------------------------------------------  
      int returnCode=EVAL_BODY_BUFFERED;  
      pageContext.setAttribute(getId(),this);
       if(getPaging().equalsIgnoreCase("true")){
           setStartRow(nvl((String)pageContext.getRequest().getParameter(getStartRowParameter()), "0"));
       }
       else {
           setPageSize("0");
       }      
      sqlTagsConnection=(SQLTagsConnection)findAncestorWithClass(this,ConnectionTag.class);
      
      if(sqlTagsConnection==null)
          return SKIP_BODY;
      
      if(getSql().equals("")) {
          returnCode=EVAL_BODY_BUFFERED;
      } else if(!select(getSql())) {
          returnCode=SKIP_BODY;
      } else if(fetch()) {
          returnCode=EVAL_BODY_BUFFERED;
      } else {
          // now what? ... 
      }
      
      return returnCode;  
   }// doStartTag() ENDS  

   /**
    * <code>doAfterBody</code>
    * <p>
    * This method is executed after the body has been evaluated. If SKIP_BODY 
    * is returned or the tags body is empty, this method is not called. It is 
    * invoked after the body has been evaluated and is initially invoked by 
    * doStartTag.
    * </p>
    * @author  Booker Northington II
    * @version 1.0
    * @since   1.3
    * @param none <code>none</code> none.
    * @return value <code>int</code> Indicates whether to continue evaluating 
    *        the body.
    */
   //---------------------------------------------------------------------------
   public int doAfterBody(){
   //---------------------------------------------------------------------------
      int returnCode=SKIP_BODY;
      if(getSql().equals("")||isFetch()) {
         returnCode=SKIP_BODY;
      } else if(fetch()) {
         returnCode=EVAL_BODY_AGAIN;
      } else {
          close();
          setLastRecord(true);
      }
       try{
           // if(bodyContent!=null && bodyContent.getEnclosingWriter()!=null) 
           if(bodyContent!=null) 
           {
               bodyContent.writeOut(getPreviousOut());
               bodyContent.clearBody();
           }
       }
       catch(IOException exception){
           log.warning("CursorTag.doEndTag: "+exception);
       }
      
      return returnCode;
   }// doAfterBody() ENDS
   
   /**  
    * <code>toString</code>  
    * <p>  
    * This method provides a default print for the class.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param <code>none</code>  
    */  
   //---------------------------------------------------------------------------  
   public String toString(){  
   //---------------------------------------------------------------------------  
      StringBuffer buffer=new StringBuffer("\n*****CursorTag: ");  
      buffer.append("\tid="+id);  
      buffer.append("\tsql="+sql);  
      // buffer.append("\tconnection+="+parent);  
      return buffer.toString();  
   }
   
   public void doCatch(Throwable t) throws java.lang.Throwable {
       log.severe("CursorTag: doCatch(): " + t.toString() );
       Exception e = new Exception (t);
       setException(e);
   }
   
   public void doFinally() {
       pageContext.removeAttribute(getId());
   }
   
// toString() ENDS  
  
}//CursorTag() ENDS  
