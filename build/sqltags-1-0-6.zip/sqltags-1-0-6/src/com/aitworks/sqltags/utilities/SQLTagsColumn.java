/* $Id: SQLTagsColumn.java,v 1.7 2003/06/19 19:49:58 solson Exp $
 * $Log: SQLTagsColumn.java,v $
 * Revision 1.7  2003/06/19 19:49:58  solson
 * added try block to getValueDateField() to avoid Number Format exceptions ...
 *
 * Revision 1.6  2003/06/17 22:02:12  lindahl
 * Modified the hour fields in the dateFieldHash to correctly assume whether the hour starts at 0 or 1, as per SimpleDateFormat spec
 *
 * Revision 1.5  2003/06/16 21:31:12  solson
 * fixed problem with null NUMBERS returning 0 ... not null.
 *
 * Revision 1.4  2003/05/22 18:11:38  solson
 * updated logging
 *
 * Revision 1.3  2003/05/17 03:24:17  solson
 * Major rewrite to support replacement of ColumnProperties with SQLTagsColumns;
 * which now supports native DATE, TIME, TIMESTAMP, and NUMBER conversions
 * in Java and not in the database queries.
 *
 * Revision 1.2  2003/05/12 20:41:01  solson
 * added getValueDate(), getValueDateField(), getValueNumber() methods and added
 * support for java.text.SimpleDateFormat fields for formatting
 *
 * Revision 1.1  2003/05/08 04:31:44  solson
 * this will be a replacement for ColumnProperties
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 * Created on May 7, 2003, 9:58 PM
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.utilities;
import java.io.*;
import java.util.logging.*;
import java.util.Hashtable;
import java.util.Date;
import java.util.Enumeration;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParsePosition;
import java.text.FieldPosition;
import java.text.ParseException;
import java.sql.Types;
/**
 *
 * @author  solson
 */
public class SQLTagsColumn {
    private static Logger log = Logger.getLogger("com.aitworks.sqltags.utilities.SQLTagsColumn");
    
    /** 
     * Properties.
     */
    private String name;            // column name
    private String type="STRING";   // type of column
    private String size="0";        // max size of field for input size
    private String format="";       // java Format for Date, Number, Decimals
    private boolean baseTable=true; // part of the table or not ... 
    private String arrayIndex="0";  // Index into array of values
    private Hashtable valueHash=new Hashtable();
                                    // hashtable of String values
    private Hashtable dateFieldHash=new Hashtable();
                                    // Hashtable of DATE Field Strings ... 
    /*
    private Hashtable calHash=new Hashtable();
                                    // hashtable of Calendar Objects for DATES
                                    // Hashtable is needed to ensure that the array
                                    // of Dates can be constructed a field at a time
                                    // using setDateField() calls with random calls
                                    // to arrayIndex.
     */
    private Object object=new Object();
                                    // Object to hold special stuff like CLOB/BLOB
    private boolean ignoreArrayIndex=false; 
                                    // ignoreArrayIndex (special purpose for FKs)
    private String bindFormat="";   // bind format -- backward compat avoid!
    private String selectFormat=""; // select format -- backward compat avoid!
    private int sqlType=Types.NULL; /** Holds value of property sqlType. */
    
    /** 
     * Constructors - Creates a new instance of SQLTagsColumn
     */
    public SQLTagsColumn(String name
                        ,String value
                        ,String arrayIndex
                        ,String type
                        ,int sqlType
                        ,String size
                        ,String format
                        ,String bindFormat
                        ,String selectFormat
                        ,boolean baseTable
                        ,Object object
                        )
    {
        initialize();
        setName(name);
        setArrayIndex(arrayIndex);
        setType(type);
        setSqlType(sqlType);
        setSize(size);
        
        // Attempt to use "smart" defaults if none is given ... 
        // Should derive this from a properties files .. some day . :))
        if(format.equals("") && type.equalsIgnoreCase("DATE")) {
            setFormat("MM/dd/yyyy");
        } else if(format.equals("") && type.equalsIgnoreCase("TIME")) {
            setFormat("kk:mm:ss");
        } else if(format.equals("") && type.equalsIgnoreCase("TIMESTAMP")) {
            setFormat("MM/dd/yyyy kk:mm:ss");
        } else if(format.equals("") && type.equalsIgnoreCase("NUMBER")) {
            setFormat("###0");
        } else {
            setFormat(format);
        }
        setBindFormat(bindFormat);
        setSelectFormat(selectFormat);
        setBaseTable(baseTable);
        setObject(object);
        setValue(value);
    }
    public SQLTagsColumn() {
        this("unknown","","0","STRING",Types.VARCHAR,"0", "", "?", "unknown", true, null);
    }
    public SQLTagsColumn(String name) {
        this(name,"","0","STRING",Types.VARCHAR,"0", "", "?", name, true, null);
    }
    public SQLTagsColumn(String name, String value) {
        this(name,value,"0","STRING",Types.VARCHAR, "0", "", "?", name, true, null);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex) {
        this(name,value,arrayIndex,"STRING",Types.VARCHAR, "0", "", "?", name, true, null);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex, String type, int sqlType) {
        this(name,value,arrayIndex,type,sqlType, "0", "", "?", name, true, null);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex, String type,int sqlType, String size) {
        this(name,value,arrayIndex,type,sqlType,size, "", "?", name, true, null);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex, String type,int sqlType, String size, String format) {
        this(name,value,arrayIndex,type,sqlType, size, format, "?", name, true, null);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex, String type,int sqlType, String size, String format, boolean baseTable) {
        this(name,value,arrayIndex,type,sqlType,size, format, "", "", baseTable, null);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex, String type, int sqlType, String size, String format, boolean baseTable, Object object) {
        this(name,value,arrayIndex,type,sqlType,size, format, "", "", baseTable, object);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex, String type,int sqlType, String size, String format, String bindFormat) {
        this(name,value,arrayIndex,type,sqlType, size, format, bindFormat, name, true, null);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex, String type, int sqlType, String size, String format, String bindFormat, String selectFormat) {
        this(name,value,arrayIndex,type,sqlType,size, format, bindFormat, selectFormat, true, null);
    }
    public SQLTagsColumn(String name, String value, String arrayIndex, String type, int sqlType, String size, String format, String bindFormat, String selectFormat, boolean baseTable) {
        this(name,value,arrayIndex,type,sqlType,size, format, bindFormat, selectFormat, baseTable, null);
    }
    
    private void initialize(){
        dateFieldHash.put("AM_PM", new Integer(DateFormat.AM_PM_FIELD));
        dateFieldHash.put("a", new Integer(DateFormat.AM_PM_FIELD));
        dateFieldHash.put("am", new Integer(DateFormat.AM_PM_FIELD));
        dateFieldHash.put("AM", new Integer(DateFormat.AM_PM_FIELD));
        dateFieldHash.put("pm", new Integer(DateFormat.AM_PM_FIELD));
        dateFieldHash.put("PM", new Integer(DateFormat.AM_PM_FIELD));
        
        dateFieldHash.put("DATE", new Integer(DateFormat.DATE_FIELD));
        dateFieldHash.put("dd", new Integer(DateFormat.DATE_FIELD));
        dateFieldHash.put("d", new Integer(DateFormat.DATE_FIELD));

        dateFieldHash.put("DAY_OF_WEEK", new Integer(DateFormat.DAY_OF_WEEK_FIELD));
        dateFieldHash.put("E", new Integer(DateFormat.DAY_OF_WEEK_FIELD));
        dateFieldHash.put("EE", new Integer(DateFormat.DAY_OF_WEEK_FIELD));
        dateFieldHash.put("DAY", new Integer(DateFormat.DATE_FIELD));
        dateFieldHash.put("day", new Integer(DateFormat.DATE_FIELD));
        
        dateFieldHash.put("DAY_OF_WEEK_IN_MONTH", new Integer(DateFormat.DAY_OF_WEEK_IN_MONTH_FIELD));
        dateFieldHash.put("F", new Integer(DateFormat.DAY_OF_WEEK_IN_MONTH_FIELD));
        dateFieldHash.put("FF", new Integer(DateFormat.DAY_OF_WEEK_IN_MONTH_FIELD));
        
        dateFieldHash.put("DAY_OF_YEAR", new Integer(DateFormat.DAY_OF_YEAR_FIELD));
        dateFieldHash.put("D", new Integer(DateFormat.DAY_OF_YEAR_FIELD));
        dateFieldHash.put("DD", new Integer(DateFormat.DAY_OF_YEAR_FIELD));
        
        dateFieldHash.put("ERA", new Integer(DateFormat.ERA_FIELD));
        dateFieldHash.put("G", new Integer(DateFormat.ERA_FIELD));
        dateFieldHash.put("GG", new Integer(DateFormat.ERA_FIELD));
        dateFieldHash.put("ad", new Integer(DateFormat.ERA_FIELD));
        dateFieldHash.put("AD", new Integer(DateFormat.ERA_FIELD));
        dateFieldHash.put("bc", new Integer(DateFormat.ERA_FIELD));
        dateFieldHash.put("BC", new Integer(DateFormat.ERA_FIELD));
        
        // 24-hour fields
        dateFieldHash.put("HOUR_OF_DAY0", new Integer(DateFormat.HOUR_OF_DAY0_FIELD));
        dateFieldHash.put("hh24", new Integer(DateFormat.HOUR_OF_DAY0_FIELD));
        dateFieldHash.put("H", new Integer(DateFormat.HOUR_OF_DAY0_FIELD));
        dateFieldHash.put("HH", new Integer(DateFormat.HOUR_OF_DAY0_FIELD));
        dateFieldHash.put("k", new Integer(DateFormat.HOUR_OF_DAY1_FIELD));
        dateFieldHash.put("kk", new Integer(DateFormat.HOUR_OF_DAY1_FIELD));
        dateFieldHash.put("HOUR_OF_DAY1", new Integer(DateFormat.HOUR_OF_DAY1_FIELD));
        
        // 12-hour fields (am/pm)
        dateFieldHash.put("HOUR0", new Integer(DateFormat.HOUR0_FIELD));
        dateFieldHash.put("HOUR", new Integer(DateFormat.HOUR1_FIELD));
        dateFieldHash.put("h", new Integer(DateFormat.HOUR1_FIELD));
        dateFieldHash.put("hh", new Integer(DateFormat.HOUR1_FIELD));
        dateFieldHash.put("K", new Integer(DateFormat.HOUR0_FIELD));
        dateFieldHash.put("KK", new Integer(DateFormat.HOUR0_FIELD));
        dateFieldHash.put("HOUR1", new Integer(DateFormat.HOUR1_FIELD));
        
        dateFieldHash.put("MILLISECOND", new Integer(DateFormat.MILLISECOND_FIELD));
        dateFieldHash.put("S", new Integer(DateFormat.MILLISECOND_FIELD));
        dateFieldHash.put("SS", new Integer(DateFormat.MILLISECOND_FIELD));
        dateFieldHash.put("ms", new Integer(DateFormat.MILLISECOND_FIELD));
        dateFieldHash.put("MS", new Integer(DateFormat.MILLISECOND_FIELD));
        
        dateFieldHash.put("MINUTE", new Integer(DateFormat.MINUTE_FIELD));
        dateFieldHash.put("m", new Integer(DateFormat.MINUTE_FIELD));
        dateFieldHash.put("mm", new Integer(DateFormat.MINUTE_FIELD));
        dateFieldHash.put("mi", new Integer(DateFormat.MINUTE_FIELD));
        dateFieldHash.put("MI", new Integer(DateFormat.MINUTE_FIELD));
        
        dateFieldHash.put("MONTH", new Integer(DateFormat.MONTH_FIELD));
        dateFieldHash.put("month", new Integer(DateFormat.MONTH_FIELD));
        dateFieldHash.put("M", new Integer(DateFormat.MONTH_FIELD));
        dateFieldHash.put("MM", new Integer(DateFormat.MONTH_FIELD));
        dateFieldHash.put("MON", new Integer(DateFormat.MONTH_FIELD));
        dateFieldHash.put("mon", new Integer(DateFormat.MONTH_FIELD));
        
        dateFieldHash.put("SECOND", new Integer(DateFormat.SECOND_FIELD));
        dateFieldHash.put("s", new Integer(DateFormat.SECOND_FIELD));
        dateFieldHash.put("ss", new Integer(DateFormat.SECOND_FIELD));
        
        dateFieldHash.put("TIMEZONE", new Integer(DateFormat.TIMEZONE_FIELD));
        dateFieldHash.put("z", new Integer(DateFormat.TIMEZONE_FIELD));
        dateFieldHash.put("TZ", new Integer(DateFormat.TIMEZONE_FIELD));
        dateFieldHash.put("tz", new Integer(DateFormat.TIMEZONE_FIELD));
        
        dateFieldHash.put("WEEK_OF_MONTH", new Integer(DateFormat.WEEK_OF_MONTH_FIELD));
        dateFieldHash.put("W", new Integer(DateFormat.WEEK_OF_MONTH_FIELD));
        dateFieldHash.put("WW", new Integer(DateFormat.WEEK_OF_MONTH_FIELD));
        
        dateFieldHash.put("WEEK_OF_YEAR", new Integer(DateFormat.WEEK_OF_YEAR_FIELD));
        dateFieldHash.put("w", new Integer(DateFormat.WEEK_OF_YEAR_FIELD));
        dateFieldHash.put("ww", new Integer(DateFormat.WEEK_OF_YEAR_FIELD));
        
        dateFieldHash.put("YEAR", new Integer(DateFormat.YEAR_FIELD));
        dateFieldHash.put("y", new Integer(DateFormat.YEAR_FIELD));
        dateFieldHash.put("yy", new Integer(DateFormat.YEAR_FIELD));
        dateFieldHash.put("yyyy", new Integer(DateFormat.YEAR_FIELD));
        dateFieldHash.put("Y", new Integer(DateFormat.YEAR_FIELD));
        dateFieldHash.put("YY", new Integer(DateFormat.YEAR_FIELD));
        dateFieldHash.put("YYYY", new Integer(DateFormat.YEAR_FIELD));
    }
    
    /** clear value ... actually ... set to value "" (empty string)
     */
    public void clear(){
        clear(getArrayIndex());
    }
    public void clearAll(){
        Enumeration enum = valueHash.keys();
        while( enum.hasMoreElements() ){
            clear( (String) enum.nextElement() );
        }
    }
    public void clear(String arrayIndex){
        setValue("",arrayIndex);
    }
    
    /** Setter for value property
     * @return void
     */
    public void setValue(String value) {
        setValue(value,getArrayIndex());
    }
    /** Setter for value property
     * @return void
     */
    public void setValue(String value, String arrayIndex) {
        if(value==null)
            value="";
        if( value.length()>0 && 
                (  getType().equalsIgnoreCase("DATE") 
                || getType().equalsIgnoreCase("TIME") 
                || getType().equalsIgnoreCase("TIMESTAMP") ) )
        {
            SimpleDateFormat f = new SimpleDateFormat(getFormat());
            ParsePosition pos = new ParsePosition(0);
            java.util.Date d = f.parse(value, pos);
            if(d != null) {
                valueHash.put(arrayIndex,d);
            } else {
                log.fine("setValue:"+getName()+": Null Date: " + value);
                // OK, should this now be demoted to a STRING??
                // Or .. is it possible that the Other values in the
                // Array are OK? ... damn! ... don't know
                // setType("STRING");
                valueHash.put(arrayIndex,value);
            }
        }
        else if(value.length()>0 &&
                ( getType().equalsIgnoreCase("NUMBER"))) 
        {
            DecimalFormat f = new DecimalFormat(getFormat());
            try{
                Number n = f.parse(value);
                valueHash.put(arrayIndex,n);
            } catch( ParseException e) {
                log.info("setValue:"+getName()+":DecimalFormat Parse Error on "+value+": "+e);
                // OK, should this now be demoted to a STRING??
                // Or .. is it possible that the Other values in the
                // Array are OK? ... damn! ... don't know
                // setType("STRING");
                valueHash.put(arrayIndex,value);
            }
        }
        else {
            valueHash.put(arrayIndex,value); // use parameter ...
        }
    }
    /** Setter for value property
     * @return void
     */
    public void setValue(Number value) {
        setValue(value, getArrayIndex());
    }
    public void setValue(Number value, String arrayIndex) {
        if(value==null) {
            // value=new Integer(0);
            valueHash.put(arrayIndex,"");
        } else {
            valueHash.put(arrayIndex,value); // use parameter ...
        }
    }
    /** Setter for value property
     * @return void
     */
    public void setValue(java.util.Date value) {
        setValue(value, getArrayIndex());
    }
    public void setValue(java.util.Date value, String arrayIndex) {
        if(value==null) {
            /** can't put null date because it'll default to current time
             *  since we can put strings and dates and numbers in the
             * valueHash ... we'll put in an empty string!
             */
            valueHash.put(arrayIndex, "");
        } else {
            valueHash.put(arrayIndex,value); // use parameter ...
        }
    }
    
    /** Setter for value property
     * @return void
     * @throws IOException
     * @param InputStream converted to String
     */
    public void setValue( InputStream in ) throws IOException {
        setValue(in,getArrayIndex());
    }
    
    /** Setter for value property
     * @return void
     * @throws IOException
     * @param InputStream converted to String
     */
    public void setValue( InputStream in, String arrayIndex) throws IOException {
        StringBuffer buf = new StringBuffer();
        int charByte = 0;
        if(in==null) {
            log.fine("SQLTagsColumn:setValue:"+getName()+":"+getType()+":null InputStream");
            return;
        }
        while((charByte=in.read())!=-1) {
            buf.append((char)charByte);
        }
        setValue(buf.toString(),arrayIndex);
    }
    /** Setter for value property
     * @return void
     * @throws IOException
     * @param InputStream converted to String
     */
    public void setValue( Reader in ) throws IOException {
        setValue(in,getArrayIndex());
    }
    
    /** Setter for value property
     * @return void
     * @throws IOException
     * @param InputStream converted to String
     */
    public void setValue( Reader in, String arrayIndex ) throws IOException {
        StringBuffer buf = new StringBuffer();
        int charByte = 0;
        if(in==null) {
            log.fine("SQLTagsColumn:setValue:"+getName()+":"+getType()+":null Reader at " + arrayIndex);
            return;
        }
        while((charByte=in.read())!=-1) {
            buf.append((char)charByte);
        }
        setValue(buf.toString(),arrayIndex);
    }
    
    /** Getter for property value.
     * @return Value of property name.
     *
     */
    public String getValue() {
        return getValue( getArrayIndex() );
    }
    /** Getter for property value.
     * @return Value of property name.
     *
     */
    public String getValue( String arrayIndex) {
        Object o = getValueObject(arrayIndex);
        if(o==null) {
            log.fine("getValue["+arrayIndex+"] is null");
            return "";
        }
        if( o instanceof java.util.Date ) {
            log.finest("got Date:"+getName()+":applying format: " +getFormat() );
            // Format the current time.
            SimpleDateFormat dform = new SimpleDateFormat(getFormat());
            String dateValue = dform.format(o);
            return dateValue;
        }
        else if( o instanceof Number ) {
            log.finest("got Number for: "+getName() +": applying format: " +getFormat() );
            Number n = (Number)o;
            DecimalFormat form = new DecimalFormat(getFormat());
            return form.format( n.doubleValue() );
        }
        else if( o instanceof String ) {
            return (String) o; // use parameter
        }
        log.fine("getValue:"+getName()+":Unknown type: " + o);
        return o.toString();
    }
    
    /** Getter for value as an Object
     */
    public Object getValueObject(){
        return getValueObject(getArrayIndex());
    }
    public Object getValueObject(String arrayIndex){
        Object o = null;
        if( isIgnoreArrayIndex()) {
            // Ignore parameter and get default Array Index value
            if( !arrayIndex.equals(getArrayIndex())) {
                log.fine("getValueObject:"+getName()+":Ignoring arrayIndex:"+arrayIndex+":using "+getArrayIndex());
            }
            o = valueHash.get( getArrayIndex() );
        } else {
            o = valueHash.get( arrayIndex );
        }
        /** not sure if this'll help or hurt!
         *
        if( o==null ) {
            log.info("getValueObject:"+getName()+":"+getType()+":created new empty Object");
            o = new Object();
        }
         *
         */
        return o;
    }
    
    /** Getter for value with DATE type
     */
    public java.util.Date getValueDate(){
        return getValueDate(getArrayIndex());
    }
    public java.util.Date getValueDate(String arrayIndex){
        Object o = getValueObject(arrayIndex);
        if( o==null) {
            log.fine("getValueDate:"+getName()+"["+arrayIndex+"]:getValueObject returned null");
            return null;
        }
        if( o instanceof java.util.Date ){
            return (java.util.Date)o;
        } else if ( o instanceof Number ) {
            log.info("getValueDate:"+getName()+"["+arrayIndex+"]:"+o+":Element is a Number, not Date");
            return null;
        }
        String dateString = (String)o;
        
        SimpleDateFormat f = new SimpleDateFormat(getFormat());
        ParsePosition pos = new ParsePosition(0);
        java.util.Date d = f.parse(dateString, pos);
        
        if( d == null) {
            log.fine("getValueDate:"+getName()+"["+arrayIndex+"]:"+dateString+":"+format+":parse date failed");
            return null;
        }
        return d;
    }
    
    /** Converts a Date Field as a String into the DateFormat Field as in java.text.DateFormat
     */
    private int getFieldPosition(String pos){
        if(pos==null)  return 0;
        Integer i = (Integer)dateFieldHash.get(pos);
        if (i == null) return 0;
        return i.intValue();
    }
        
    public String getValueDateField(String pos){
        return getValueDateField(pos, getArrayIndex());
    }
    public String getValueDateField(String pos, String arrayIndex){
        java.util.Date d = getValueDate(arrayIndex);
        if( d == null){
            log.fine("getValueDateField:"+getName()+":"+arrayIndex+":can't convert value to date:"+getValue(arrayIndex));
            return "";
        }
        try {
            FieldPosition fPos = new FieldPosition(getFieldPosition(pos));
            if( fPos == null ){
                log.info("getValueDateField:"+getName()+":"+arrayIndex+":invalid field position:"+pos);
                return "";
            }
            StringBuffer buf = new StringBuffer();
            SimpleDateFormat dFmt = new SimpleDateFormat(getFormat());
            buf = dFmt.format(d, buf, fPos);
            return buf.substring(fPos.getBeginIndex(), fPos.getEndIndex());
        }
        catch (Exception e) {
            log.warning("getValueDateField("+pos+","+arrayIndex+"):"+e);
            return "";
        }
    }
    
    /** Getter for value with NUMBER type
     */
    public Number getValueNumber(){
        return getValueNumber(getArrayIndex());
    }
    public Number getValueNumber(String arrayIndex){
        Object o = getValueObject(arrayIndex);
        if( o==null) {
            log.fine("getValueNumber:"+getName()+"["+arrayIndex+"]:getValueObject returned null");
            return null;
        }
        if( o instanceof Number ){
            return (Number)o;
        } else if ( o instanceof java.util.Date ) {
            log.warning("getValueNumber:"+getName()+":"+arrayIndex+":"+o+":Element is a Date, not Number");
            return null;
        }
        String numString = (String)o;
        
        DecimalFormat f = new DecimalFormat(getFormat());
        ParsePosition pos = new ParsePosition(0);
        Number n = f.parse(numString, pos);
        
        if(n == null) {
            if(! (numString==null || numString.equals("")) ) {
                log.fine("getValueNumber:"+getName()+"["+arrayIndex+"]="+numString+":"+format+":parse number failed");
            }
            return null;
        }
        return n;
    }
    
    /** Getter for property name.
     * @return Value of property name.
     *
     */
    public String getName() {
        return this.name;
    }
    
    /** Setter for property name.
     * @param name New value of property name.
     *
     */
    public void setName(String name) {
        if(name!=null) {
            this.name = name.toUpperCase();
        }
    }
    
    /** Getter for property type.
     * @return Value of property type.
     *
     */
    public String getType() {
        return this.type;
    }
    
    /** Setter for property type.
     * @param type New value of property type.
     *
     */
    public void setType(String type) {
        this.type = type;
    }
    
    /** Getter for property baseTable.
     * @return Value of property baseTable.
     *
     */
    public boolean isBaseTable() {
        return this.baseTable;
    }
    
    /** Setter for property baseTable.
     * @param baseTable New value of property baseTable.
     *
     */
    public void setBaseTable(boolean baseTable) {
        this.baseTable = baseTable;
    }
    
    /** Getter for property format.
     * @return Value of property format.
     *
     */
    public String getFormat() {
        return this.format;
    }
    
    /** Setter for property format.
     * @param format New value of property format.
     *
     */
    public void setFormat(String format) {
        this.format = format;
    }
    
    /** Getter for property arrayIndex.
     * @return Value of property arrayIndex.
     *
     */
    public String getArrayIndex() {
        return this.arrayIndex;
    }
    
    /** Setter for property arrayIndex.
     * @param arrayIndex New value of property arrayIndex.
     *
     */
    public void setArrayIndex(String arrayIndex) {
        this.arrayIndex = arrayIndex;
    }
    
    /** Getter for property bindFormat.
     * @return Value of property bindFormat.
     *
     */
    public String getBindFormat() {
        return this.bindFormat;
    }
    
    /** Setter for property bindFormat.
     * @param bindFormat New value of property bindFormat.
     *
     */
    public void setBindFormat(String bindFormat) {
        this.bindFormat = bindFormat;
    }
    
    /** Getter for property selectFormat.
     * @return Value of property selectFormat.
     *
     */
    public String getSelectFormat() {
        return this.selectFormat;
    }
    
    /** Setter for property selectFormat.
     * @param selectFormat New value of property selectFormat.
     *
     */
    public void setSelectFormat(String selectFormat) {
        this.selectFormat = selectFormat;
    }
    
    /** Getter for property object.
     * @return Value of property object.
     *
     */
    public Object getObject() {
        return this.object;
    }
    
    /** Setter for property object.
     * @param object New value of property object.
     *
     */
    public void setObject(Object object) {
        this.object = object;
    }
    
    
    /** Getter for property size.
     * @return Value of property size.
     *
     */
    public String getSize() {
        return this.size;
    }
    
    /** Setter for property size.
     * @param size New value of property size.
     *
     */
    public void setSize(String size) {
        this.size = size;
    }
    
    /** Getter for property ignoreArrayIndex.
     * @return Value of property ignoreArrayIndex.
     *
     */
    public boolean isIgnoreArrayIndex() {
        return this.ignoreArrayIndex;
    }
    
    /** Setter for property ignoreArrayIndex.
     * @param ignoreArrayIndex New value of property ignoreArrayIndex.
     *
     */
    public void setIgnoreArrayIndex(boolean ignoreArrayIndex) {
        this.ignoreArrayIndex = ignoreArrayIndex;
    }
    
    /** toString
     */
    public String toString(){
        return "SQLTagsColumn:name="+name+"["+arrayIndex+"]:type="+type+":format="+format+":bind:"+bindFormat+":values="+valueHash ;
    }
    
    /* main, basically for testing purposes ..
     *
     */
    public static void main( String args [] ) {
        
        // Testing Numbers
        SQLTagsColumn t1 = new SQLTagsColumn("t1", "50023422.2344","0","NUMBER",Types.NUMERIC,"0","#,000.00");
        // t1.setFormat("#,000.00");
        t1.setValue("100.00","1");
        t1.setValue( new Integer(3), "2");
        t1.setValue( "xx4234", "3");
        System.out.println("[0]=" + t1.getValue("0") );
        System.out.println("[1]=" + t1.getValue("1") );
        System.out.println("[2]=" + t1.getValue("2") );
        System.out.println("[3]=" + t1.getValue("3") );
        
        // Testing Dates; dates will use default format if no format is given ... 
        // SQLTagsColumn t2 = new SQLTagsColumn("t2", "1963/10/28 13:45:59","0","DATE",Types.DATE,"0","yyyy/MM/dd kk:mm:ss");
        // SQLTagsColumn t2 = new SQLTagsColumn("t2", "1963/10/28 13:45:59","0","TIME",Types.TIME);
        SQLTagsColumn t2 = new SQLTagsColumn("t2", "1963/10/28 13:45:59","0","TIMESTAMP",Types.TIMESTAMP);
        // SQLTagsColumn t2 = new SQLTagsColumn("t2", "1963/10/28 13:45:59","0","DATE",Types.DATE);
        t2.setFormat("yyyy/MM/dd hh(kk) w W E D F HH(KK) kk:mm:ss a z");
        t2.setValue( new java.util.Date(), "1" );
        t2.setValue( new java.util.Date(), "2" );
        t2.setValue( "1999/xx/33 01:01:01", "3");
        System.out.println("[0]=" + t2.getValue("0") );
        System.out.println("[1]=" + t2.getValue("1") );
        System.out.println("[2]=" + t2.getValue("2") );
        System.out.println("[3]=" + t2.getValue("3") );
        
        System.out.println("[2.AM_PM]="+t2.getValueDateField("AM_PM","2"));
        System.out.println("[2.DATE]="+t2.getValueDateField("DATE","2"));
        System.out.println("[2.DAY_OF_WEEK]="+t2.getValueDateField("DAY_OF_WEEK","2"));
        System.out.println("[2.DAY_OF_WEEK_IN_MONTH]="+t2.getValueDateField("DAY_OF_WEEK_IN_MONTH","2"));
        System.out.println("[2.DAY_OF_YEAR]="+t2.getValueDateField("DAY_OF_YEAR","2"));
        System.out.println("[2.ERA]="+t2.getValueDateField("ERA","2"));
        System.out.println("[2.HOUR_OF_DAY0]="+t2.getValueDateField("HOUR_OF_DAY0","2"));
        System.out.println("[2.HOUR_OF_DAY1]="+t2.getValueDateField("HOUR_OF_DAY1","2"));
        System.out.println("[2.HOUR0]="+t2.getValueDateField("HOUR0","2"));
        System.out.println("[2.HOUR1]="+t2.getValueDateField("HOUR1","2"));
        System.out.println("[2.MISSISECOND]="+t2.getValueDateField("MILLISECOND","2"));
        System.out.println("[2.MINUTE]="+t2.getValueDateField("MINUTE","2"));
        System.out.println("[2.MONTH]="+t2.getValueDateField("MONTH","2"));
        System.out.println("[2.SECOND]="+t2.getValueDateField("SECOND","2"));
        System.out.println("[2.TIMEZONE]="+t2.getValueDateField("TIMEZONE","2"));
        System.out.println("[2.WEEK_OF_MONTH]="+t2.getValueDateField("WEEK_OF_MONTH","2"));
        System.out.println("[2.WEEK_OF_YEAR]="+t2.getValueDateField("WEEK_OF_YEAR","2"));
        System.out.println("[2.YEAR]="+t2.getValueDateField("YEAR","2"));

        System.out.println("[2.K]="+t2.getValueDateField("KK","2"));
        System.out.println("[2.z]="+t2.getValueDateField("z","2"));
        System.out.println("[2.y]="+t2.getValueDateField("y","2"));

        // Testing Strings
        SQLTagsColumn t3 = new SQLTagsColumn("t3", "default value","0","STRING",Types.VARCHAR);
        t3.setValue("hello world", "1");
        t3.setValue("goodby cruel world!","2");
        System.out.println("[0]=" + t3.getValue("0") );
        System.out.println("[1]=" + t3.getValue("1") );
        System.out.println("[2]=" + t3.getValue("2") );
        
        System.exit(0);
    }
    
    /** Getter for property sqlType.
     * @return Value of property sqlType.
     *
     */
    public int getSqlType() {
        return this.sqlType;
    }
    
    /** Setter for property sqlType.
     * @param sqlType New value of property sqlType.
     *
     */
    public void setSqlType(int sqlType) {
        this.sqlType = sqlType;
    }
    
}
/**
        dateFieldHash.put("AM_PM", new Integer(DateFormat.AM_PM_FIELD));
        dateFieldHash.put("DATE", new Integer(DateFormat.DATE_FIELD));
        dateFieldHash.put("DAY_OF_WEEK", new Integer(DateFormat.DAY_OF_WEEK_FIELD));
        dateFieldHash.put("DAY_OF_WEEK_IN_MONTH", new Integer(DateFormat.DAY_OF_WEEK_IN_MONTH_FIELD));
        dateFieldHash.put("DAY_OF_YEAR", new Integer(DateFormat.DAY_OF_YEAR_FIELD));
        dateFieldHash.put("ERA", new Integer(DateFormat.ERA_FIELD));
        dateFieldHash.put("HOUR_OF_DAY0", new Integer(DateFormat.HOUR_OF_DAY0_FIELD));
        dateFieldHash.put("HOUR_OF_DAY1", new Integer(DateFormat.HOUR_OF_DAY1_FIELD));
        dateFieldHash.put("HOUR0", new Integer(DateFormat.HOUR0_FIELD));
        dateFieldHash.put("HOUR1", new Integer(DateFormat.HOUR1_FIELD));
        dateFieldHash.put("MILLISECOND", new Integer(DateFormat.MILLISECOND_FIELD));
        dateFieldHash.put("MINUTE", new Integer(DateFormat.MINUTE_FIELD));
        dateFieldHash.put("MONTH", new Integer(DateFormat.MONTH_FIELD));
        dateFieldHash.put("SECOND", new Integer(DateFormat.SECOND_FIELD));
        dateFieldHash.put("TIMEZONE", new Integer(DateFormat.TIMEZONE_FIELD));
        dateFieldHash.put("WEEK_OF_MONTH", new Integer(DateFormat.WEEK_OF_MONTH_FIELD));
        dateFieldHash.put("WEEK_OF_YEAR", new Integer(DateFormat.WEEK_OF_YEAR_FIELD));
        dateFieldHash.put("YEAR", new Integer(DateFormat.YEAR_FIELD));
 *
 */