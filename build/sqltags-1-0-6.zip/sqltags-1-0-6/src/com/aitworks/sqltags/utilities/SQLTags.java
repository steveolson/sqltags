/* $Id: SQLTags.java,v 1.81 2003/11/13 03:42:48 solson Exp $
 * $Log: SQLTags.java,v $
 * Revision 1.81  2003/11/13 03:42:48  solson
 * added init() method for tag caching/pooling (not working yet)
 *
 * Revision 1.80  2003/11/12 20:30:03  solson
 * some cleanup on SQLTags (removed unused variables)
 * moved output from doFinally to doAfterBody ... should work ..
 * added bodyContent.clearBody() call to cleanup output for pooled tags
 *
 * Revision 1.79  2003/11/07 20:27:13  solson
 * changed login on execute vs executeQuery is sql string starts with select we
 * use executeQuery otherwise we use execute.
 *
 * Revision 1.78  2003/10/26 06:00:12  solson
 * suport for tableAlias v1 may need some additional tweaking
 *
 * Revision 1.77  2003/10/01 16:02:00  solson
 * added getColumnNames() Enumeration and getColumn() for access by JSTL
 * added getCause() to setException's log message
 *
 * Revision 1.76  2003/09/26 19:00:46  solson
 * added some log.fine() statements ...
 *
 * Revision 1.75  2003/09/24 14:48:05  solson
 * added "SQLTags." prefix to the bindStrings property
 *
 * Revision 1.74  2003/06/18 21:25:06  solson
 * fixed problem w/ getBindColumns which parses SQL statments for : variables and
 * associates them with corresponding SQLTagsColumn --or-- from the servletRequest.
 *
 * Revision 1.73  2003/06/17 18:02:14  solson
 * fixed clear after delete; cleared all arrayIndexes for all rows.  Now clear() only clears
 * the current row, based on arrayIndex.
 *
 * Revision 1.72  2003/06/14 00:22:24  solson
 * fixed situation where we have table_name prefix but not array syntax.  now both cases
 * work as expected.
 *
 * Revision 1.71  2003/06/04 12:59:05  solson
 * added table alias to delete statement
 *
 * Revision 1.70  2003/05/31 02:44:17  solson
 * changed preparedStatement.setDate() for DATE/TIME/TIMESTAMPS to
 * preparedStatement.setTimeStamp() ... to keep from clobbering hours/minutes/seconds
 *
 * Revision 1.69  2003/05/30 00:56:11  solson
 * wrapped getString() result in nvl( getter, "") to ensure it always returns NON NULL value
 * wanted to do similar to getDate and getNumber; however, what should we use in place
 * of null? ... date would be now ... number would be 0 perhaps ... so left those two null
 *
 * Revision 1.68  2003/05/22 18:11:11  solson
 * updated logging
 *
 * Revision 1.67  2003/05/17 03:24:17  solson
 * Major rewrite to support replacement of ColumnProperties with SQLTagsColumns;
 * which now supports native DATE, TIME, TIMESTAMP, and NUMBER conversions
 * in Java and not in the database queries.
 *
 * Revision 1.66  2003/03/20 14:41:57  solson
 * fixed replace of column_name to add table alias as getId() ... was replacing the "AS COLUMN" part incorrectly
 *
 * Revision 1.65  2003/03/19 21:32:08  jpoon
 * fix bug with prefix
 *
 * Revision 1.64  2003/03/19 15:51:44  jpoon
 * add from in sqltags
 *
 * Revision 1.63  2003/02/25 19:57:06  solson
 * added support for "deleteChildren" operation
 *
 * Revision 1.62  2003/01/20 21:57:48  solson
 * added setBeanProperties() method to allow page, request, session, and application
 * java beans to be used to set a tag's column properties (COLUMNS) and Foreign Keys.
 * This method will be overridden by specific methods in the generated table classes.
 *
 * Revision 1.61  2002/11/11 20:31:27  jpoon
 * change ConnectionTag as parameters and class variable
 * to super class SQLTagsConnection
 *
 * Revision 1.60  2002/11/08 17:58:19  solson
 * fixed bug in BIND parsing
 *
 * Revision 1.59  2002/10/18 04:38:52  solson
 * fixed classCastException in sqlFetch
 *
 * Revision 1.58  2002/10/18 04:19:52  solson
 * minor cleanup of ExecuteSQL exception output (again)
 * and, minor changes to bind variable logic
 *
 * Revision 1.57  2002/10/18 03:01:59  solson
 * Several changes:
 * 1- removed logException
 * 2- Cleanup of ExecuteSQL exception reporting
 * 3- Added support for "BaseTable" columnProperties
 * 4- Cleanup of update() method
 * 5- Bind columns can use either non-baseTable items added to the current
 *     table via matching tablenames, or from request Parameters.  So we can
 *    now use "where ename like :SRCH" where :srch is a request parameter
 * 6- Added support for "Table.Column[array]" naming within setRequestProperties
 *    can use either no prefix or can use the tablename to avoid conflicts between
 *    columns with same name in different tables; however it is usually the same
 *    value when the do show up (as foreign keys) ..
 * 7- Added support for "tableAliases"; but not completely implemented
 *
 * Revision 1.56  2002/10/17 01:54:39  solson
 * added support for operation="loop" which allows a SQLTag Tag to loop
 * over the items submitted in an Array within the RequestObject
 *
 * Revision 1.55  2002/10/16 21:31:20  jpoon
 * fix Boolean value in setColumnProperty for "value"
 *
 * Revision 1.54  2002/10/16 19:49:16  solson
 * added "ignoreArrayIndex" and "type" features to setColumnProperty
 *
 * Revision 1.53  2002/10/15 20:05:51  jpoon
 * fix delete to use bind variables
 * fix columnName to all uppercase in setRequestParameters
 *
 * Revision 1.52  2002/09/16 13:59:44  jpoon
 * added nvl
 *
 * Revision 1.51  2002/08/16 15:46:13  jpoon
 * little fix for start row
 *
 * Revision 1.50  2002/08/13 18:00:20  jpoon
 * fix bug in fetch,
 * check startRow for null and "" first before parseInt
 *
 * Revision 1.49  2002/08/07 15:13:10  jpoon
 * re-construct connection manager
 *
 * Revision 1.48  2002/07/24 19:16:48  jpoon
 * fix paging
 *
 * Revision 1.47  2002/07/17 19:23:58  solson
 * cleaned up the Handler calls.  Modified calls to the handler class and fixed
 * parameters to class ... changed parameter from "Object" to "SQLTags"
 *
 * Revision 1.46  2002/07/03 15:04:43  jpoon
 * comment out
 * System.out.println("Skipping bind: "+key);
 *
 * Revision 1.45  2002/07/02 19:10:21  jpoon
 * change SQLTagsRequest to HttpServletRequest
 *
 * Revision 1.44  2002/06/27 13:33:17  jpoon
 * take getID() from select(String )
 *
 * Revision 1.43  2002/06/26 17:41:54  solson
 * added getId() after tableName in select(where) so alias name can be
 * used in _SELECT, _BIND, and where definitions
 *
 * Revision 1.42  2002/06/25 18:57:36  solson
 * changes for SQLTagsRequest (HttpServletRequest instead of ServletRequest)
 * also added pass-thru calls for most of the httpServletRequest calls for
 * convience
 *
 * Revision 1.41  2002/06/25 16:05:53  jpoon
 * fix paging code
 *
 * Revision 1.40  2002/06/24 23:17:04  jpoon
 * add getConnectionTag
 *
 * Revision 1.39  2002/06/20 19:34:54  solson
 * added exception to setException, added exception to setException(event)
 *
 * Revision 1.38  2002/06/13 19:20:46  jpoon
 * add pageContext to SQLTagsHandler
 *
 * Revision 1.37  2002/05/30 19:47:02  jpoon
 * Changes for MimeData
 *
 * Revision 1.36  2002/05/23 15:51:11  solson
 * removed all references to caching implementation
 *
 * Revision 1.35  2002/05/21 12:36:06  booker
 * final checkin of sqltags
 *
 * Revision 1.34  2002/05/16 18:01:12  booker
 * format change.
 *
 * Revision 1.33  2002/05/16 14:23:03  booker
 * added method getSQLTagRequesParameter() to retrieve
 * a parameter from the SQLTagsRequest object.
 *
 * Revision 1.32  2002/04/23 21:39:20  booker
 * menuing changes
 *
 * Revision 1.31  2002/04/20 16:44:44  booker
 * added method
 *
 * Revision 1.30  2002/04/15 18:07:16  booker 
 * Removed the following methods:
 * 	setPreparedStatementBindColumns()
 * 	haveLOBS()
 * Changed the following methods to private:
 * 	getBindColumns()
 * 	getColumnNameSelectList()
 * 	getCommaString()
 * 	isSelectStatement()
 * 	getPreviousStartPosition()
 * 	getPreviousRow()
 * 	readClobBlobLong()
 * 	setStopRow()
 * 	setCurrentRow()
 * 	updateColumnPropertiesHash()
 * 	updateArray()
 *
 * Revision 1.29  2002/04/15 17:03:41  booker
 * Removed the following methods:
 * 	writeErrorToSDTOUD()
 * 	getCurrentVectorKeysSize()
 * 	getDebug()
 * 	getDefaultDateFormat()
 * 	getOutput()
 * 	getSaveColumn()
 * 	setDefaultDateFormat()
 * 	setOutput()
 * 	setSaveHash()
 * 	setSelectHash()
 * Changed the sope of the following methods to private:
 * 	isColumnTypeValid()
 * 	isData()
 * 	getColonString()
 *
 * Revision 1.28  2002/04/10 17:36:52  booker
 * Modifed code to work with the binding of values
 * to the column properties object.
 *
 * Revision 1.27  2002/04/05 18:52:59  booker
 * Modified creation of sqlTagHandler within the
 * setHandlerClass() and getSQLTagsHandler() methods.
 *
 * Revision 1.26  2002/04/05 00:05:02  solson
 * removed debugging output in two places
 *
 * Revision 1.25  2002/04/04 22:36:00  solson
 * removed requirement to have a '?' character in the _BIND string.  If the '?' is
 * missing, then we don't attempt to bind the value for that column-- we assume
 * that a constant expression like SYSDATE or EMPTY_CLOB() is used instead.
 *
 * Revision 1.24  2002/04/03 16:55:36  booker
 * Added a getObject(String) wrapper for the
 * columnPropertiesHash.
 *
 * Revision 1.23  2002/04/03 14:49:23  booker
 * Worked on adding Object to ColumnProperties.
 *
 * Revision 1.22  2002/03/28 18:09:39  booker
 * Added getException(JspWriter) method
 *
 * Revision 1.21  2002/03/15 14:33:31  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.utilities;  
import  com.aitworks.sqltags.jsptags.ConnectionTag;
import com.aitworks.sqltags.interfaces.IExceptionHandler;  
import java.util.Arrays;  
import java.util.ArrayList;  
import java.util.Hashtable;  
import java.util.Vector;  
import java.util.Enumeration;  
import java.util.Properties;
import java.io.ByteArrayInputStream;  
import java.io.InputStream;  
import java.io.IOException;  
import java.io.StringReader;
import java.io.Reader;
// import java.sql.Blob;  
// import java.sql.Clob;  
import java.sql.Date;
import java.sql.ResultSet;  
import java.sql.Statement;  
import java.sql.Connection;  
import java.sql.PreparedStatement;  
import java.sql.SQLException;  
import java.sql.ResultSetMetaData;  
import java.sql.Types;
import javax.servlet.ServletContext;  
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.JspWriter;
import javax.servlet.ServletException;
import javax.servlet.jsp.JspException;
import java.util.logging.Logger;
import java.math.BigDecimal;
  
/**
 * <code>SQLTags</code>
 * <p>
 * The primary class for SQLTags generated tables and generic
 * cursors.
 * </p>
 * @author Steve Olson
 * @version 1.0
 * @since 1.3
 */  
//------------------------------------------------------------------------------  
public class SQLTags 
    extends BodyTagSupport 
    implements IExceptionHandler
{
    //--------------------------------------------------------------------------
    // Class Properties
    private static Logger log = Logger.getLogger("com.aitworks.sqltags.utilities.SQLTags");
   
   //***************************************************************************  
   //                      Class variable section  
   //***************************************************************************  
   private boolean            anyRecords=false;  
   private Hashtable          arrayIndexHash=new Hashtable(); // unique list of Array Index values
   private String             arrayIndex="0";                 // current array Index
   protected Enumeration      arrayIndexEnumeration = null; // array Enumeration for LOOP operation
   private Vector             bindColumnVector=new Vector();  
   private String             caching="false";  
   private String             cacheSize="0";  
   private String             cacheScheme="default";  
   private String             childName="";  
   private SQLTagsColumns     sqlTagsColumns = new SQLTagsColumns(); // replacement for columnProperties
   private String             columns="";  
   protected SQLTagsConnection sqlTagsConnection=null;
   private String             currentPage="1";  
   private int                currentRow=0;  
   private String             displayPageSize="";
   private String             distinct="false";
   protected int                depth=0;  
   private   Exception        exception;  
   private boolean            firstRecord=false;  
   private String             foreignKey="";  
   private String             handlerClass="";  
   private String             handlerID="";  
   private boolean            hasFetch=false;  
   private Utilities          utilities=new Utilities();  
   private int                itemDisplayCount=0;  
   private boolean            lastRecord=false;  
   private int                maxInt=Integer.MAX_VALUE;  
   private String             maxRows=Integer.MAX_VALUE+"";  
   private boolean            multipleOpen=false;  
   private Hashtable          operationHash=new Hashtable();
   private String             operationName="OPERATION";
   private String             orderBy="";  
   private String             pageSize="";  
   private String             paging="false";  
   private String             parentName="";  
   private String             preInsertSQL="";  
   private PreparedStatement  ps=null;  
   private String             preUpdateSQL="";  
   protected Vector             primaryKeyVector=new Vector();  
   private String             properties="false";  
   protected ResultSet        resultSet;  
   private int                resultSetSize=0;
   private PreparedStatement  selectPreparedStatement;  
   private String             sql="";  
   private SQLTagsHandler     sqlTagHandler=new SQLTagsHandler();  
   private HttpServletRequest sqlTagRequest;
   private String             startPage="1";  
   private String             startRow="0";  
   protected String             tableName="SQLTags";
   private String             where="";  
   private String             from="";  
   private String             startRowParameter="startRow";
   private String             tableAlias="";
    
   // ************************************************************************
    // Old properties ... purging ... 
   // private Hashtable            asciiStreamTypes=new Hashtable(); // 
   // private Hashtable            binaryStreamTypes=new Hashtable();
   // private Hashtable            cacheHashtable=new Hashtable();  
   // private String               cacheItemQuery="";  
   // protected StringBuffer       cacheQuery=new StringBuffer();  
   // private Hashtable            cacheVectorHash=null;  
   // private String               cacheVectorQuery="";  
   // private Hashtable            characterStreamTypes=new Hashtable();
   // protected Connection         connection=null;  //Cursor needs this!
   // private ArrayList           currentVectorKeys=new ArrayList();  
   // private final static int     DEFAULT=1;  
   // private final static int     DISK=3;  
   // private String             debug="1";  
   // private StringBuffer       emptyLobs=new StringBuffer();  
   // private boolean            haveLob=false;  
   // private boolean            insertingRecords=false;  
   // private StringBuffer       keyQuery=new StringBuffer();  
   // private StringBuffer       knownLobs=new StringBuffer();  
   // private String             output="";  
   // protected Object[]           pkValueArray=null;  
   // private   int                previousCacheIndex=0;  
   // private final static int     RAM=2;  
   // private SessionCache         sessionCache=null;  
   // private SQLActionEvent       sqlEvent=new SQLActionEvent();
   // private Hashtable            sqlTagsColumnHash = new Hashtable();
   // private int                  totalReadFromCache=0;  
   // protected static int         totalSelected=0;  
   // private Vector             asciiStreamColumns=new Vector(); // list of data types that require ascii Stream
   // private Vector             binaryStreamColumns=new Vector();
   // private Blob               blob=null;  
   // private Vector             characterStreamColumns=new Vector();
   // private Clob               clob=null;  
   // private Hashtable          columnPropertiesHash=new Hashtable();  
   // private boolean            firstRecordOnPage=false;  
   // private String             id="";  
   // private boolean            lastRecordOnPage=false;  
   // private Hashtable          lobHash=new Hashtable();  
   // private int                nextLink=0;  
   // private int                previousStartPosition=0;  
   // private int                prevLink=0;  
   // private String             primaryKeys="";  
   // private int                stopRow=4;  
   // private Statement          stmt;  
   // private String             useTableAlias="false";
   
  //***************************************************************************  
   // Class Constructors  
   //***************************************************************************  
    /** <code>Default Constructor</code>
     * <p>creates an instance of SQLTags</p>
     */  
   //---------------------------------------------------------------------------  
   public SQLTags(){  
   //---------------------------------------------------------------------------  
   }//sqlTags() ENDS
   
   public SQLTags(String id, SQLTagsConnection con) {
       setId(id);
       sqlTagsConnection = con;
   }
   
   
     
   /** Getter for columnPropertiesHash
    * @return Hashtable
    */   
   // public Hashtable getColumnPropertiesHash(){return columnPropertiesHash;}
   // public Vector getPrimaryKeyVector(){return primaryKeyVector;}
   public String getTableName(){return this.tableName;}
   public void setTableName(String t){this.tableName=t;}
   public void setFKParent(int depth){setDepth( Integer.toString(depth));}
   
   //***************************************************************************  
   // Public Methods  
   //*************************************************************************** 
   /**  
    * <code>addArrayIndex</code>  
    * <p>  
    * Internal function to keep track of arrayIndexes during processing of 
    * request parameters when "properties=true"
    * </p>  
    */  
   //---------------------------------------------------------------------------  
   protected void addArrayIndex(String arrayIndex){
   //---------------------------------------------------------------------------  
       arrayIndexHash.put(arrayIndex,arrayIndex);
   }//addArrayIndex() ENDS
   
   /**  
    * <code>clear</code>  
    * <p>  
    * This method resets the columns to empty strings.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param  <code>none</code>  
    * @return <code>none</code>  
    */  
   //---------------------------------------------------------------------------  
   public void clear(){  
   //---------------------------------------------------------------------------  
       sqlTagsColumns.clearValues(getArrayIndex());
       /**
      Enumeration enum=columnPropertiesHash.keys();  
      for(;enum.hasMoreElements();){  
         String key=(String)enum.nextElement();  
         setColumnProperty( "value", key, "" );
      }  
        */
   }// clear() ENDS  
     
   /**  
    * <code>close</code>  
    * <p>  
    * This method closes the result set and the statement.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code>  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void close(){  
   //---------------------------------------------------------------------------  
      try{  
         isOpen(false);             
         // sqlTagHandler=getSQLTagsHandler();  
           
         if(!sqlTagHandler.postQuery(this)){  
            ;  
         }  
         
         if(selectPreparedStatement!=null)  
            selectPreparedStatement.close();  
           
         if(ps!=null)  
            ps.close();  

      }  
      catch(SQLException exception){  
         setException(exception);  
         log.warning("Exception in close(): "+exception);
      }          
   }// close() ENDS  
   
   /**  
    * <code>delete</code>  
    * <p>  
    * This method will remove records from the database.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code></code>  
    * @return true <code>boolean</code> true, if everything went ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean delete(){  
   //---------------------------------------------------------------------------  
       return delete("where "+ getColonString("delete",","));  
   }
   
   /**  
    * <code>delete</code>  
    * <p>  
    * This method will remove records from the database based on a where
    * supplied by the user.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none where<code>String</code>  the where clause.
    * @return true <code>boolean</code> true, if everything went ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean delete(String where){
   //---------------------------------------------------------------------------  
      boolean returnValue=true;  
      // sqlTagHandler=getSQLTagsHandler();  
      String sqlQuery = "delete from " +getTableName() + " " + getTableAlias() + " " + where;
        
      if(!sqlTagHandler.preDelete(this))  
         returnValue=false;  
      else{  
         returnValue = executeSQL(sqlQuery,true);  
         if(returnValue){
             if(!sqlTagHandler.postDelete(this))  
                returnValue=false;  
         }
         if(returnValue)
            clear();  
      }  
        
      return returnValue;  
   }// delete() ENDS  
   
   /**  
    * <code>deleteArray</code>  
    * <p>  
    * This method will remove records within the arrayIndex.
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none where<code>String</code>  the where clause.
    * @return true <code>boolean</code> true, if everything went ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean deleteArray(){
   //---------------------------------------------------------------------------  
       Enumeration arrayIndexes = getArrayIndexes();
       
       while(arrayIndexes.hasMoreElements()){
           String arrayIndex = (String) arrayIndexes.nextElement();
           setArrayIndex( arrayIndex );
           
           if(!delete()){
               log.warning("DeleteArray Failed on index="+arrayIndex);
               return false;
           }
       }
       
       return true;
   }//deleteArray ENDS
           
   /**  
    * <code>getArrayIndexes</code>  
    * <p>  
    * This method returns the current array index.
    * </p>  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return value <code>String</code> the array index.
    */  
   //---------------------------------------------------------------------------  
   public String getArrayIndex(){
   //---------------------------------------------------------------------------  
       return arrayIndex;
   }//getArrayIndex() ENDS   
   
   /**  
    * <code>getArrayIndexes</code>  
    * <p>  
    * This method is used in conjunction with batch processing.
    * </p>  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return enum <code>Enumeration</code>an enumeration of the current index.  
    */  
   //---------------------------------------------------------------------------  
   public Enumeration getArrayIndexes(){
   //---------------------------------------------------------------------------  
       return arrayIndexHash.keys();
   }//getArrayIndexes() ENDS
   
   /**  
    * <code>getArrayInputName</code>  
    * <p>  
    * This method return the array input name.
    * </p>  
    * @version 1.0  
    * @since   1.3  
    * @param  columnName<code>String</code> the column name.
    * @return columnName<code>String</code> the array input name
    */  
   //---------------------------------------------------------------------------  
   public String getArrayInputName(String columnName){
   //---------------------------------------------------------------------------  
       return getArrayInputName(columnName,getArrayIndex());
   }//getArrayInputName() ENDS
   
   
   /**  
    * <code>getArrayInputName</code>  
    * <p>  
    * This method return the array input name formatted.
    * </p>  
    * @version 1.0  
    * @since   1.3  
    * @param  columnName<code>String</code> the column name.
    * @param  arrayIndex<code>String</code> the array index.
    * @return columnName<code>String</code> the formatted column name.
    */  
   //---------------------------------------------------------------------------  
   public String getArrayInputName(String columnName,String arrayIndex){
   //---------------------------------------------------------------------------  
       return columnName + "[" + arrayIndex + "]";
   }//getArrayInputName() ENDS

   /**  
    * <code>disectQuerySting</code>  
    * <p>  
    * This method returns a portion of the query string.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param  query<code>String</code>the query to disect.  
    * @param  keyWord<code>String</code>the word were looking for.  
    * @param  quotes<code>boolean</code>true if quotes are to be considered.,  
    * @return results <code>String</code>a portion of the query string.  
    */  
   
   /**
   //---------------------------------------------------------------------------  
   public String disectQueryString(String query,String keyWord,boolean quotes){  
      //---------------------------------------------------------------------------  
      String results="";  
      int index=0;  
      int start=0;  
      int stop=query.length();  
      boolean positionFound=false;  
        
      while(!positionFound){  
         index=query.indexOf(keyWord,start);  
           
         if(index!=-1){  
            if(quotes){  
               int beginQuote=index-1;  
               int endQuote=index+keyWord.length();  
                 
               while(query.charAt(beginQuote)==' '&&beginQuote>=0)  
                  beginQuote=beginQuote-1;  
                 
               if(beginQuote>=0&&query.charAt(beginQuote)!='\'')  
                  positionFound=true;  
                 
               if(positionFound){  
                  positionFound=false;  
                    
                  while(query.charAt(endQuote)==' '&&endQuote<stop)  
                     endQuote=endQuote+1;  
                    
                  if(endQuote<stop&&query.charAt(endQuote)!='\''){  
                     positionFound=true;  
                       
                     if(keyWord.equalsIgnoreCase("where"))  
                        results=query.substring(0,index);  
                     else  
                        results=query.substring(index,query.length());  
                  }  
               }  
            }  
            else{  
               results=query.substring(index,query.length());  
               positionFound=true;  
            }  
         }  
         else  
            positionFound=true;  
           
         start=index+1;  
      }  
        
      return results;  
   }// disectQueryString() ENDS  
    *
    */
   
   public boolean doArrayOperations() {
       // where is set by parentName=p and foreignKey=fk; and operation="deleteChildren"
       // ... this mechanism is handy for maintaining certain master-detail relationships ...
       // 
       if( !getWhere().equals("") && operationHash.containsValue("deleteChildren")) {
           if( !delete( getWhere() ) ) {
               log.warning("doArrayOperation: deleteChildren failed");
               return false;
           }
       }
       
       Enumeration arrayLoop = operationHash.keys();
       while( arrayLoop.hasMoreElements() ){
           String arrayIndex = (String)arrayLoop.nextElement();
           setArrayIndex(arrayIndex);
           String operation = getOperation(arrayIndex);
           
           log.finer("doArrayOperations["+arrayIndex+"] = " + operation);
           
           if( operation.equalsIgnoreCase("insert")) {
               if( !insert()) {
                   log.severe("doArrayOperations: insert failed at "+arrayIndex+", aborting operation.");
                   return false;
               }
           } 
           else if( operation.equalsIgnoreCase("update")){
               if(!update()) {
                   log.severe("doArrayOperations: update failed at "+arrayIndex+", aborting operation.");
                   return false;
               }
           }
           else if( operation.equalsIgnoreCase("delete")){
               if(!delete()) {
                   log.severe("doArrayOperations: delete failed at "+arrayIndex+", aborting operation.");
                   return false;
               }
           }
           else if( operation.equalsIgnoreCase("select")){
               initialize(getDepth());
           }
           else if( operation.equalsIgnoreCase("loop")){
               arrayIndexEnumeration = getArrayIndexes();
           }
           else {
               log.finer("doArrayOperations: unknown-op at "+arrayIndex+" operation = "+operation);
           }
       }
       log.finer("doArrayOperations completed successfully"); // imagine that!
       return true;
   }// doArrayOperations() ENDS
     
   /**  
    * <code>executeSQL</code>  
    * <p>  
    * This method sets the current sql statement associated with this object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param sql <code>String</code> the sql statement.  
    * @return none <code></code>  
    */  
   //---------------------------------------------------------------------------  
   public boolean executeSQL(String sql,boolean autoCommit) {  
   //---------------------------------------------------------------------------  
      String key="";  
      setSql(sql);  
      log.fine("executeSQL:SQL:\n"+sql);
      int vectorSize=0;  
      boolean openValue=true;  
      boolean selectStatement=false;  
      Connection connection=null;
      // first we have to bind our columns to their respective formats.
      sql=getBindColumns(sql);  
      
      // if we dont have a connection. bail out.
      try{
          connection=getConnection();
      } 
      catch(JspException exception){
          setException(exception);
          log.warning("ExecuteSQL: Failed to obtain connection:" +exception);
          return false;
      }
      
      //make sure we know how how to read the various LOB types.
      // setColumnTypes();      
      log.fine("Connection is: " + connection);

      try{
          if(connection.isClosed()){
             // set the exception and let it blow out on the page.
              Exception exception=
                  new Exception("Failed to obtain open connection.");
              setException(exception);
          }
      } 
      catch(SQLException exception){
          log.severe("executeSQL: Exception on isClosed(): " + exception);
          //set the exception and let it blow out on the page.
          setException(exception);
      }

      try{ 
         //turn auto-commit off if thats what the tag requested.
         if(!autoCommit)  
            connection.setAutoCommit(false);  
 
         //are we doing a select?
         if(isSelectStatement(sql)){  
            selectStatement=true;  
            selectPreparedStatement=connection.prepareStatement(sql,  
               ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE  
            );                
            ps=selectPreparedStatement;  
            
            //a flag to prevent multiple opens of the same cursor.
            isOpen(true);  
         }  
         else  {
            ps=connection.prepareStatement(sql,  
               ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);  
         }

         log.finer("executeSQL: sql: " + sql);

         //do we have any bind columns?
         if(bindColumnVector!=null)  
            vectorSize=bindColumnVector.size();  
         
         int position=0;
         
         String bindStrings = getProperty("SQLTags.bindStrings",getProperty("bindStrings","false"));
         
         //place the bind values in the prepared statement.
         for(int index=0;index<vectorSize;index++){  
            key=((String)bindColumnVector.elementAt(index)).toUpperCase();  
            SQLTagsColumn col = sqlTagsColumns.get(key);
            if( col == null) {
                // In theory this shouldn't happen 'cause the build Bind
                // routine should stuff the bind vector with non-basetable
                // fields if it can't find a bind variable
                log.severe("Internal Error: cannot find BIND variable: " + key);
                throw new SQLException("Internal Error, Missing BIND variable: " + key);
            }
            String type = col.getType();
            String bind = col.getBindFormat();
            int sqlType = col.getSqlType();
            
            if( bind.indexOf("?") == -1) {
                log.fine("Constant BIND value: " + key);
                continue;
            }
            
            // only increment position after seeing the ? ... 
            position++;
            
            if(sqlType==Types.BLOB || sqlType==Types.LONGVARBINARY ) {
                String value = nvl( col.getValue(getArrayIndex()), "");
                int length = value.length();
                InputStream inputStream = new ByteArrayInputStream(value.getBytes());
                ps.setBinaryStream(position, inputStream, length);
            } else if(sqlType==Types.CLOB || sqlType==Types.LONGVARCHAR) {
                String value = nvl( col.getValue(getArrayIndex()), "");
                int length = value.length();
                StringReader reader = new StringReader( value );
                ps.setCharacterStream(position, reader, length);
            } else if ( type.equalsIgnoreCase("DATE") 
                   || type.equalsIgnoreCase("TIME") 
                   || type.equalsIgnoreCase("TIMESTAMP")) 
            {
                if( bindStrings.equalsIgnoreCase("true")) {
                    log.fine(key+":binding DATE As STRING");
                    ps.setString(position, col.getValue(getArrayIndex()));
                } else {
                    log.finest(key +":binding a " + type + " = " + col );
                    java.util.Date d = col.getValueDate(getArrayIndex());
                    if( d == null) {
                        // this is likely bad user input, let's try as a STRING ...
                        log.fine(key + ":Cannot find BIND value as DATE (trying as STRING)");
                        String s = col.getValue(getArrayIndex());
                        if( s == null) {
                            log.severe("Cannot BIND, aborting: "+ key );
                            throw new SQLException("Cannot BIND: "+ key);
                            // that's it! .. otta here can't skip BIND variable gotta puke
                        }
                        ps.setString(position,s);
                        // well this worked; however, we can likely expect a DB error soon :)
                    } else {
                        ps.setTimestamp(position,new java.sql.Timestamp( d.getTime()) );
                    }
                }
            }
            else if ( type.equalsIgnoreCase("NUMBER") ) {
                if( bindStrings.equalsIgnoreCase("true")) {
                    log.fine(key+":binding NUMBER As STRING");
                    ps.setString(position, col.getValue(getArrayIndex()));
                } else {
                    log.finest(key +":binding a " + type + " = " + col );
                    Number n = col.getValueNumber(getArrayIndex());
                    log.finest(key +":binding done.");
                    if( n == null) {
                        log.fine(key +":Can't find a Number for BIND at " +getArrayIndex() +", using String" );
                        ps.setString(position,col.getValue(getArrayIndex()));
                    } else {
                        try {
                            ps.setBigDecimal(position,new BigDecimal(n.toString()));
                        } catch( NumberFormatException ex) {
                            log.warning(key +":exception creating BigDecimal for " + col + ": " +ex);
                            ps.setString(position,col.getValue(getArrayIndex()));
                        } catch( Exception ex2) {
                            log.warning(key +":exception creating BigDecimal for " + col + ": " +ex2);
                            ps.setString(position,col.getValue(getArrayIndex()));
                        }
                    }
                }
            } else {
                log.finest(key +":binding a " + type + " = " + col );
                // setString(ps,getColumnValue(key),position);
                ps.setString(position,col.getValue(getArrayIndex()));
            }
         }
         log.finer("executeSQL: binding done.");
         if(selectStatement){
            resultSet=ps.executeQuery();  
            resultSet.last();
            resultSetSize=resultSet.getRow();
            resultSet.beforeFirst();
         }
         else  {
             if( !sql.trim().toLowerCase().startsWith("select")){
                 ps.execute();
                 ps.close();
             } else {
                 // not sure about this one ... 
                 ps.executeQuery();
             }
         }
        log.finer("executeSQL: execute done.");
      }  
      catch(SQLException exception){
         close();
         setException(exception);
         openValue=false;
         
         log.severe("ExecuteSQL SQLException pt 1: " + exception);
         log.severe("ExecuteSQL SQLException pt 2: " + sql);
         log.severe("ExecuteSQL SQLException pt 3: " + getSQLTagsColumns());
      }
      log.finer("executeSQL: done.");
      return openValue;  
   }// executeSQL() ENDS  
     
   /**  
    * <code>executeSQL</code>  
    * <p>  
    * This method sets the current sql statement associated with this object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param sql <code>String</code> the sql statement.  
    * @return none <code></code>  
    */  
   //---------------------------------------------------------------------------  
   public boolean executeSQL(){  
   //---------------------------------------------------------------------------  
      return executeSQL(sql,true);  
   }// executeSQL() ENDS  
     
   /**  
    * <code>fetch</code>  
    * <p>  
    * This method fetches records returned from the database.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return true <code>boolean</code> if there are more records.  
    */  
   //---------------------------------------------------------------------------  
   public boolean fetch(){  
   //---------------------------------------------------------------------------  
       log.finer("Entering fetch()");
       int begin=0;
       int mod=0;
       int lastItemInCursor=maxInt;
       boolean oneMoreRecord=false;
       boolean hasMore=false;
       isData(false);
       // setColumnTypes();
       
       // get the row to display.
       try{
           if(getStartRow()!=null && !getStartRow().equals(""))
               begin=Integer.parseInt(getStartRow());
           else {
               begin=0;
               startRow=0+"";
           }
       }
       catch(NumberFormatException exception){
           begin=0;
           startRow=0+"";
           log.warning("fetch(): " + exception);
       }
       
       if(!isOpen()){
           hasMore=false;
       }
       else{
           try{
               log.finer("fetch: attempting getRow(): begin="+begin+", currentRow="+currentRow);
               // set the cursor on the row to display.
               currentRow=resultSet.getRow(); // == 0 before first fetch
               if(currentRow<begin){
                   do {
                       resultSet.next();
                       currentRow=resultSet.getRow();
                   } while(currentRow<begin && currentRow>0);
               }
               
               /**
                *  Since we fetch the record before we can process it, I need
                * to be able to know, before hand, whether or not the current
                * record is the last record.
                */
               if(currentRow!=0){
                   log.finer("fetch: checking for lastRow");
                   resultSet.last();
                   lastItemInCursor=resultSet.getRow()-1;
                   resultSet.absolute(currentRow);
               }
               
               log.finer("fetch: setting last, first");
               // indicate whether this is the first/last record in the set.
               setLastRecord(resultSet.isLast());
               setFirstRecord(resultSet.isFirst());
               
               if(currentRow!=0){
                   isData(true);
                   mod=(currentRow%utilities.stringToInt(pageSize));
                   
                   if(mod==0){
                       oneMoreRecord=true;
                       setFirstRecord(true);
                   }
                   else {
                       setFirstRecord(false);
                   }
               }
               else {
                   setFirstRecord(true);
               }
               log.finer("fetch: OK, finally ready to fetch a row");
               if(resultSet.next()){
                   log.finer("fetch: whew, fetch succeeded!");
                   sqlTagsColumns.clearValues(getArrayIndex());
                   
                   isData(true);
                   setLastRecord(resultSet.isLast());
                   hasMore=true;
                   sqlTagsColumns.set(resultSet, arrayIndex);
                   /**
                    *
                   clear();
                   String value="";
                   // Enumeration enum=columnPropertiesHash.keys();
                   Enumeration enum=sqlTagsColumns.keys();
                   
                   // update the column properties
                   for(;enum.hasMoreElements();){
                       String key = (String)enum.nextElement();
                       SQLTagsColumn col = sqlTagsColumns.get(key);
                       if( !col.isBaseTable()) {
                           continue;
                       }
                       col.setObject(resultSet.getObject(key)); // every time ?
                       try {
                           if(isColumnTypeValid(asciiStreamColumns,col.getType())) {
                               // readClobBlobLong(key);
                               col.setValue( resultSet.getAsciiStream(key) );
                           }
                           else if(isColumnTypeValid(binaryStreamColumns,col.getType())) {
                               // readClobBlobLong(key);
                               col.setValue( resultSet.getBinaryStream(key));
                           }
                           else if(isColumnTypeValid(characterStreamColumns,col.getType())) {
                               // readClobBlobLong(key);
                               col.setValue( resultSet.getCharacterStream(key));
                           }
                           else{
                               if(resultSet.getString(key)!=null){
                                   col.setValue(resultSet.getString(key));
                               }
                           }
                       }
                       catch(IOException exception){
                           log(getTableName()+".fetch(): "+getSql()+"\n"+exception);
                           close();
                       }
                   }
                    *
                    */
                   
                   setFKParent();
                   
                   if(oneMoreRecord) {
                       setLastRecord(true);
                   }
                   
                   int intDisplaySize=getPageSize();
                   int stopRow=begin+intDisplaySize;
                   
                   if(currentRow==stopRow-1) {
                       setLastRecord(true);
                   }
                   else {
                       setLastRecord(false);
                   }
                   
                   if(currentRow==stopRow&&paging.equalsIgnoreCase("true")){
                       setLastRecord(true);
                       
                       while((currentRow%intDisplaySize)!=0) {
                           currentRow++;
                       }
                       
                       setCurrentRow(currentRow);
                       startRow=currentRow+"";
                       
                       hasMore=false;
                       close();
                   }
               }
               else {
                   close();
               }
               
               if(currentRow>=lastItemInCursor){
                   setLastRecord(true);
                   isData(false);
               }
               
               // sqlTagHandler=getSQLTagsHandler();
               
               if(!sqlTagHandler.postFetch(this)) {
                   hasMore=false;
               }
               
           }
           catch(SQLException exception){
               close();
               setException(exception);
               log.warning("Exception in fetch(): "+ exception );
               hasMore=false;
           }
       }
       log.finer("fetch: done." );
       return hasMore;
   }// fetch() ENDS
   
   /**
    * <code>getFormat</code>
    * <p>gets format</p>
    * @param name column name 
    * @return returns String representatio of format string
    */
   public String getFormat(String name) {
       return sqlTagsColumns.getFormat(name);
   }
   /**
    * <code>setFormat</code>
    * <p>sets  format</p>
    * @param name column name 
    * @param Format format for bind string
    * @return none
    */
   public void setFormat(String name, String format) {
       sqlTagsColumns.setFormat(name,format);
   }
   /**
    * <code>getSelectFormat</code>
    * <p>gets Select format</p>
    * @param name column name 
    * @return returns String representatio of select string
    */
   public String getSelectFormat(String name) {
       return sqlTagsColumns.getSelectFormat(name);
   }
   /**
    * <code>setSelectFormat</code>
    * <p>sets select format</p>
    * @param name column name 
    * @param bindFormat format for select string
    * @return none
    */
   public void setSelectFormat(String name, String format) {
       sqlTagsColumns.setSelectFormat(name,format);
   }
   
   /**
    * <code>getBindFormat</code>
    * <p>gets BIND format</p>
    * @param name column name 
    * @return returns String representatio of bind string
    */
   public String getBindFormat(String name) {
       return sqlTagsColumns.getBindFormat(name);
   }
   /**
    * <code>setBindFormat</code>
    * <p>sets BIND format</p>
    * @param name column name 
    * @param bindFormat format for bind string
    * @return none
    */
   public void setBindFormat(String name, String bindFormat) {
       sqlTagsColumns.setBindFormat(name,bindFormat);
   }
   
   /**
    * <code>getString</code>
    * <p>gets String version of sqlTagsColumn</p>
    * @param name column name 
    * @return returns String value
    */
   public String getString(String name) {
       return getString(name,getArrayIndex());
   }
   /**
    * <code>getString</code>
    * <p>gets String version of sqlTagsColumn</p>
    * @param name column name 
    * @param arrayIndex index into current array
    * @return returns String value
    */
   public String getString(String name, String arrayIndex) {
       return nvl(sqlTagsColumns.getString(name,arrayIndex),"");
   }
   /** <code>getColumnValue</code>
    * <P>strictly for backward compat-- no longer supported and may be dropped
    * in a future version.  Replaced by getString()
    * @param s - name of column to retreive
    * @return String the String value of column named s
    */
   public String getColumnValue(String s){ return getString(s);}
   /** <code>getColumnValue</code>
    * <P>strictly for backward compat-- no longer supported and may be dropped
    * in a future version.  Replaced by getString()
    * @param s - name of column to retreive
    * @param a - arrayIndex for value array
    * @return String the String value of column named s
    */
   public String getColumnValue(String s,String a){return getString(s,a);}
   /**
    * <code>setString</code>
    * <p>sets String version of sqlTagsColumn</p>
    * @param name column name 
    * @return returns none
    */
   public void setString(String name, String value) {
       setString(name,value,getArrayIndex());
   }
   /**
    * <code>setString</code>
    * <p>sets String version of sqlTagsColumn</p>
    * @param name column name 
    * @param arrayIndex index into current array
    * @return returns none
    */
   public void setString(String name, String value, String arrayIndex) {
       sqlTagsColumns.setString(name,value,arrayIndex);
   }
   /**
    * <code>getDate</code>
    * <p>gets Date version of sqlTagsColumn</p>
    * @param name column name 
    * @return returns Date value
    */
   public java.util.Date getDate(String name) {
       return getDate(name,getArrayIndex());
   }
   /**
    * <code>getDate</code>
    * <p>gets Date version of sqlTagsColumn</p>
    * @param name column name 
    * @param arrayIndex index into current array
    * @return returns Date value
    */
   public java.util.Date getDate(String name, String arrayIndex) {
       return sqlTagsColumns.getDate(name,arrayIndex);
   }
   /**
    * <code>setDate</code>
    * <p>sets Date version of sqlTagsColumn</p>
    * @param name column name 
    * @param value of date to be set
    * @return returns none
    */
   public void setDate(String name, java.util.Date value) {
       setDate(name,value,getArrayIndex());
   }
   /**
    * <code>setDate</code>
    * <p>sets Date version of sqlTagsColumn</p>
    * @param name column name 
    * @param value of date to be set
    * @param arrayIndex index into current array
    * @return returns none
    */
   public void setDate(String name, java.util.Date value, String arrayIndex) {
       sqlTagsColumns.setDate(name,value,arrayIndex);
   }
   /**
    * <code>getDateField</code>
    * <p>gets Date field of sqlTagsColumn</p>
    * @param name column name 
    * @param field date field to return
    * @return returns String value
    */
   public String getDateField(String name, String field) {
       return getDateField(name,field,getArrayIndex());
   }
   /**
    * <code>getDate</code>
    * <p>gets Date version of sqlTagsColumn</p>
    * @param name column name 
    * @param field date field to return
    * @param arrayIndex index into current array
    * @return returns String value
    */
   public String getDateField(String name, String field, String arrayIndex) {
       return sqlTagsColumns.getDateField(name,field,arrayIndex);
   }
   
   /**
    * <code>setDate</code>
    * <p>sets Date field in sqlTagsColumn</p>
    * @param name column name 
    * @param field date field to set
    * @param value of the field
    * @return returns String value
    */
   public void setDateField( String name, String field, String value) {
       setDateField(name,field,value,getArrayIndex());
   }
   /**
    * <code>setDate</code>
    * <p>sets Date field in sqlTagsColumn</p>
    * @param name column name 
    * @param field date field to set
    * @param value of the field
    * @param arrayIndex index into current array
    * @return returns String value
    */
   public void setDateField( String name, String field, String value, String arrayIndex) {
       sqlTagsColumns.setDateField(name,field,value,arrayIndex);
   }
   
   /**
    * <code>getNumber</code>
    * <p>gets Number version of sqlTagsColumn</p>
    * @param name column name 
    * @return returns Number value
    */
   public Number getNumber(String name) {
       return sqlTagsColumns.getNumber(name,getArrayIndex());
   }
   /**
    * <code>getNumber</code>
    * <p>gets Number version of sqlTagsColumn</p>
    * @param name column name 
    * @param arrayIndex index into current array
    * @return returns Number value
    */
   public Number getNumber(String name, String arrayIndex) {
       return sqlTagsColumns.getNumber(name,arrayIndex);
   }
   /**
    * <code>setNumber</code>
    * <p>sets Number value of a sqlTagsColumn</p>
    * @param name column name 
    * @param value value to be set
    * @return none
    */
   public void setNumber(String name, Number value) {
       setNumber(name,value,getArrayIndex());
   }
   /**
    * <code>setNumber</code>
    * <p>sets Number value of a sqlTagsColumn</p>
    * @param name column name 
    * @param value value to be set
    * @param arrayIndex index into current array
    * @return none
    */
   public void setNumber(String name, Number value, String arrayIndex) {
       sqlTagsColumns.setNumber(name,value,arrayIndex);
   }
   
   /**
    * <code>init</code>
    * <p>Initialize object for use </p>
    */
   protected void init(){
       anyRecords=false;
       arrayIndexHash=new Hashtable();
       arrayIndex="0";
       arrayIndexEnumeration = null;
       bindColumnVector=new Vector();
       caching="false";
       cacheSize="0";
       cacheScheme="default";
       childName="";
       columns="";
       sqlTagsConnection=null;
       currentPage="1";
       currentRow=0;
       displayPageSize="";
       distinct="false";
       depth=0;
       exception=null;
       firstRecord=false;
       foreignKey="";
       handlerClass="";
       handlerID="";
       hasFetch=false;
       // utilities=new Utilities();
       itemDisplayCount=0;
       lastRecord=false;
       maxInt=Integer.MAX_VALUE;
       maxRows=Integer.MAX_VALUE+"";
       multipleOpen=false;
       operationHash=new Hashtable();
       operationName="OPERATION";
       orderBy="";
       pageSize="";
       paging="false";
       parentName="";
       preInsertSQL="";
       ps=null;
       preUpdateSQL="";
       primaryKeyVector=new Vector();
       properties="false";
       resultSet=null;
       resultSetSize=0;
       selectPreparedStatement=null;
       sql="";
       sqlTagHandler=new SQLTagsHandler();
       sqlTagRequest=null;
       startPage="1";
       startRow="0";
       tableName="SQLTags";
       where="";
       from="";
       startRowParameter="startRow";
       tableAlias="";
       
       sqlTagsColumns = new SQLTagsColumns(); // replacement for columnProperties
       initializeHashTables();
   }
   
   /**  
    * <code>initialize</code>  
    * <p>  
    * The method dose a select, fetch, and then a close. It also ensures  
    * the the foreign keys have been initialize to the appropriate depth.  
    * </p>  
    * @param depth <code>int</code> The number of layers to be initialize.  
    * @return none <code></code>  
    */  
   //---------------------------------------------------------------------------  
   public void initialize(int depth){  
   //---------------------------------------------------------------------------  
         select();  
         fetch();  
         close();  
         setFKParent(depth);  
   }// initialize() ENDS  
   
   /** 
    */
   protected void initializeHashTables() {
       // provided for override by generated tag
   }
     
   /**  
    * <code>insert</code>  
    * <p>  
    * This method inserts records into the database.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code></code>  
    * @return true <code>boolean</code> true, if everything went ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean insert(){  
   //---------------------------------------------------------------------------  
      // haveLob=false;  
      boolean returnValue=true;  
      preInsertSQL(getPreInsertSQL());  
      String colStr=getCommaString();  
      StringBuffer psQuery=new StringBuffer();  
      psQuery.append("insert into "+getTableName()+"("+colStr+") values(");  
      psQuery.append(getColonString("insert",",")+")");  
      // sqlTagHandler=getSQLTagsHandler();  
        
      if(!sqlTagHandler.preInsert(this))  
         returnValue=false;  
      else{  
         returnValue = executeSQL(psQuery.toString(),true);  
         if(returnValue) {
             if(!sqlTagHandler.postInsert(this))  
                returnValue=false;  
         }
         if(returnValue) {
            setFKParent();  
         }
      }  
        
      return returnValue;  
   }// insert() ENDS  
   
   public boolean insertArray(){
       Enumeration arrayIndexes = getArrayIndexes();
       while(arrayIndexes.hasMoreElements()){
           String arrayIndex = (String) arrayIndexes.nextElement();
           setArrayIndex( arrayIndex );
           
           if(!insert()){
               log.warning("insertArray failed at: " + arrayIndex);
               return false;
           }
       }
       return true;
   }//insertArray ENDS

   /**  
    * <code>isColumnTypeValid</code>  
    * <p>  
    * This method keeps track of whether there is any data.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param state <code>boolean</code> True if there are any records.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   private boolean isColumnTypeValid(Vector vector,String string){
   //---------------------------------------------------------------------------  
      boolean isColumnValid=false;
      Enumeration enum=vector.elements();
   
      for(;enum.hasMoreElements();){
          String column=(String)enum.nextElement();
          
          if(column.equalsIgnoreCase(string)){
              isColumnValid=true;
              break;
          }
      }
      
      return isColumnValid;
   }// isColumnInVector() ENDS  
     
   /**  
    * <code>isData</code>  
    * <p>  
    * This method keeps track of whether there is any data.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param state <code>boolean</code> True if there are any records.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   private void isData(boolean state){  
   //---------------------------------------------------------------------------  
      anyRecords=state;  
   }// isData() ENDS  
     
   /**  
    * <code>isData</code>  
    * <p>  
    * This method returns true if there is any data.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return anyRecords <code>boolean</code> True, if there are any records.  
    */  
   //---------------------------------------------------------------------------  
   private boolean isData(){  
      //---------------------------------------------------------------------------  
      return anyRecords;  
   }// isData() ENDS  
     
   /**  
    * <code>isFetch()</code>  
    * <p>  
    * This method returns the value of the hasFetch property.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return hasFetch <code>String</code> true, if a fetch has already  
    *        been done.  
    */  
   //---------------------------------------------------------------------------  
   public boolean isFetch(){  
   //---------------------------------------------------------------------------  
      return hasFetch;  
   }// isFetch() ENDS  
     
     
     
   /**  
    * <code>isFirstRecord</code>  
    * <p>  
    * This method indicates whether this is the first record of the result set.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return true <code>boolean</code> if this is the first record of  
    *        the result set.  
    */  
   //---------------------------------------------------------------------------  
   public boolean isFirstRecord(){  
   //---------------------------------------------------------------------------  
      return firstRecord;  
   }// isFirstRecord() ENDS  
     
   /**  
    * <code>isLastRecord</code>  
    * <p>  
    * This method indicates whether this is the last record within this result  
    * set.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return lastRecord <code>boolean</code> true, if this is the last  
    *        record within this result set.  
    */  
   //---------------------------------------------------------------------------  
   public boolean isLastRecord(){  
      //---------------------------------------------------------------------------  
      return lastRecord;  
   }// isLastRecord() ENDS  
     
   /**  
    * <code>isLastRecordOnPage</code>  
    * <p>  
    * This method indicates whether this is the first record of the result set.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return true <code>boolean</code> if this is the first record of  
    *        the result set.  
    */  
   /*
   //---------------------------------------------------------------------------  
   public boolean isLastRecordOnPage(){  
   //---------------------------------------------------------------------------  
      return lastRecordOnPage;  
   }// isLastRecordPage() ENDS  
    */
     
   /**  
    * <code>isNextPage</code>  
    * <p>  
    * This method checks to see if we have any records left to place on the next  
    * page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return haveNextPage <code>boolean</code> True, if there is data  
    *        to display.  
    */  
   //---------------------------------------------------------------------------  
   public boolean isNextPage(){  
   //---------------------------------------------------------------------------  
      int pageSize=getPageSize();  
      boolean haveNextPage=true;  
      int lastRecordDisplayed=0;  
      boolean validStartRow=false;  
      int displayCount=0;  
      
      if(!isData()||pageSize==maxInt)  
         haveNextPage=false;  
        
      return haveNextPage;  
   }// isNextPage() ENDS  
     
     
   /**  
    * <code>isPreviousPage</code>  
    * <p>  
    * This method checks to see if we have any records left  
    * to place on the previous  
    * page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return havePreviousPage <code>boolean</code> True, if there is data  
    *        to display.  
    */  
   //---------------------------------------------------------------------------  
   public boolean isPreviousPage(){  
   //---------------------------------------------------------------------------  
      boolean havePreviousPage=false;  
      boolean validStartRow=false;  
        
      // get the display page size and the current row were on  
      int pageSize=getPageSize();  
      int lastRecordDisplayed=utilities.stringToInt(getStartRow());  
        
      /**  
       * if the total amount of records we have already displayed is  
       * greater than the page size, we know that there is a previous page,  
       * therefore we need to calculate its starting position.  
       */  
      if(lastRecordDisplayed>pageSize&&pageSize!=maxInt){  
         havePreviousPage=true;  
         int previousStartPosition=lastRecordDisplayed-(pageSize*2);  
           
         /**  
          * There is a possible situation where the page size is greater  
          * the total amount of records retrieved. In this case their will  
          * be no previous page. Lets handle that condition now.  
          */  
         if(previousStartPosition<pageSize){  
            previousStartPosition=0;  
            havePreviousPage=false;  
         }  
      }  
        
      return havePreviousPage;  
   }// isPreviousPage() ENDS  
     
   /**  
    * <code>log</code>  
    * <p>  
    * This method logs errors to netscapes error log.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param message <code>String</code> the error to log.  
    * @return true <code>boolean</code> If there are more records to fetch.  
    */  
   /**
    *
   //---------------------------------------------------------------------------  
   public void log(String message){  
   //---------------------------------------------------------------------------  
      if(pageContext!=null)  
         pageContext.getServletContext().log(message);  
      else{  
         System.out.println(message);  
      }  
   }// log() ENDS  
    */
  
   /**  
    * <code>next</code>  
    * <p>  
    * This method dose a fetch.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return true <code>boolean</code> If there are more records to fetch.  
    */  
   //---------------------------------------------------------------------------  
   public boolean next(){  
   //---------------------------------------------------------------------------  
      return fetch();  
   }// next() ENDS  
     
   /**  
    * <code>open</code>  
    * <p>  
    * This method performs a select.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return true <code>boolean</code> true if select was ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean open(){  
   //---------------------------------------------------------------------------  
      return select();  
   }// open() ENDS  
     
   /**  
    * <code>open</code>  
    * <p>  
    * This method dose a select based on a where clause which is passed in.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param whereClause <code>String</code> The where clause.  
    * @return true <code>boolean</code> If everything went ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean open(String whereClause){  
   //---------------------------------------------------------------------------  
      return select(whereClause);  
   }// open() ENDS  
     
   /**  
    * <code>preInsertSQL</code>  
    * <p>  
    * This method processes the pre-insert instruction.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param insertString <code>String</code> The instruction to process.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void preInsertSQL(String insertString){  
   //---------------------------------------------------------------------------  
      ResultSet resultSet=null;  
      if(insertString==null||insertString.equals(""))  
         return;  
        
      try{  
         Connection connection=getConnection();
         Statement stmt=connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);  
         resultSet=stmt.executeQuery(insertString);
         sqlFetch(resultSet);
         stmt.close();
      }  
      catch(JspException e) {
          log.warning("Exception preSQL(): Invalid connection: "+e);
      }
      catch(SQLException exception){  
          log.warning("Exception preSQL: "+exception);
         close();  
      }  
   }// preInsertSQL() ENDS  
     
   /**  
    * <code>select</code>  
    * <p>  
    * This method will select records from the database based upon the primary  
    * key.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code></code> .  
    * @return true <code>boolean</code> true, if everything went ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean select(){  
   //---------------------------------------------------------------------------  
      if(where.trim().equals(""))  
         return select("where "+getColonString("primaryKey","and"));  
      else  
         return select(where);  
   }// select() ENDS  
     
   /**  
    * <code>select</code>  
    * <p>  
    * This method will select records from the database based upon a where clause  
    * which is passed into the method.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param where <code>String</code> The where condition.  
    * @return true <code>boolean</code> true, if everything went ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean select(String where){  
   //---------------------------------------------------------------------------  
       log.finer("select: where="+where);
       
      StringBuffer selectQuery=new StringBuffer("select ");  
      // sqlTagHandler=getSQLTagsHandler();  
      
      if(distinct.equalsIgnoreCase("true"))
         selectQuery.append("distinct ");
       
      if(!sqlTagHandler.preQuery(this))  
         return false;  
        
      if(isOpen()){
          log.fine("cursor is already open: "+ where);
      }
        
      log.finest("select: settingup columns ... ");
      // Enumeration enum=columnPropertiesHash.keys();  
      Enumeration enum=sqlTagsColumns.keys();
        
      for(;enum.hasMoreElements();){  
         String key=((String)enum.nextElement());  
         SQLTagsColumn col = sqlTagsColumns.get(key);
         // need to decide if non-baseTable columns should be in select list
         // since they are constant anyway shouldn't really be in here also
         // would allow us to flag columns as non-basetable when using columns
         // attribute and keep items in columnpropertiesHash ... 
         if(!col.isBaseTable()) {
             continue;
         }
         
         StringBuffer buf= new StringBuffer(col.getSelectFormat());
         if(!getTableAlias().equals("")) {
             int index=buf.indexOf(key);
             if( index > -1)
                 buf.replace(index, index+key.length(), getTableAlias()+"."+key);
         }
         selectQuery.append(buf + " as " + key + ", ");
      }  
      selectQuery.setLength(selectQuery.toString().lastIndexOf(","));  
      selectQuery.append("\n");  
      selectQuery.append(" from "+getTableName()+" "+getTableAlias());
      if(!from.equals("")) 
         selectQuery.append(" ,"+from+" ");
      if(!where.equals("")) {
         selectQuery.append("\n");  
         selectQuery.append(" "+where+" ");
      }
      executeSQL(selectQuery.toString(),true);  
        
      return true;  
   }// select() ENDS  
   
   /**  
    * <code>setArrayIndex</code>  
    * <p>  
    * This method sets the array index.
    * </p>  
    * @version 1.0  
    * @since   1.3  
    * @param  arrayIndex<code>String</code> the array index
    * @return <code>none</code>
    */  
   //---------------------------------------------------------------------------  
   public void setArrayIndex(String arrayIndex){
   //---------------------------------------------------------------------------  
       this.arrayIndex=arrayIndex;
   }//setArrayIndex() ENDS
   
   /** sets the columnProperties and the FK parents
    * based on a bean previously set by useBean
    * @param bean bean found using findAttribute()
    * that was referenced using useBean; this method should be
    * overridden by the generated class for a specific table.
    */   
   //---------------------------------------------------------------------------  
   public void setBeanProperties(Object bean) {
   //---------------------------------------------------------------------------  
       if(bean==null)
           return;
       if( bean instanceof SQLTags ) {
           SQLTags t = (SQLTags)bean;
           // setColumnPropertiesHash(t.getColumnPropertiesHash());
           sqlTagsColumns = t.getSQLTagsColumns();
       }
   }
   
   public SQLTagsColumns getSQLTagsColumns() {return this.sqlTagsColumns;}
   public void setSQLTagsColumns(SQLTagsColumns c){this.sqlTagsColumns=c;}
   
   /**  
    * <code>sqlFetch</code>  
    * <p>  
    * This method stores the values obtained from the query into the 
    * columnProperties object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param resultSet <code>ResultSet</code> The results obtained from  
    *        the query..  
    * @return none <code>none</code> none.  
    */  
   public boolean sqlFetch(ResultSet rs) {
       try {
           if( rs.next() ) {
               sqlTagsColumns.set(rs,arrayIndex);
               return true;
           }
       } catch (SQLException e) {
           log.severe("SQLTags:sqlFetch:"+e);
       }
       return false;
   }
   
   /**
    *
   //---------------------------------------------------------------------------  
   public boolean XsqlFetch(ResultSet resultSet){  
   //---------------------------------------------------------------------------  
       boolean hasMore=false;
       String columnName="";
       // setColumnTypes();
       
       try{
           if(resultSet.next()){
               sqlTagsColumns.set(resultSet,arrayIndex);
               // how many columns do we have
               ResultSetMetaData metaData=resultSet.getMetaData();
               int size=metaData.getColumnCount()+1;
               
               // reset the columnPropertiesHash with the columns retrieved
               for(int index=1;index<size;index++){
                   hasMore=true;
                   // Enumeration enum=columnPropertiesHash.keys();
                   columnName=metaData.getColumnName(index);
                   if( !sqlTagsColumns.contains(columnName.toUpperCase())) {
                       continue;
                   }
                   
                   String key=columnName.toUpperCase();
                   SQLTagsColumn col = sqlTagsColumns.get(key);
                   
                   col.setObject(resultSet.getObject(columnName)); // every time ?
                   try {
                       if(isColumnTypeValid(asciiStreamColumns,col.getType())) {
                           // readClobBlobLong(key);
                           col.setValue( resultSet.getAsciiStream(columnName) );
                       }
                       else if(isColumnTypeValid(binaryStreamColumns,col.getType())) {
                           // readClobBlobLong(key);
                           col.setValue( resultSet.getBinaryStream(columnName));
                       }
                       else if(isColumnTypeValid(characterStreamColumns,col.getType())) {
                           // readClobBlobLong(key);
                           col.setValue( resultSet.getCharacterStream(columnName));
                       }
                       else{
                           if(resultSet.getString(columnName)!=null){
                               col.setValue(resultSet.getString(columnName));
                           }
                       }
                   }
                   catch(IOException exception){
                       log(getTableName()+".sqlFetch(): "+getSql()+"\n"+exception);
                       close();
                   }
               }
           }
       }
       catch(SQLException exception){
           close();
           setException(exception);
           log(getTableName()+".sqlFetch(): "+getSql()+"\n"+exception);
       }
       
       return hasMore;
   }// sqlFetch() ENDS  
    *
    */
     
   /*  
    * <code>toString</code>  
    * <p>  
    * This method sets the column bind.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param bind <code>String</code> the column bind  
    * @return <code>none</code>  
    */  
   //---------------------------------------------------------------------------  
   public String toString(){  
   //---------------------------------------------------------------------------  
      StringBuffer buffer=new StringBuffer("SQLTags::");  
      buffer.append("tableName=" + getTableName());  
      buffer.append(":Connection = " + getSQLTagsConnection());  
      buffer.append(":Columns = " + getSQLTagsColumns());  
      return buffer.toString();  
   }//toString() ENDS  
  
   /**  
    * <code>update</code>  
    * <p>  
    * This method updates records that are currently within the database.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code></code>  
    * @return true <code>boolean</code> true, if everything went ok.  
    */  
   //---------------------------------------------------------------------------  
   public boolean update(){  
   //---------------------------------------------------------------------------  
       String whereClause = "where " + getColonString("primaryKey","and");
       return update(whereClause);
   }// update() ENDS  
   
   //---------------------------------------------------------------------------  
   public boolean update(String where){
   //---------------------------------------------------------------------------  
      boolean returnValue=true;  
      preInsertSQL(getPreUpdateSQL());  
        
      StringBuffer psQuery=new StringBuffer("update "+getTableName()+ " " +getTableAlias()+" "+" set ");  
      psQuery.append(getColonString("columns",","));  
      
      // Vector saveVector=new Vector(bindColumnVector);  
      psQuery.append(" "); // just in case ... 
      psQuery.append(where);  
      /*
       *
      int size=bindColumnVector.size();  
        
      if(size>0)  
         for(int index=0;index<size;index++)  
            saveVector.addElement(bindColumnVector.elementAt(index));  
        
      bindColumnVector=new Vector(saveVector);  
       *
       */
      // sqlTagHandler=getSQLTagsHandler();  
        
      if(!sqlTagHandler.preUpdate(this))  
         returnValue=false;  
      else{  
         returnValue = executeSQL(psQuery.toString(),true);  
         if( returnValue) {
             if(!sqlTagHandler.postUpdate(this))  
                returnValue=false;  
         }
         if(returnValue)
            setFKParent();  
      }  
      return returnValue;  
   }//update() ENDS

   private boolean updateArray(){
       Enumeration arrayIndexes = getArrayIndexes();
       while( arrayIndexes.hasMoreElements() ) {
           String arrayIndex = (String) arrayIndexes.nextElement();
           setArrayIndex( arrayIndex );
           if( ! update() ) {
               log.fine("UpdateArray Failed on index="+arrayIndex);
               return false;
           }
       }
       return true;
   }//updateArray ENDS
     
   /**  
    * <code>setColumns</code>  
    * <p>  
    * This method will adjust the columnPropertiesHash table  in accordance with  
    * the columns attribute.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code></code>  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   private void setColumns(){  
   //---------------------------------------------------------------------------  
      Vector columnVector=new Vector();  
      Vector clearVector=new Vector();  
      columns=getColumns();  
      int start=0;  
      int stop=columns.indexOf(",",start);  
      String key="";  
        
      if(stop!=-1){  
         while(stop!=-1){  
            columnVector.add(columns.substring(start,stop).trim());  
            start=stop+1;  
            stop=columns.indexOf(",",start);  
         }  
         columnVector.add(columns.substring(start,columns.length()).trim());  
      }  
      else  
         columnVector.add(columns);  
        
      // Enumeration enum=columnPropertiesHash.keys();  
      Enumeration enum = sqlTagsColumns.keys();
        
      for(;enum.hasMoreElements();){  
         key=(String)enum.nextElement();  
         if(!columnVector.contains(key))  
            clearVector.add(key);  
      }  
        
      enum=clearVector.elements();  
        
      // make sure the primary key was submitted with the columns  
      // primaryKeyVector=getPrimaryKeyVector();  
      int size=primaryKeyVector.size();  
        
      for(int index=0;index<size;index++){  
         String column=(String)primaryKeyVector.get(index);  
           
         if(clearVector.contains(column.toUpperCase()))  
            clearVector.remove(column.toUpperCase());  
      }  
        
      // update the column hash to the requested values  
      for(;enum.hasMoreElements();){  
         key=(String)enum.nextElement();  
         // columnPropertiesHash.remove(key);  
         sqlTagsColumns.delete(key);
      }  
   }// setColumns() ENDS   
     
   //***************************************************************************  
   //                      Class accessor section  
   //***************************************************************************  
   /**  
    * <code>getBindColumns</code>  
    * <p>  
    * This method parses a where clause which contains colon  
    * variables and returns the bind compatiable version. This  
    * method sets the bind column vector.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param type <code>String</code> the type your creating.  
    * @return colonString <code>String</code> the new colon string.  
    */  
   //---------------------------------------------------------------------------  
   private String getBindColumns(String where){  
   //---------------------------------------------------------------------------  
      where+=" ";  
      
      /**
       * this vector holds the names of all of the bind columns for this table.
       * we need to start from scratch.
       **/
      bindColumnVector.setSize(0);  
                  
      //get the index of the first bind.
      int columnNameStarts=where.indexOf(":");  
      
      //do we have any bind variables?
      while(columnNameStarts!=-1){ 
          /**
           * need to push the index to the first character beyond the
           * : variable. this is where the column name really ends.
           */
          int columnNameEnds=1+columnNameStarts;
          StringBuffer bindName=new StringBuffer();
          
          // now we can get the bind name.
          // *****************************
          // Would be better to avoid ":" variables within single quotes with
          // a better parser ... big danger in grabing 'mm/dd/yy hh:mi' as
          // a column (if MI is a column in table or request param it's screw up)
          // *****************************
          for(;columnNameEnds<where.length();columnNameEnds++){
              char aCharacter=where.charAt(columnNameEnds);
              
              if(Character.isJavaIdentifierPart(aCharacter)||
                 Character.isJavaIdentifierStart(aCharacter)){
                  bindName.append(aCharacter);
              } 
              else
                  break;
          }
          
          //convert the bind name to upper case. that's our format.
          String bindNameString=bindName.toString().toUpperCase();
          log.finest("getBindColumns:" + bindNameString );
          /**
           * the bind name should must be an entry within the 
           * columnPropertiesHash. get it now.
           */
          /**
          ColumnProperties item=(ColumnProperties)
                                 columnPropertiesHash.get(bindNameString);
           */
          SQLTagsColumn col = sqlTagsColumns.get(bindNameString);

          /**
           * was the bind name valid?
           */
          if(col==null) {
              log.finer("getBindColumns:no col, checking servletRequest for: " + bindNameString);
              // OK it isn't a COLUMN in the table ... let's see where we can
              // find one named bindNameString ...
              //
              String value=null;
              if(pageContext!=null) {
                  HttpServletRequest servletRequest = (HttpServletRequest)pageContext.getRequest();
                  // Ok, we are binding ... can't affort to not have a value ..
                  // so we'll set the value to "" if we can't find it.  ... still
                  // need alternatives from request "parameters" ...
                  // perhaps findAttribute??
                  value= servletRequest.getParameter(bindNameString);
                  if(value==null) {
                      value= servletRequest.getParameter(bindNameString.toLowerCase());
                      if( value==null) {
                          value= servletRequest.getParameter(bindNameString.toUpperCase());
                      }
                  }
              }
              // OK, if the value is NULL we didn't find the bind variable anywhere
              // we know about ... so we just skip it ... this helps us deal with
              // strings like "mm/dd/yyyy hh24:mi" when :MI is not a bind var
              if(value!=null) {
                  col = new SQLTagsColumn(bindNameString,value,getArrayIndex(),"STRING",Types.VARCHAR,""+value.length(),"","?",bindNameString,false,new Object());
                  getSQLTagsColumns().add(col);
              } else {
                  log.fine("getBindColumns:Skipped col: " + bindNameString);
              }
          }
          if(col!=null){
              //store the bind name in our bindColumnVector for later use.
              bindColumnVector.addElement(bindNameString);
              
              /**
               * take the bind format from the columnProperties object and
               * palace it in the where clause.
               */
              StringBuffer tmp=new StringBuffer(where);
              tmp.replace(columnNameStarts,columnNameEnds, col.getBindFormat());
                        //  getColumnProperty("bind",bindNameString));
              where=tmp.toString(); 
              /**
               * finally figure out where to start looking for the next 
               * colon variable.  (to_char('hh:mi:ss') contain :'s
               */
              columnNameEnds=columnNameStarts+ col.getBindFormat().length();
                         //    getColumnProperty("bind",bindNameString).length();
          }
          
         // grab the next colon variable, if were not done.
         columnNameStarts=where.indexOf(":",columnNameEnds);  
      }
      
      // done.
      return where;  
   } // getBindColumns() ENDS  
     
     
   /**  
    * <code>getButtonName</code>  
    * <p>  
    * This method returns the name of the current operation we are doing. For  
    * example, select.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return buttonName <code>String</code> The name of the selected button.  
    */  
   //---------------------------------------------------------------------------  
   public String getButtonName(){  
   //---------------------------------------------------------------------------  
      return operationName;  
   }// getButtonName() ENDS  
   
   /**  
    * <code>getChildName</code>  
    * <p>  
    * This method gets the tables childName.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return parentName <code>String</code> The parent name.  
    */  
   //---------------------------------------------------------------------------  
   public String getChildName(){  
   //---------------------------------------------------------------------------  
      return childName;  
   }// getChildName() ENDS  
     
   /**  
    * <code>getColonString</code>  
    * <p>  
    * This method will create a colon string based on the columns or primary  
    * key.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param type <code>String</code> the type your creating.  
    * @return colonString <code>String</code> the new colon string.  
    */  
   //---------------------------------------------------------------------------  
   private String getColonString(String type, String separator){  
   //---------------------------------------------------------------------------  
      // primaryKeyVector=getPrimaryKeyVector();  
      StringBuffer buffer=new StringBuffer();  
        
      if(type.equalsIgnoreCase("columns")){  
         // Enumeration enum=columnPropertiesHash.keys();  
         Enumeration enum=sqlTagsColumns.keys();  
         
         for(;enum.hasMoreElements();){  
            String key=((String)enum.nextElement()).toUpperCase();  
            if( !sqlTagsColumns.isBaseTable(key)) {
                continue;
            }
            buffer.append(key+"=:");  
            buffer.append(key+" "+separator+" ");  
         }  
         buffer.setLength(buffer.toString().lastIndexOf(separator));  
      }  
      else if(type.equalsIgnoreCase("primaryKey")){  
         int sizeOfVector=primaryKeyVector.size();  
         for(int index=0;index<sizeOfVector;index++){  
            String key=((String)primaryKeyVector.elementAt(index)).toUpperCase();  
            if( !sqlTagsColumns.isBaseTable(key)) {
                continue;
            }
            buffer.append(key+"= :"+key+" and ");
         }  
         buffer.setLength(buffer.toString().lastIndexOf(" and"));  
      }  
      else if(type.equalsIgnoreCase("insert")){  
         // Enumeration enum=columnPropertiesHash.keys();  
         Enumeration enum=sqlTagsColumns.keys();  
           
         for(;enum.hasMoreElements();){  
            String key=((String)enum.nextElement()).toUpperCase();  
            SQLTagsColumn col = sqlTagsColumns.get(key);
            if(!col.isBaseTable()) {
                continue;
            }
            buffer.append(":"+key+" "+separator+" ");  
         }  
         buffer.setLength(buffer.toString().lastIndexOf(separator));  
      }  
      else if(type.equalsIgnoreCase("delete")){  
         int sizeOfVector=primaryKeyVector.size();  
         for(int index=0;index<sizeOfVector;index++){  
            String key=((String)primaryKeyVector.elementAt(index)).toUpperCase();  
            buffer.append(key+"=:"+key+" and ");  
         }  
           
         buffer.setLength(buffer.toString().lastIndexOf(" and"));  
      }  
        
      return buffer.toString();  
   }//getColonString() ENDS  
   
   /** returns an Enumeration of columns (sa SQLTagsColumnns) for this instance
    * @return Enumeration of Column Names returned as Strings
    */   
   public Enumeration getColumnNames(){
       return sqlTagsColumns.keys();
   }
   /** Returns a single SQLTagsColumn for a given column name
    * @param name name of the column (should be from getColumnNames)
    * @return SQLTagsColumn for given name
    */   
   public SQLTagsColumn getColumn(String name){
       return sqlTagsColumns.get(name);
   }
     
   /**  
    * <code>getColumnNameSelectList</code>  
    * <p>  
    * This method return the value of the requested column.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param name <code>String</code> valid values are:  
    * <li>bind</li>  
    * <li>selectFormat</li>  
    * <li>value</li>  
    * @param key <code>String</code> the column name.  
    * @return propertyValue <code>String</code> the column's associated value.  
    */  
   //---------------------------------------------------------------------------  
   private String getColumnNameSelectList(){  
   //---------------------------------------------------------------------------  
      // Enumeration enum=columnPropertiesHash.keys();  
      Enumeration enum=sqlTagsColumns.keys();  
      StringBuffer buffer=new StringBuffer();  
        
      for(;enum.hasMoreElements();){  
         String key=((String)enum.nextElement()).toUpperCase();  
         // buffer.append(getColumnProperty("selectFormat",key)+" as "+key+",");  
         buffer.append(sqlTagsColumns.getSelectFormat(key) +" as "+key+",");  
      }  
        
      buffer.setLength(buffer.toString().lastIndexOf(","));  
        
      return buffer.toString();  
   }  
     
   /**  
    * <code>getColumnProperty</code>  
    * <p>  
    * This method return the value of the requested column.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param name <code>String</code> valid values are:  
    * <li>bind</li>  
    * <li>selectFormat</li>  
    * <li>value</li>  
    * @param key <code>String</code> the column name.  
    * @return propertyValue <code>String</code> the column's associated value.  
    */  
   /**
   //---------------------------------------------------------------------------  
   public String getColumnProperty(String name, String key){  
   //---------------------------------------------------------------------------  
       return getColumnProperty(name,key,getArrayIndex());
   }// getColumnProperty() ENDS  
    *
    */
   
   /**
    *
   //---------------------------------------------------------------------------
   public String getColumnProperty(String name, String key, String arrayIndex){
   //---------------------------------------------------------------------------
      key=key.toUpperCase();  
      ColumnProperties item=(ColumnProperties)columnPropertiesHash.get(key);  
      String propertyValue="";  
        
      if(item!=null){  
         if(name.equalsIgnoreCase("selectFormat"))  
            propertyValue=item.getSelectFormat();  
         else if(name.equalsIgnoreCase("bind"))  
            propertyValue=item.getBind();  
         else if(name.equalsIgnoreCase("value"))  
            propertyValue=item.getValue(arrayIndex);  
         else if(name.equalsIgnoreCase("inclause"))
             propertyValue=item.getInClause();
         else if(name.equalsIgnoreCase("type"))
             propertyValue=item.getType();
      }  
      return propertyValue;  
   }// getColumnProperty() ENDS
    *
    */
     
   /**  
    * <code>getColumns</code>  
    * <p>  
    * This method returns the value of columns. This value represents the columns  
    * to be returned from the db.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code></code>  
    * @return columns <code>String</code> the database columns to return  
    *        from the database.  
    */  
   //---------------------------------------------------------------------------  
   private String getColumns(){  
   //---------------------------------------------------------------------------  
      return columns;  
   }// getColumns() ENDS  
     
   /**  
    * <code>getColumnValue</code>  
    * <p>  
    * This method returns the specified value of the requested column.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param key <code>String</code> The column were looking up.  
    * @return key <code>String</code> The value of this key.  
    */  
   
   /**
    *
   //---------------------------------------------------------------------------  
   public String getColumnValue(String key){  
   //---------------------------------------------------------------------------  
       return getColumnValue(key,getArrayIndex());
   }// getColumnValue() ENDS  
   
   public String getColumnValue(String key, String arrayIndex){
       return getColumnProperty("value",key,arrayIndex);
   }//getColumnValue() ENDS
    *
    */
     
   /**  
    * <code>getCommaString</code>  
    * <p>  
    * This method will create a colon string based on the columns or primary  
    * key.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code></code>  
    * @return colonString <code>String</code> a comma separated list of  
    *        columns  
    */  
   //---------------------------------------------------------------------------  
   private String getCommaString(){  
   //---------------------------------------------------------------------------  
       StringBuffer buffer=new StringBuffer();
       // Enumeration enum=columnPropertiesHash.keys();
       Enumeration enum=sqlTagsColumns.keys();
       
       for(;enum.hasMoreElements();){
           String key=((String)enum.nextElement()).toUpperCase();
           if( !sqlTagsColumns.isBaseTable(key)) {
               continue;
           }
           buffer.append(key+", ");
       }
       buffer.setLength(buffer.toString().lastIndexOf(","));
       return buffer.toString();
   }//getCommaString() ENDS  
     
   /**  
    * <code>getConnectionObject</code>  
    * <p>  
    * This method returns the current connection.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return connection <code>Connection</code> The current connection.  
    */  
   /*
   //---------------------------------------------------------------------------  
   public Connection getConnectionObject(){  
   //---------------------------------------------------------------------------  
      return ConnectionManager.getInstance().getConnectionObject(connection);  
   }// getConnectionObject() ENDS  
    */     
   //---------------------------------------------------------------------------  
   protected Connection getConnection() throws JspException {
   //---------------------------------------------------------------------------  
       if(sqlTagsConnection==null) {
           throw new JspException("No database connection available."); 
       }
       return sqlTagsConnection.getConnection();
   }
   
   public String nvl(String parameter, String defaultValue) {
      if(parameter==null || parameter.length()==0)
          return defaultValue;
      return parameter;
   }
   
   /**  
    * <code>getCurrentPage</code>  
    * <p>  
    * This method returns the current page number.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return currentPage <code>String</code> The current page number.  
    */  
   //---------------------------------------------------------------------------  
   public String getCurrentPage(){  
   //---------------------------------------------------------------------------  
      int pageSize=utilities.stringToInt(nvl(this.pageSize,maxInt+""));  
      int startRow=utilities.stringToInt(nvl(this.startRow,"1"));  
      this.currentPage=(startRow/pageSize)+"";  
      return currentPage;  
   }// getCurrentPage() ENDS  
     
   /**  
    * <code>getCurrentRow</code>  
    * <p>  
    * This method returns the current row of the cursor  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return currentRow <code>int</code> The current row of the cursor.  
    */  
   //---------------------------------------------------------------------------  
   public int getCurrentRow(){  
   //---------------------------------------------------------------------------  
      return currentRow-1;  
   }// getCurrentRow() ENDS  
     
   /**  
    * <code>getDepth</code>  
    * <p>  
    * This method returns the current depth associated with this instance..  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return depth <code>int</code> the current depth  
    */  
   //---------------------------------------------------------------------------  
   public int getDepth(){  
   //---------------------------------------------------------------------------  
      return depth;  
   }// getDepth() ENDS  
   
   /**  
    * <code>getDisplayPageSize</code>  
    * <p>  
    * This method returns how many items are to be displayed on this page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return pageSize <code>int</code> The amount of items to be displayed.  
    */  
   //---------------------------------------------------------------------------  
   public String getDisplaySize(){  
   //---------------------------------------------------------------------------  
      return pageSize;  
   }// getDisplaySize() ENDS  

   /**  
    * <code>getDisplaySize</code>  
    * <p>  
    * This method obtains the current display size for this column.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param key <code>String</code> The column to look up.  
    * @return size <code>int</code> The default size for this column.  
    */  
   //---------------------------------------------------------------------------  
   public int getDisplaySize(String key){  
   //---------------------------------------------------------------------------  
       /**
      int size=utilities.stringToInt(getColumnProperty("size",key),0);          
      return size;  
        *
        */
      return utilities.stringToInt(sqlTagsColumns.getSize(key),0);
   }// getDisplaySize() ENDS  
     
   /**  
    * <code>getException</code>  
    * <p>  
    * This method sets the encountered exception for later retrival.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param exception <code>Exception</code> The exception generated.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public Exception getException(){  
   //---------------------------------------------------------------------------  
      return exception;  
   }// getException() ENDS  
   
   /**  
    * <code>getException</code>  
    * <p>  
    * This method sets the encountered exception for later retrival.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param exception <code>Exception</code> The exception generated.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void getException(JspWriter out){  
   //---------------------------------------------------------------------------
      try{
          if(exception!=null)
              out.println(exception);
      }
      catch(IOException exception){
          exception.printStackTrace();
      }
   }// getException() ENDS  
     
   /**  
    * <code>getForeignKey</code>  
    * <p>  
    * This method gets the tables foreign key name.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return foreignKey <code>String</code> The foreign key.  
    */  
   //---------------------------------------------------------------------------  
   public String getForeignKey(){  
   //---------------------------------------------------------------------------  
      return foreignKey;  
   }// getForeignKey() ENDS  
     
   /**  
    * <code>getHandlerClass</code>  
    * <p>  
    * This method returns the handler class.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none  
    * @return handlerClass <code>String</code> The class of the handler.  
    */  
   //---------------------------------------------------------------------------  
   public String getHandlerClass(){  
      //---------------------------------------------------------------------------  
      return handlerClass;  
   }// getHandlerClass() ENDS  
     
     
   /**  
    * <code>getHandlerID</code>  
    * <p>  
    * This method returns the handler ID for this object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return handlerID <code>String</code> The handlerID name.  
    */  
   //---------------------------------------------------------------------------  
   public String getHandlerID(){  
   //---------------------------------------------------------------------------  
      return handlerID;  
   }// getHandlerID() ENDS  
     
   /**  
    * <code>getID</code>  
    * <p>  
    * This method returns the scripting variable associated with the TB_BLURBS  
    * table.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return id <code>String</code> The scripting variable name.  
    */  
   //---------------------------------------------------------------------------  
   public String getId(){  
      //---------------------------------------------------------------------------  
      return id;  
   }// getId() ENDS  
     
   /**
    *
   public String getInClause(String columnName) {
       return getColumnProperty("inclause",columnName);
   }
    *
    */
   
   /**  
    * <code>getMaxRows</code>  
    * <p>  
    * This method returns the max rows to be retrieved.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return maxRows <code>String</code> The value of maxRows.  
    */  
   //---------------------------------------------------------------------------  
   public String getMaxRows(){  
   //---------------------------------------------------------------------------  
      return maxRows;  
   }// getMaxRows() ENDS  
     
   /**  
    * <code>getObject</code>  
    * <p>  
    * This method returns the object associated with the value.
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return object <code>Object</code>the column value as an object.  
    */  
   //---------------------------------------------------------------------------  
   public Object getObject(String string){  
   //---------------------------------------------------------------------------  
       /**
        *
       ColumnProperties columnProperties=(ColumnProperties)
            columnPropertiesHash.get(string);      
       return columnProperties.getObject();
        *
        */
       return sqlTagsColumns.getObject(string);
   }//getObject() ENDS  

   /**  
    * <code>getOperation</code>  
    * <p>  
    * This method return the current type of operation were doing.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return operation <code>String</code> The operation type.  
    */  
   //---------------------------------------------------------------------------  
   public String getOperation(){  
   //---------------------------------------------------------------------------  
      return getOperation( getArrayIndex() );  
   }// getOperation() ENDS  
    
   public String getOperation(String arrayIndex){
       String operation = (String) operationHash.get(arrayIndex);
       if (operation==null)
           operation="";
       return operation;
   }
     
   /**  
    * <code>getOrderBy</code>  
    * <p>  
    * This method returns the orderBy clause for this instance.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return orderBy <code>String</code> The order by clause.  
    */  
   //---------------------------------------------------------------------------  
   public String getOrderBy(){  
      //---------------------------------------------------------------------------  
      return orderBy;  
   }// getOrderBy() ENDS  
     
   /**  
    * <code>getPaging</code>  
    * <p>  
    * This method returns whether or not paging has been enabled.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return true <code>String</code> if paging has been enabled.  
    */  
   //---------------------------------------------------------------------------  
   public String getPaging(){  
   //---------------------------------------------------------------------------  
      return paging.toLowerCase();  
   }// getPaging() ENDS  
     
   /**  
    * <code>getPageSize</code>  
    * <p>  
    * This method returns how many items are to be displayed on this page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return pageSize <code>int</code> The amount of items to be displayed.  
    */  
   //---------------------------------------------------------------------------  
   public int getPageSize(){  
   //---------------------------------------------------------------------------  
      return utilities.stringToInt(pageSize);  
   }// getPageSize() ENDS  

   /**  
    * <code>getParentName</code>  
    * <p>  
    * This method gets the tables parentName.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return parentName <code>String</code> The parent name.  
    */  
   //---------------------------------------------------------------------------  
   public String getParentName(){  
   //---------------------------------------------------------------------------  
      return parentName;  
   }// getParentName() ENDS  
     
   /**  
    * <code>getPreInsertSQL</code>  
    * <p>  
    * This method return the insert instruction.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return preInsertSQL <code>String</code> The instruction to run before  
    *        the insert statement.  
    */  
   //---------------------------------------------------------------------------  
   public String getPreInsertSQL(){  
      //---------------------------------------------------------------------------  
      return preInsertSQL;  
   }// getPreInsertSQL() ENDS  
     
   /**  
    * <code>getPreUpdateSQL</code>  
    * <p>  
    * This method gets the instruction to process before the update statement.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return preUpdateSQL <code>String</code> The instruction to run before  
    *        doing a update.  
    */  
   //---------------------------------------------------------------------------  
   public String getPreUpdateSQL(){  
   //---------------------------------------------------------------------------  
      return preUpdateSQL;  
   }// getPreUpdateSQL() ENDS  
     
   /**  
    * <code>getPreviousRow</code>  
    * <p>  
    * This method returns the number for the previous start.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return previousStart <code>int</code> The start location for the  
    *        previous page of results which were displayed.  
    */  
   //---------------------------------------------------------------------------  
   private int getPreviousRow(){  
   //---------------------------------------------------------------------------  
      int size=getPageSize();  
      int previousStart=currentRow-(size*2);  
        
      if(previousStart<size)  
         previousStart=0;  
        
      return previousStart;  
   }// getPreviousRow() ENDS  
     
   /**  
    * <code>getPrimaryKeys</code>  
    * <p>  
    * This method returns whether or not paging has been enabled.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return true <code>String</code> if paging has been enabled.  
    */  
   /*
   //---------------------------------------------------------------------------  
   public String getPrimaryKeys(){  
   //---------------------------------------------------------------------------  
      return primaryKeys;  
   }// getPrimaryKeys() ENDS  
    */
     
  
   public String getProperty(String p){
       if( sqlTagsConnection!=null){
           return sqlTagsConnection.getProperty(p);
       }
       return null;
   }
   
   public String getProperty(String p, String d){
       if( sqlTagsConnection!=null){
           return sqlTagsConnection.getProperty(p,d);
       }
       return d;       
   }
   
   /**  
    * <code>getResultSetSize</code>  
    * <p>  
    * This method returns the size of the result set.
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param  <code>none</code> 
    * @return value <code>int</code> The size of the result set. 
    *        column.  
    */  
   //---------------------------------------------------------------------------  
   public int getResultSetSize(){  
   //---------------------------------------------------------------------------  
      return resultSetSize; 
   }// getResultSetSize() ENDS  
     
   /**  
    * <code>getSql</code>  
    * <p>  
    * This method returns the current sql statement associated with this object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return sql <code>String</code> The current sql statement.  
    */  
   //---------------------------------------------------------------------------  
   public String getSql(){  
      //---------------------------------------------------------------------------  
      return sql;  
   }// getSql() ENDS  
     
   /**  
    * <code>getSQLTagsHandler</code>  
    * <p>  
    * This method get the next start page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return getSQLTagsHandler <code>Strign</code> The next page to display.  
    */  
   //---------------------------------------------------------------------------  
   public SQLTagsHandler getSQLTagsHandler(){  
   //---------------------------------------------------------------------------  
      return sqlTagHandler;  
   }// getSQLTagsHandler()  
   
   /**  
    * <code>getSQLTagsRequest</code>  
    * <p>  
    * This method returns the sqlTagRequest
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return sqlTagRequest<code>SQLTagsRequest</code> a SQLTagsRequest  object.
    */  
   //---------------------------------------------------------------------------  
   public HttpServletRequest getSQLTagsRequest(){  
   //---------------------------------------------------------------------------  
      return sqlTagRequest;
   }// getSQLTagsRequest() ENDS  
   
   /**  
    * <code>getSQLTagsRequestParameter</code>  
    * <p>  
    * This method returns a parameter from the SQLTagsRequest.
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param string <code>String</code> the parameterName.  
    * @return value<code>String</code>the parameter's value.
    */  
   //---------------------------------------------------------------------------  
   public String getSQLTagsRequestParameter(String string){  
   //---------------------------------------------------------------------------  
      return sqlTagRequest.getParameter(string);
   }// getSQLTagsRequestParameter() ENDS  
   
   /**  
    * <code>getStartPage</code>  
    * <p>  
    * This method get the next start page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return startPage <code>Strign</code> The next page to display.  
    */  
   //---------------------------------------------------------------------------  
   public String getStartPage(){  
      //---------------------------------------------------------------------------  
      return startPage;  
   }// getStartPage() ENDS  
     
   /**  
    * <code>getStartRow</code>  
    * <p>  
    * This method returns the current start row associated with the paging of  
    * this object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return startRow <code>String</code> The first row in the next iteration.  
    */  
   //---------------------------------------------------------------------------  
   public String getStartRow(){  
   //---------------------------------------------------------------------------  
      return startRow;  
   }// getStartRow() ENDS  

   /**  
    * <code>getFrom</code>  
    * <p>  
    * This method gets the current where clause.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return where <code>String</code> The current where clause.  
    */  
   //---------------------------------------------------------------------------  
   public String getFrom(){  
   //---------------------------------------------------------------------------  
      return from;  
   }// getFrom() ENDS  
   
   /**  
    * <code>getWhere</code>  
    * <p>  
    * This method gets the current where clause.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return where <code>String</code> The current where clause.  
    */  
   //---------------------------------------------------------------------------  
   public String getWhere(){  
   //---------------------------------------------------------------------------  
      return where;  
   }// getWhere() ENDS  
   
     
   /**
    *
   //---------------------------------------------------------------------------  
   public boolean isBaseTable(String columnName) {
   //---------------------------------------------------------------------------  
       ColumnProperties cp = (ColumnProperties) columnPropertiesHash.get(columnName);
       if(cp!=null && cp.isBaseTable())
           return true;
       return false;
   }
    *
    */
     
     
   //***************************************************************************  
   //                      Class mutator section  
   //***************************************************************************  
   /**  
    * <code>setButtonName</code>  
    * <p>  
    * This method sets the current operation type.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param buttonName <code>String</code> The current operation type.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setButtonName(String buttonName){  
   //---------------------------------------------------------------------------  
       operationName=buttonName;
   }// setButtonName() ENDS  
     
     
     
   public void setCacheScheme(String c){ cacheScheme=c;}
   public void setCacheSize(String c){ cacheSize=c;} 
   public void setCaching(String c){ caching=c.trim().toLowerCase();}
     
   /**  
    * <code>setChildName</code>  
    * <p>  
    * This method sets the child name.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return parentName <code>String</code> The parent name.  
    */  
   //---------------------------------------------------------------------------  
   public void setChildName(String childName){  
   //---------------------------------------------------------------------------  
      this.childName=childName;  
   }// setChildName() ENDS  
     
   /**  
    * <code>setColumnProperties</code>  
    * <p>  
    * This method will update the value within the ColumnProperties object. This  
    * object is stored within a hashtable.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param name <code>String</code> The name of the property.  
    * @param key <code>String</code> The the column name.  
    * @param value <code>String</code> The the column value.  
    * @return none <code>none</code> none.  
    */  
   /***
    *
    *
   //---------------------------------------------------------------------------  
   public void setColumnProperty(String name, String key, String value){  
   //---------------------------------------------------------------------------  
       setColumnProperty(name,key,value,getArrayIndex());
   }// setColumnProperty() ENDS  
   
   //---------------------------------------------------------------------------  
   protected void setColumnPropertiesHash(Hashtable columnPropertiesHash){
   //---------------------------------------------------------------------------   
      this.columnPropertiesHash=columnPropertiesHash;
   }
   
   //---------------------------------------------------------------------------  
   public void setColumnProperty( String name,String key,String value
                                 ,String ArrayIndex){
   //---------------------------------------------------------------------------   
      key=key.toUpperCase();  
      ColumnProperties item=(ColumnProperties)columnPropertiesHash.get(key);  
        
      if(item!=null){
         if(name.equalsIgnoreCase("selectFormat"))
            item.setSelectFormat(value);
         else if(name.equalsIgnoreCase("bind"))
            item.setBind(value);
         else  if(name.equalsIgnoreCase("ignoreArrayIndex")) {
             //Boolean b=new Boolean(value);
             item.setIgnoreArrayIndex(Boolean.valueOf(value).booleanValue());
         }
         else if(name.equalsIgnoreCase("type"))
            item.setType(value);
         else if(name.equalsIgnoreCase("value"))
            item.setValue(value,arrayIndex);
         
         columnPropertiesHash.put(key,item);  
      }  
   }// setColumnProperty() ENDS  
    *
    */
     
   /**  
    * <code>setColumns</code>  
    * <p>  
    * This method sets the columns to be retrieved from the database.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param columns <code>String</code> a comma demilited list of columns.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setColumns(String columns){  
   //---------------------------------------------------------------------------  
      this.columns=columns.toUpperCase();  
      setColumns();  
   }// setColumns() ENDS  
     
   /**  
    * <code>setColumnValue</code>  
    * <p>  
    * This method sets the current on an individual table colun.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param key <code>String</code> The key to the column.  
    * @param value <code>String</code> The value of the column.  
    * @return none <code>none</code> none  
    */  
   /**
    *
   //---------------------------------------------------------------------------  
   public void setColumnValue(String key, String value){  
   //---------------------------------------------------------------------------  
       setColumnValue(key,value,getArrayIndex());
   }// setColumnValue() ENDS  
    *
    */
   
   /**
    *
   //---------------------------------------------------------------------------  
   public void setColumnValue(String key, String value, String arrayIndex){  
   //---------------------------------------------------------------------------  
      setColumnProperty("value",key,value,arrayIndex);  
      addArrayIndex(arrayIndex); // keeps track of all arrayIndex values
   }// setColumnValue() ENDS
    *
    */
     
   //---------------------------------------------------------------------------  
   public void setSQLTagsConnection(SQLTagsConnection sqlTagsConnection){
   //---------------------------------------------------------------------------  
       this.sqlTagsConnection=sqlTagsConnection;
   }     
     
   //---------------------------------------------------------------------------  
   public SQLTagsConnection getSQLTagsConnection(){
   //---------------------------------------------------------------------------  
       return this.sqlTagsConnection;
   } 
   /**  
    * <code>setCurrentPage</code>  
    * <p>  
    * This method sets the value for the current page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param value <code>String</code> The value for the current page.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setCurrentPage(String value){  
   //---------------------------------------------------------------------------  
      this.currentPage=value;  
      int currentPage=utilities.stringToInt(nvl(value,"1"));  
      int pageSize=utilities.stringToInt(nvl(this.pageSize,maxInt+""));  
      startRow=(currentPage*pageSize)+"";  
   }// setCurrentPage() ENDS  
     
   /**  
    * <code>setCurrentRow</code>  
    * <p>  
    * Sets the current row.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param currentRow <code>int</code> The current row.  
    * @return nonecurrentRow <code></code>  
    */  
   //---------------------------------------------------------------------------  
   private void setCurrentRow(int currentRow){  
      //---------------------------------------------------------------------------  
      this.currentRow=currentRow;  
   }// setCurrentRow() ENDS  
     
     
   /**  
    * <code>setDepth</code>  
    * <p>  
    * This method sets the depth.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param depth <code>int</code> The new depth.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setDepth(String depth){  
   //---------------------------------------------------------------------------  
      this.depth=utilities.stringToInt(depth);  
   }// setDepth() ENDS
     
   
   /**  
    * <code>setDistinct</code>  
    * <p>  
    * This method enables you to select distinct records
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param exception <code>Exception</code> The exception generated.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setDistinct(String distinct){
      this.distinct=distinct;
   }
   
   /*
    *
   //ISQLListener implementation
   public void setException(SQLEvent event){
       setException( new Exception(event.toString()) );
   }
    *
    */
   
   /**  
    * <code>setException</code>  
    * <p>  
    * This method sets the encountered exception for later retrival.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param exception <code>Exception</code> The exception generated.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setException(Exception exception){  
   //---------------------------------------------------------------------------  
      this.exception=exception;  
      log.warning("setException:"+this.getClass()+": " +exception+", CAUSE: " + exception.getCause());
   }// setException() ENDS  
     
   /**  
    * <code>setExceptionString</code>  
    * <p>  
    * This method creates a user defined exception and sets it as the current  
    * exception.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param message <code>String</code> The exception message.  
    * @return true <code>boolean</code> true if exception successfully set.  
    */  
   //---------------------------------------------------------------------------  
   public boolean setExceptionString(String message){  
      boolean returnValue=true;  
        
      try{  
         Exception exception=new Exception(message);  
         setException(exception);  
      }  
      catch(Exception exception){  
         returnValue=false;  
      }  
        
      return returnValue;  
   }// setException() ENDS  
   
   /**  
    * <code>setFirstRecord</code>  
    * <p>  
    * This method indicates whether this is the first record read.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param firstRecord <code>boolean</code> true if this is the first  
    *        record.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setFirstRecord(boolean firstRecord){  
   //---------------------------------------------------------------------------  
      this.firstRecord=firstRecord;  
   }// setFirstRecord() ENDS  
     
   /**  
    * <code>setForeignKey</code>  
    * <p>  
    * This method tables foreign key.  
    * object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param foreignKey <code>String</code> the foreign key.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setForeignKey(String foreignKey){  
   //---------------------------------------------------------------------------  
      this.foreignKey=foreignKey;  
   }// setForeignKey() ENDS  
     
   /**  
    * <code>setLastRecordOnPage</code>  
    * <p>  
    * This method indicates whether this is the first record read.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param firstRecord <code>boolean</code> true if this is the first  
    *        record.  
    * @return none <code>none</code> none.  
    */  
   /*
   //---------------------------------------------------------------------------  
   public void setLastRecordOnPage(boolean lastRecordOnPage){  
      //---------------------------------------------------------------------------  
      this.lastRecordOnPage=lastRecordOnPage;  
   }// setLastRecordOnPage() ENDS  
    */
     
   /**  
    * The <b><code>setFKParent</code></b> method is overloaded, its used to call  
    * the setFKParent(int depth) method passing in a depth of  
    * one.  
    * @author  Booker Northington II  
    * @version 1.0  
    * @param   none.  
    * @return  none  
    * @since   JDK1.3  
    */  
   //---------------------------------------------------------------------------  
   public void setFKParent(){  
   //---------------------------------------------------------------------------  
      setFKParent(depth);  
      return;  
   }//setFKParent() ENDS  
     
   /**  
    * <code>setHandlerClass</code>  
    * <p>  
    * This method sets the handler class.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param handlerClass <code>String</code> The handler class.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setHandlerClass(String handlerClass){  
   //---------------------------------------------------------------------------  
     sqlTagHandler=(SQLTagsHandler) utilities.factory(handlerClass);
     // sqlTagHandler.setPageContext(pageContext);

     if(sqlTagHandler==null)       
         sqlTagHandler=new SQLTagsHandler();
     
     this.handlerClass=handlerClass;  
   }// setHandlerClass() ENDS  
     
     
   /**  
    * <code>setHandler</code>  
    * <p>  
    * This method sets the handler id.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param handlerID <code>String</code> The handler id.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setHandlerID(String handlerID){  
   //---------------------------------------------------------------------------  
      this.handlerID=handlerID;  
   }// setHandlerID() ENDS  
     
   /**  
    * <code>setHasFetch</code>  
    * <p>  
    * This method sets the value of the hasFetch property. If set to true, a  
    * fetch has already been done.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param value <code>String</code> The new value of the hasFetch property.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setHasFetch(String value){  
   //---------------------------------------------------------------------------  
      hasFetch=false;  
        
      if(value.equalsIgnoreCase("true"))  
         hasFetch=true;  
   }// setHasFetch() ENDS  
     
   /**  
    * <code>setID</code>  
    * <p>  
    * This method sets the name of the scripting variable associated with this  
    * tag.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param id <code>String</code> The name of the scripting variable.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setId(String id){  
   //---------------------------------------------------------------------------  
      this.id=id;  
   }// setId() ENDS  
     
   /**  
    * <code>setItemDisplayCount</code>  
    * <p>  
    * This method set the number of items currently displayed when caching.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param itemDisplayCount <code>int</code> the value.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setItemDisplayCount(int itemDisplayCount){  
   //---------------------------------------------------------------------------  
      this.itemDisplayCount=itemDisplayCount;  
   }//setItemDisplayCount() ENDS  
     
   /**  
    * <code>setLastRecord</code>  
    * <p>  
    * This method indicates whether this is the last record within the result  
    * set.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param lastRecord <code>boolean</code> true, if this is the last  
    *        record within this result set.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setLastRecord(boolean lastRecord){  
   //---------------------------------------------------------------------------  
      this.lastRecord=lastRecord;  
   }// setLastRecord() ENDS  
     
   /**  
    * <code>setMaxRows</code>  
    * <p>  
    * This method sets the value of the maxRow attribute.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param maxRows <code>String</code> The value for maxRows.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setMaxRows(String maxRows){  
   //---------------------------------------------------------------------------  
      this.maxRows=maxRows;  
   }// setMaxRows() ENDS  
     
     
   /**  
    * <code>setOperation</code>  
    * <p>  
    * This method sets the current operation type.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param operation <code>String</code> The operation type.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setOperation(String operation){  
      //---------------------------------------------------------------------------  
      setOperation(operation, getArrayIndex() );  
   }// setOperation() ENDS  
   public void setOperation(String operation, String arrayIndex){
       operationHash.put(arrayIndex,operation);
   }
     
   /**  
    * <code>setOrderBy</code>  
    * <p>  
    * This method sets the order by clause of the current select statement.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param value <code>String</code> The order by value.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setOrderBy(String orderBy){  
   //---------------------------------------------------------------------------  
      setWhere(orderBy);  
   }// setOrderBy() ENDS  
     
   /**  
    * <code>setPageSize</code>  
    * <p>  
    * This method set the current page size.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param pageSize <code>String</code> The size for the current page.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setPageSize(String pageSize){
   //---------------------------------------------------------------------------  
      int size=utilities.stringToInt(pageSize,0);  
      this.pageSize=size+"";  
        
      if(this.pageSize.equals("0"))  
         this.pageSize=Integer.MAX_VALUE+"";  
   }// setPageSize() ENDS  
   
   /**  
    * <code>setPageSize</code>  
    * <p>  
    * This method set the current page size.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param pageSize <code>String</code> The size for the current page.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setDisplaySize(String displayPageSize){
   //---------------------------------------------------------------------------  
      this.displayPageSize=displayPageSize;
       setPageSize(displayPageSize);
   }// setMyPageSize() ENDS  
     
   /**  
    * <code>setPaging</code>  
    * <p>  
    * This method set the paging attribute.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param paging <code>String</code> true if paging is enabled.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setPaging(String paging){  
   //---------------------------------------------------------------------------  
      if(!paging.equalsIgnoreCase("true")&&!paging.equalsIgnoreCase("false"))  
         paging="false";  
        
      this.paging=paging;  
        /*
      if(paging.equalsIgnoreCase("true")){  
         if((String)pageContext.getRequest().getParameter("pageSize")!=null)  
            setPageSize(  
                (String)pageContext.getRequest().getParameter("pageSize"));  
           
         if((String)pageContext.getRequest().getParameter(getStartRowParameter())!=null)  
            startRow=(String)pageContext.getRequest().getParameter(getStartRowParameter());  
      }  
         **/
   }// setPaging() ENDS  
     
   /**  
    * <code>setParent</code>  
    * <p>  
    * This method tables foreign key.  
    * object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param parentName <code>String</code> the parentName.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setParentName(String parentName){  
      //---------------------------------------------------------------------------  
      this.parentName=parentName;  
   }// setParentName() ENDS  
     
   /**  
    * <code>setPreInsertSQL</code>  
    * <p>  
    * This method defines the instructions done before a insert.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param preInsertSQL <code>String</code> The instruction to run.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setPreInsertSQL(String preInsertSQL){  
   //---------------------------------------------------------------------------  
      this.preInsertSQL=preInsertSQL;  
   }// setPreInsertSQL() ENDS  
     
   /**  
    * <code>setPreUpdateSQL</code>  
    * <p>  
    * This method sets the instruction to process before an update is done.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param preUpdateSQL <code>String</code> The instruction to process.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setPreUpdateSQL(String preUpdateSQL){  
   //---------------------------------------------------------------------------  
      this.preUpdateSQL=preUpdateSQL;  
   }// setPreUpdateSQL() ENDS  
     
   /**  
    * <code>setPrimaryKeys</code>  
    * <p>  
    * This method returns whether or not paging has been enabled.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return true <code>String</code> if paging has been enabled.  
    */  
   /*
   //---------------------------------------------------------------------------  
   public void setPrimaryKeys(String primaryKeys){  
   //---------------------------------------------------------------------------  
      this.primaryKeys=primaryKeys;  
   }// setPrimaryKeys() ENDS  
    */
     
   /**  
    * <code>setProperties</code>  
    * <p>  
    * This method set the properties object. If the value of this variable is  
    * true, all the parameters currently within the request object are read  
    * and if any values read from the request object are within the TB_BLURBS  
    * table, TB_BLURBS will initialize itself to those values.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param properties <code>String</code> if true, the TB_BLURBS initializes  
    *        itself from the request object.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   public void setProperties(String properties){  
  //---------------------------------------------------------------------------  
      this.properties=properties;  
   }// setProperties() ENDS  
   
   /** Setter for properties property
    */
   public String getProperties(){
       return this.properties;
   }
     
   /**  
    * <code>setRequestProperties</code>  
    * <p>  
    * This method set the column properties based on the request object.
    * </p>  
    * @author  Steve Olson
    * @param none <code>none</code>none.
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------
   public void setRequestProperties(){
   //---------------------------------------------------------------------------
       if(pageContext!=null){
           HttpServletRequest servletRequest = (HttpServletRequest)pageContext.getRequest();
           
           if(servletRequest!=null){
               // startRow is a special case parameter ...
               if( nvl(servletRequest.getParameter("paging"), "").equalsIgnoreCase("true")) {
                   setStartRow(nvl(servletRequest.getParameter(getStartRowParameter()), "0"));
               }
               log.finer("setRequestProperties:processing Parameters for "+ getTableName());
               Enumeration enum=servletRequest.getParameterNames();
               
               while( enum.hasMoreElements()){
                   String parameterName = (String)enum.nextElement();
                   String parameterValue= servletRequest.getParameter( parameterName );
                   String columnName = parameterName.toUpperCase();
                   String preFix = "";

                   int sepLocation=parameterName.indexOf('.');
                   if( sepLocation > -1){
                       // got the separator, check for match w/ tableAlias
                       preFix = parameterName.substring(0, sepLocation);
                       if( preFix.equalsIgnoreCase(nvl(getTableAlias(),getTableName())) ){
                           // A match! ... bump past separator
                           sepLocation++;
                       } else {
                           // belongs to another tag ... we'll pass on this one
                           sepLocation=0;
                           // log.fine("setRequestProperties: preFix != table, skipping: " + preFix);
                           // not sure why i didn't have this here before ... 
                           continue;
                       }
                   } else {
                       sepLocation=0;
                   }
                   
                   String arrayIndex = "0";
                   int arrayStart=parameterName.indexOf('[');
                   int arrayEnd=parameterName.indexOf(']');
                   
                   if( arrayStart<arrayEnd && arrayStart != -1) {
                        arrayIndex = parameterName.substring(arrayStart+1,arrayEnd);
                        columnName = parameterName.substring(sepLocation,arrayStart).toUpperCase();
                   } else if( sepLocation>0) {
                        columnName = parameterName.substring(sepLocation).toUpperCase();
                   }

                   if(columnName.equalsIgnoreCase(operationName)){
                       setOperation(parameterValue,arrayIndex);
                       // may want to double check that OPERATION is not 
                       // a valid column in the currnet
                       // table ... would be nice to give an error ... 
                       continue;
                   }
                   SQLTagsColumn col = sqlTagsColumns.get(columnName);
                   
                   // log.finest("setRequestProperties:"+ columnName+"["+arrayIndex+"]="+parameterValue);
                   
                   if( col != null ) {
                       if( arrayStart<arrayEnd ) {
                           // This means that we got an Array formated variable
                           // Therefore we only need to get that single Value
                           log.finest("setRequestProperties:"+getTableName()+":"+ columnName+"["+arrayIndex+"]="+parameterValue);
                           col.setValue(parameterValue,arrayIndex);
                           addArrayIndex(arrayIndex);
                       }
                       else {
                           // OK, no Array format; however, w/
                           // multi-selectors out there
                           // there could be a list of values.
                           String parameterValues[]=
                           servletRequest.getParameterValues( parameterName );
                           int index = 0;
                           
                           for (;index <parameterValues.length;index++){
                               log.finest("setRequestProperties:"+getTableName()+":"+ columnName+"["+Integer.toString(index)+"]=" +parameterValues[index]);
                               col.setValue( parameterValues[index],Integer.toString(index));
                               addArrayIndex(Integer.toString(index));
                           }
                       }
                   }
                   // columnProperties IS NULL ... 
                   else {
                       // didn't find the COLUMN in the columnProperties ... hum ...
                       // perhaps we should add it w/ basetable=false just so 
                       // it is available as a bind variable ... :)
                       if( sepLocation>0) {
                           // Ok, if we have set sepLocation>0 it means we've 
                           // checked and double checked and that this _IS_
                           // a match for the tableAlias ... so ... we'll add a
                           // new columnprop and set it as baseTable=false
                           /**
                           ColumnProperties cp = new ColumnProperties(
                                                                 columnName.toUpperCase(),
                                                                 "0",
                                                                 "'"+parameterValue+"'",
                                                                 "String",
                                                                 "?",
                                                                 parameterValue,
                                                                 new Object()
                                                                );
                           // oops one more not in constructor .. 
                           cp.setBaseTable(false); // keeps this out of insert/update
                           cp.setValue(parameterValue,arrayIndex); // need arrayValue
                           columnPropertiesHash.put(columnName.toUpperCase(),cp);
                            */
                            col = new SQLTagsColumn(
                                                columnName.toUpperCase()  // name
                                               ,parameterValue            // value
                                               ,arrayIndex                // array
                                               ,"STRING"                  // type
                                               ,Types.VARCHAR             // sqlType
                                               ,""+parameterValue.length() // size
                                               ,""                        // format
                                               ,"?"                       // bindformat
                                               ,columnName.toUpperCase()  // selectFormat
                                               ,false                     // baseTable
                                               );
                            log.finest("setRequestProperties:"+getTableName()+": adding non-basetable field: " + columnName + " at " + sepLocation);
                            sqlTagsColumns.add(col);
                           addArrayIndex(arrayIndex); // for iterator ... 
                       }
                   }
               }
               log.finest("setRequestProperties:done.");
           }
       }
       
   }// setRequestProperties ENDS
     
   /**  
    * <code>setSql</code>  
    * <p>  
    * This method sets the current sql statement associated with this object.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param sql <code>String</code> the sql statement.  
    * @return none <code></code>  
    */  
   //---------------------------------------------------------------------------  
   public void setSql(String sql){  
   //---------------------------------------------------------------------------  
      this.sql=sql;  
   }  
     
   //---------------------------------------------------------------------------  
   private boolean isSelectStatement(String sql){  
   //---------------------------------------------------------------------------  
      String select="";  
      boolean returnValue=false;  
        
      if(sql!=null){  
         select=sql.trim().toLowerCase().substring(0,6);  
           
         if(select.equalsIgnoreCase("select")&&!isOpen())  
            returnValue=true;  
      }  
        
      return returnValue;  
   }  
     
   /**  
    * <code>setStartPage</code>  
    * <p>  
    * This method sets the next start page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param value <code>String</code> The value of the next start page.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setStartPage(String value){  
   //---------------------------------------------------------------------------  
      this.startPage=value;  
      int startPage=utilities.stringToInt(nvl(this.startPage,maxInt+""));  
      int startRow=utilities.stringToInt(nvl(this.startRow,"1"));  
      this.startRow=(startRow/startPage)+"";  
   }// setStartPage() ENDS  
     
     
     
   /**  
    * <code>setStartRow</code>  
    * <p>  
    * This method sets the start row for the next iteration.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param startRow <code>String</code> The first row to display when  
    *        the next link is pressed.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setStartRow(String startRow){  
      //---------------------------------------------------------------------------  
      this.startRow=nvl(startRow, "0");  
      boolean validStartRow=true;  
      int startValue=utilities.stringToInt(startRow);  
      int pageSize=utilities.stringToInt(this.pageSize);  
      /**
      nextLink=startValue+pageSize;  
      prevLink=startValue-pageSize;  

      if(prevLink<0)  
         prevLink=0;  
       */
        
   }// setStartRow() ENDS  
     
   /**  
    * <code>setStopRow</code>  
    * <p>  
    * sets how many records will be displayed on the current page.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param stopRow <code>int</code> the last row to display.  
    * @return  <code>none</code>  
    */  
   /**
   //---------------------------------------------------------------------------  
   private void setStopRow(int stopRow){  
   //---------------------------------------------------------------------------  
      this.stopRow=stopRow;  
   }
    */
   
   /**  
    * <code>setFrom</code>  
    * <p>  
    * This method sets the where clause.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param where <code>String</code> The where clause.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setFrom(String from){  
   //---------------------------------------------------------------------------  
      if(from!=null)  
         this.from=from;  
      else  
         from="";  
   }// setFrom() ENDS  
   
   /**  
    * <code>setWhere</code>  
    * <p>  
    * This method sets the where clause.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param where <code>String</code> The where clause.  
    * @return none <code>none</code> none  
    */  
   //---------------------------------------------------------------------------  
   public void setWhere(String where){  
   //---------------------------------------------------------------------------  
      if(where!=null)  
         this.where=where;  
      else  
         where="";  
   }// setWhere() ENDS  
     

   /**
    *
   private void readClobBlobLong(String key){  
      String type=getColumnProperty("type",key);  
      StringBuffer buffer=new StringBuffer();  
      String data=null;
      setColumnTypes();
      
      try{  
        if(isColumnTypeValid(asciiStreamColumns,type)) {
            data=getAsciiStream(resultSet,key);
        }

        else if(isColumnTypeValid(characterStreamColumns,type)) {
            data=getCharacterStream(resultSet,key);
        }
        else if(isColumnTypeValid(binaryStreamColumns,type)) {
            data=getBinaryStream(resultSet,key);
        }
         
        if(data!=null)
           setColumnValue(key,data);  
      }  
      catch(IOException exception){  
         log(getTableName()+".readClobBlobLong: "+exception);  
      }  
      catch(SQLException exception){  
         log(getTableName()+".readClobBlobLong: "+exception);  
      }  
   }//readClobBlobLong() ENDS  
    *
    */
     
   //***************************************************************************  
   // Private Methods  
   //***************************************************************************  
   /**  
    * <code>bumpItemDisplayCount</code>  
    * <p>  
    * This method increments the number of items displayed while caching.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param <code>none</code>  
    * @return <code>none</code>  
    */  
   //---------------------------------------------------------------------------  
   private void bumpItemDisplayCount(){  
   //---------------------------------------------------------------------------  
      itemDisplayCount=itemDisplayCount+1;  
   }  
   
   /**  
    * <code>getAsciiStream</code>  
    * <p>  
    * 
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @return results <code>String</code> data read.  
    */  
   
   /**
    *
   //--------------------------------------------------------------------------- 
   private String getAsciiStream(ResultSet resultSet,String key)
            throws SQLException,IOException{
   //--------------------------------------------------------------------------- 
        InputStream inputStream=null;
        StringBuffer buffer=new StringBuffer();
        String results=null;
        int charByte=0;
     
        if(resultSet.getAsciiStream(key)!=null){
            inputStream=resultSet.getAsciiStream(key);  

             if(inputStream!=null){  
                while((charByte=inputStream.read())!=-1)  
                   buffer.append((char)charByte);  

                results=buffer.toString();
             }
        }
        return results;
   }//getAsciiStream() ENDS
    *
    */
   
   /**  
    * <code>getBinaryStream</code>  
    * <p>  
    * 
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @return results <code>String</code> data read.  
    */  
   
   /**
    *
   //--------------------------------------------------------------------------- 
   private String getBinaryStream(ResultSet resultSet,String key)
            throws SQLException,IOException{
   //--------------------------------------------------------------------------- 
        InputStream inputStream=null;
        StringBuffer buffer=new StringBuffer();
        String results=null;
        int charByte=0;
        
        if(resultSet.getBinaryStream(key)!=null){
            inputStream=resultSet.getBinaryStream(key);  

             if(inputStream!=null){  
                while((charByte=inputStream.read())!=-1)  
                   buffer.append((char)charByte);  

                results=buffer.toString();
             }
        }
        return results;
   }//getBinaryStream() ENDS
    *
    */
   
   /**  
    * <code>getCharacterStream</code>  
    * <p>  
    * 
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @return results <code>String</code> data read.  
    */  
   
   /**
    *
   //--------------------------------------------------------------------------- 
   private String getCharacterStream(ResultSet resultSet,String key)
        throws SQLException,IOException{
   //---------------------------------------------------------------------------  
       Reader reader=null;
       StringBuffer buffer=new StringBuffer();
       String results=null;
       int aCharacter=0;
       
        if(resultSet.getCharacterStream(key)!=null)
           reader=resultSet.getCharacterStream(key);  
       
       if(reader!=null){
           while((aCharacter=reader.read())!=-1)
               buffer.append((char)aCharacter);

            results=buffer.toString();
           
        }
       
       return results;
    }//getCharacterStream() ENDS
    *
    */
        
   /**
    *
   //---------------------------------------------------------------------------  
   private boolean isLOBS(){  
   //---------------------------------------------------------------------------  
      boolean lobs=false;  
      Enumeration enum=columnPropertiesHash.keys();  
        
      // update the column properties  
      for(;enum.hasMoreElements();){  
         String key=((String)enum.nextElement()).toUpperCase();            
         String columnType=getColumnProperty("type",key).toUpperCase();  
           
         if(characterStreamColumns.contains(columnType)){  
            lobs=true;  
            break;  
         }  
         else if(binaryStreamColumns.contains(columnType)){  
            lobs=true;  
            break;  
         }  
      }  
        
      return lobs;  
   }// isLOBS() ENDS  
    *
    */
     
   /**  
    * <code>isOpen</code>  
    * <p>  
    * This method returns the state of the cursor.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param none <code>none</code> none.  
    * @return mutipleOpen <code>boolean</code> true, if the cursor is open.  
    */  
   //---------------------------------------------------------------------------  
   private boolean isOpen(){  
   //---------------------------------------------------------------------------  
      return multipleOpen;  
   }// isOpen() ENDS  
     
   /**  
    * <code>isOpen</code>  
    * <p>  
    * This method sets the cursor state. If it is set to true, the result set  
    * is currently open.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param mutipleOpen <code>boolean</code> true, if the cursor is currently  
    *        opened.  
    * @return none <code>none</code> none.  
    */  
   //---------------------------------------------------------------------------  
   private void isOpen(boolean multipleOpen){  
   //---------------------------------------------------------------------------  
      this.multipleOpen=multipleOpen;  
   }// isOpen() ENDS  
     
   /**  
    * <code>setAsciiStream</code>  
    * <p>  
    *  Sets the prepared statements ascii stream
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @return results <code>String</code> data read.  
    */  
   
   //--------------------------------------------------------------------------- 
   private void setAsciiStream(PreparedStatement ps, byte[] data, int index)
        throws SQLException{
   //---------------------------------------------------------------------------  
       int size=data.length;  
       ByteArrayInputStream byteStream=new ByteArrayInputStream(data);  
       ps.setAsciiStream(index,byteStream,size);  
    }//setAsciiStream() ENDS
   
   /**  
    * <code>setBinaryStream</code>  
    * <p>  
    *  Sets the prepared statements binary stream
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @return results <code>String</code> data read.  
    */  
   
   //--------------------------------------------------------------------------- 
   private void setBinaryStream(PreparedStatement ps, byte[] data, int index)
        throws SQLException{
   //---------------------------------------------------------------------------  
     int size=data.length;
     InputStream inputStream=new ByteArrayInputStream(data);
     ps.setBinaryStream(index,inputStream,size);
    }//setBinaryStream() ENDS
     
   /**  
    * <code>setCharacterStream</code>  
    * <p>  
    *   
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @return results <code>String</code> data read.  
    */  
   //--------------------------------------------------------------------------- 
   private void setCharacterStream(PreparedStatement ps, String data, int index)
        throws SQLException{
   //---------------------------------------------------------------------------  
       int size=data.length();
       StringReader reader=new StringReader(data);
       ps.setCharacterStream(index,(Reader)reader,size);
    }//setCharacterStream() ENDS
   

   /**  
    * <code>setLobHash</code>  
    * <p>  
    * This method allows set the lob hashtable.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param  <code>none</code>  
    * @return <code>none</code>  
    */  
   
   /*
    *
   //---------------------------------------------------------------------------  
   private void setLobHash(PreparedStatement preparedStatement){  
      //---------------------------------------------------------------------------  
      String columnName="";  
      int size=0;  
      long byteOffset=1;  
      lobHash=new Hashtable();
        
      try{  
         ResultSet resultSet=preparedStatement.getResultSet();  
         resultSet.next();  
         ResultSetMetaData metaData=resultSet.getMetaData();  
         size=metaData.getColumnCount()+1;  
           
         for(int index=1;index<size;index++){  
            // Enumeration enum=columnPropertiesHash.keys();  
            Enumeration enum=sqlTagsColumns.keys();  
            columnName=metaData.getColumnName(index);  
              
            for(;enum.hasMoreElements();){  
               String key=((String)enum.nextElement());  
               SQLTagsColumn col = sqlTagsColumns.get(key);
                 
               if(key.equalsIgnoreCase(columnName) && col!=null){  
                  // String columnType=getColumnProperty("type",key).toUpperCase();  
                  
                  if(characterStreamColumns.contains(col.getType())){
                     clob=(Clob)resultSet.getClob(columnName);  
                     // setLobObject(resultSet,key,columnName);
                     col.setObject(clob);
                     String data=col.getValue();
                     setCharacterStream(preparedStatement,data,index);
                     lobHash.put(columnName,clob);  
                  }  
                  else if(binaryStreamColumns.contains(col.getType())){
                     blob=(Blob)resultSet.getBlob(columnName);  
                     // setLobObject(resultSet,key,columnName);
                     col.setObject(blob);
                     byte[] blobData=col.getValue().getBytes();
                     setBinaryStream(preparedStatement,blobData,index);
                     lobHash.put(columnName,blob);  
                  }  
               }  
            }  
         }  
           
         resultSet.close();  
      }  
      catch(SQLException exception){  
         log(getTableName()+".setLobHash(): "+exception);  
      }  
   }// setLobHash() ENDS  
    *
    */
   
   /**  
    * <code>setColumnTypes</code>  
    * <p>  
    *  Sets the prepared statements ascii stream
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @return results <code>String</code> data read.  
    */  
   
   /**
    *
   //--------------------------------------------------------------------------- 
   public void setColumnTypes(){
   //--------------------------------------------------------------------------- 
      asciiStreamColumns=utilities.getStringTokenVector(
                           getProperty("asciiStreamTypes","long"),",");
      characterStreamColumns=utilities.getStringTokenVector(
                           getProperty("characterStreamTypes","clob"),",");
      binaryStreamColumns=utilities.getStringTokenVector(
                           getProperty("binaryStreamTypes","blob,image"),",");
   }//setColumnTypes() ENDS
    *
    */

    /**  
    * <code>setLobObject</code>  
    * <p>  
    * This method places a lob reference within the columnProperties
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param resultSet <code>ResultSet</code>the result set 
    * @param key <code>String</code>the key were looking up.
    * @param columnName <code>String</code>the name of the column we want.
    * @return none <code>none</code> none.  
    */  
   
   /**
    *
   //---------------------------------------------------------------------------  
   private void setLobObject(ResultSet resultSet, String key,
                             String columnName){  
   //---------------------------------------------------------------------------
        try{
            ColumnProperties columnProperties=(ColumnProperties)
                columnPropertiesHash.get(key);
            Object object=resultSet.getObject(columnName);
            columnProperties.setObject(object);
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
   }//setLobObject() ENDS
    *
    */
   
   /**  
    * <code>setString</code>  
    * <p>  
    *  Sets the prepared statements ascii stream
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @return results <code>String</code> data read.  
    */  
   /**
    *
   //--------------------------------------------------------------------------- 
   private void setString(PreparedStatement ps, String data, int index)
        throws SQLException{
   //---------------------------------------------------------------------------  
       ps.setString(index,data);  
    }//setString() ENDS
    *
    */

   /**  
    * <code>updateColumnPropertiesObject</code>  
    * <p>  
    * This method allows set the lob hashtable.  
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param  <code>none</code>  
    * @return <code>none</code>  
    */  
   
   /**
    *
   //---------------------------------------------------------------------------  
   private void updateColumnPropertiesObject(ResultSet resultSet,
            ColumnProperties columnProperties,String columnType){  
  //---------------------------------------------------------------------------  
        try{                             
            if(isColumnTypeValid(asciiStreamColumns,columnType)||
               isColumnTypeValid(binaryStreamColumns,columnType)||
               isColumnTypeValid(characterStreamColumns,columnType)){
                   
                if(columnProperties!=null){
                    Object object=resultSet.getObject(columnProperties.getName());
                    
                    if(object!=null)
                        columnProperties.setObject(object);
                }
            }
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
   }
    *
    */
   
   /** Getter for property startRowParameter.
    * @return Value of property startRowParameter.
    */
   public String getStartRowParameter() {
       return this.startRowParameter;
   }
   
   /** Setter for property startRowParameter.
    * @param startRowParameter New value of property startRowParameter.
    */
   public void setStartRowParameter(String startRowParameter) {
       this.startRowParameter = startRowParameter;
   }
   
   /** Getter for property tableAlias.
    * @return Value of property tableAlias.
    */
   public String getTableAlias() {
       if( this.tableAlias==null )
           return "";
       return this.tableAlias;
   }
   
   /** Setter for property tableAlias.
    * @param tableAlias New value of property tableAlias.
    */
   public void setTableAlias(String tableAlias) {
       this.tableAlias = tableAlias;
   }
   /*
   public boolean isTableAlias() {
       if( getTableAlias().equals("") ) {
           return false;
       }
       return true;
   }
    */
   
   /** <code>main</code>
    * main test routine
    */
   public static void main( String [] args ) {
       SQLTags tag = new SQLTags( "tag", new SQLTagsConnection("oracle2.properties") );
       tag.setTableName("EMP");
       tag.setSQLTagsColumns( new SQLTagsColumns() );
       tag.getSQLTagsColumns().add( new SQLTagsColumn("EMPNO","100","0","STRING",Types.VARCHAR,"4","","?","EMPNO",true));
       tag.getSQLTagsColumns().add( new SQLTagsColumn("ENAME","JONES","0","STRING",Types.VARCHAR,"10","","?","ENAME",true));
       
       System.out.println("SQLTags: tag="+tag);
       System.exit(0);
   }
}// SQLTags() ENDS  
