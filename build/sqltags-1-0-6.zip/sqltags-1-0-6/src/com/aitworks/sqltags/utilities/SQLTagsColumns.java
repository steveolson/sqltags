/* $Id: SQLTagsColumns.java,v 1.5 2003/10/01 15:59:23 solson Exp $
 * $Log: SQLTagsColumns.java,v $
 * Revision 1.5  2003/10/01 15:59:23  solson
 * added logging messages for debugging connection/dataSource problem
 *
 * Revision 1.4  2003/06/19 16:24:51  solson
 * Fixed DATE types on select (was using getDate() and not getTimestamp())
 * the getDate() method in JDBC truncates time portion.  getTimestamp() keeps all info
 * available, if necessary.
 *
 * Revision 1.3  2003/06/17 18:02:14  solson
 * fixed clear after delete; cleared all arrayIndexes for all rows.  Now clear() only clears
 * the current row, based on arrayIndex.
 *
 * Revision 1.2  2003/05/22 18:12:02  solson
 * updated logging
 *
 * Revision 1.1  2003/05/17 03:18:21  solson
 * no message
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 * Created on May 13, 2003, 9:41 PM
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.utilities;
import java.util.logging.Logger;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;
import java.text.*;
import java.sql.*;
import java.io.*;

/**
 * SQLTagsColumns is a collection of SQLTagsColumn.  Provides some functions
 * to manage the set of Columns for a table.
 * @author  solson
 */
public class SQLTagsColumns {
    private Logger log = Logger.getLogger("com.aitworks.sqltags.utilities.SQLTagsColumns");
    private Hashtable columnHash = new Hashtable();
    
    /** Creates a new instance of SQLTagsColumns */
    public SQLTagsColumns() {
    }
    
    /** <CODE>add</CODE>
     * adds a SQLTagsColumn to the collection
     * @param c SQLTagsColumn to be added to the Collection
     */    
    public void add(SQLTagsColumn c) {
        if( c == null ) {
            log.warning("SQLTagsColumns:add:null parameter");
            return;
        }
        columnHash.put( c.getName(), c);
    }
    
    /** <CODE>delete</CODE>
     * deletes a SQLTagsColumn from the Collection
     * @param c SQLTagsColumn to be deleted
     */    
    public void delete(SQLTagsColumn c) {
        if( c == null) {
            log.warning("SQLTagsColumns:delete:null parameter");
            return;
        }
        delete(c.getName());
    }
    
    /** <CODE>delete</CODE>
     * Delete a SQLTagsColumn from the collection
     * @param s name of SQLTagsColumn to be deleted
     */    
    public void delete(String s) {
        if( s==null) {
            log.warning("SQLTagsColumns:delete:null parameter");
            return;
        }
        columnHash.remove(s.toUpperCase());
    }
    
    /** <CODE>clearValues</CODE>
     * <P>clear values in collection (including all elements in array)
     * does NOT DELETE ENTRIES!
     * </P>
     */
    public void clearValues(String arrayIndex) {
        Enumeration enum = keys();
        while( enum.hasMoreElements() ){
            SQLTagsColumn col = get( (String) enum.nextElement() );
            col.clear(arrayIndex);
        }
    }
    
    /** <CODE>contains</CODE>
     * <p>boolean method to see if an element is contained in the Collection
     * </p>
     * @return boolean value: true is item is in list or flase if not
     * @param c SQLTagsColumn to check
     */    
    public boolean contains(SQLTagsColumn c) {
        if( c == null) {
            log.warning("SQLTagsColumns:contains:null parameter");
            return false;
        }
        return contains(c.getName());
    }
    
    /** <CODE>contains</CODE>
     * <p>boolean method to see if an element is contained in the Collection
     * </p>
     * @param s name of SQLTagsColumn to check
     * @return boolean value: true is item is in list or flase if not
     */    
    public boolean contains(String s) {
        if( s==null) {
            log.warning("SQLTagsColumns:contains:null parameter");
            return false;
        }
        return columnHash.containsKey(s.toUpperCase());
    }
    
    /** <CODE>size</CODE>
     * returns size of Collection
     * @return number of elements in collection
     */    
    public int size() {
        return columnHash.size();
    }
    
    /** <CODE>isEmpty</CODE>
     * boolean method to test if collection is empty
     * @return true if collection is empty; false if not empty
     */    
    public boolean isEmpty(){
        return columnHash.isEmpty();
    }
    
    /** <CODE>keys</CODE>
     * returns Enumeration of collection's key values as Strings
     * @return returns Enumeration of the Keys of the Collection as Strings
     */    
    public Enumeration keys() {
        return columnHash.keys();
    }
    
    /** <CODE>getSQLTagsColumn</CODE>
     * gets a specific SQLTagsColumn based on Column Name
     * @return SQLTagsColumn corresponding to name parameter
     * @param name name of column
     */    
    public SQLTagsColumn get(String name){
        if( name==null) {
            log.warning("SQLTagsColumns:get:null parameter");
            return null;
            // should really throw an Exception here ... 
        }
        return (SQLTagsColumn)columnHash.get(name.toUpperCase());
    }
    
    /** <CODE>isBaseTable</CODE>
     * gets a specific SQLTagsColumn baseTable property based on Column Name
     * @return boolean, true if is baseTable else false
     * @param name name of column
     */
    public boolean isBaseTable(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:isBaseTable:can't find column:"+name);
            return false;
        }
        return col.isBaseTable();
    }
    
    /** <CODE>getFormat</CODE>
     * gets a specific SQLTagsColumn Format based on Column Name
     * @return SQLTagsColumn.bind corresponding to name parameter
     * @param name name of column
     */
    public String getFormat(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getFormat:can't find column:"+name);
            return null;
        }
        return col.getFormat();
    }
    
    /** <CODE>setFormat</CODE>
     * <P>sets the number or date format for all values in the array
     * @param name - column name to set format for
     * @param format - the format to use: see java.text.SimpleDateFormat and
     *  java.text.DecimalFormat for details
     * @return void
     * @see java.text.SimpleDateFormat
     * @see java.text.DecimalFormat
     */
    public void setFormat(String name, String format){
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns::setFormat:can't find column:"+name);
            return;
        }
        col.setFormat(format);
    }
        
    /** <CODE>getBindFormat</CODE>
     * gets a specific SQLTagsColumn bindFormat based on Column Name
     * @return SQLTagsColumn.bind corresponding to name parameter
     * @param name name of column
     */
    public String getBindFormat(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getBindFormat:can't find column:"+name);
            return null;
        }
        return col.getBindFormat();
    }
    /** <CODE>setBindFormat</CODE>
     * <P>sets the BIND expression used for INSERT/UPDATE/DELETE statement</P>
     * @param name - column name to set format for
     * @param format - BIND expression: use "?" as placeholder for column name
     * @return void
     * @see java.sql.PreparedStatement
     */
    public void setBindFormat(String name, String format){
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns::setBindFormat:can't find column:"+name);
            return;
        }
        col.setBindFormat(format);
    }
    
    /** <CODE>getSelectFormat</CODE>
     * gets a specific SQLTagsColumn SelectFormat based on Column Name
     * @return SQLTagsColumn.Select corresponding to name parameter
     * @param name name of column
     */
    public String getSelectFormat(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getSelectFormat:can't find column:"+name);
            return null;
        }
        return col.getSelectFormat();
    }
    /** <CODE>setBindFormat</CODE>
     * <P>sets the SELECT expression used in SELECT-LIST itmes in SELECT statement</P>
     * @param name - column name to set format for
     * @param format - SELECT Expression
     * @return void
     */
    public void setSelectFormat(String name, String format){
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns::setSelectFormat:can't find column:"+name);
            return;
        }
        col.setSelectFormat(format);
    }
    
    /** <CODE>getObject</CODE>
     * gets a specific SQLTagsColumn Object property based on Column Name
     * @return SQLTagsColumn.ObjectValue corresponding to name parameter
     * @param name name of column
     */
    public Object getObject(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getObject:can't find column:"+name);
            return null;
        }
        return col.getValueObject();
    }
    
    /** <CODE>getObject</CODE>
     * gets a specific SQLTagsColumn Object property based on Column Name
     * @return SQLTagsColumn.ObjectValue corresponding to name parameter
     * @param name name of column
     * @param arrayIndex index into value array
     */
    public Object getObject(String name,String arrayIndex) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getObject:can't find column:"+name);
            return null;
        }
        return col.getValueObject(arrayIndex);
    }
    
    /** <CODE>getType</CODE>
     * gets a specific SQLTagsColumn type based on Column Name
     * @return SQLTagsColumn.type corresponding to name parameter
     * @param name name of column
     */
    public String getType(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getType:can't find column:"+name);
            return null;
        }
        return col.getType();
    }
    
    /** <CODE>getSize</CODE>
     * gets a specific SQLTagsColumn size property based on Column Name
     * @return SQLTagsColumn.size property corresponding to name parameter
     * @param name name of column
     */
    public String getSize(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getSize:can't find column:"+name);
            return null;
        }
        return col.getSize();
    }
    
    /** <CODE>getString</CODE>
     * gets a specific SQLTagsColumn value based on Column Name
     * @return SQLTagsColumn.value corresponding to name parameter
     * @param name name of column
     */
    /**
    public String getString(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getString:can't find column:"+name);
            return null;
        }
        return col.getValue();
    }
     *
     */
    
    /** <CODE>getString</CODE>
     * gets a specific SQLTagsColumn value based on Column Name
     * @return SQLTagsColumn.value corresponding to name parameter
     * @param name name of column
     * @param arrayIndex arrayIndex of the value array within SQLTagsColumn
     */
    public String getString(String name, String arrayIndex) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getString:can't find colunn:"+name);
            return null;
        }
        return col.getValue(arrayIndex);
    }
    
    /**<CODE>setString</CODE>
     * sets the value for a column based on name
     * @param name - column name to set
     * @param value - value to which set
     * @return none
     */
    /**
    public void setString(String name, String value) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:setString:can't find colunn:"+name);
            return;
        }
        col.setValue(value);
    }
     *
     */
    
    /**<CODE>setString</CODE>
     * sets the value for a column based on name
     * @param name - column name to set
     * @param value - value to which set
     * @param arrayIndex - index into value array
     * @return none
     */
    public void setString(String name, String value, String arrayIndex) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.fine("SQLTagsColumns:setString:can't find colunn:"+name+", didn't set value: "+value);
            return;
        }
        col.setValue(value,arrayIndex);
    }
    
    /** <CODE>getNumber</CODE>
     * gets a specific SQLTagsColumn value as a Number based on Column Name
     * @return SQLTagsColumn.value corresponding to name parameter
     * @param name name of column
     */
    /**
    public Number getNumber(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getNumber:can't find column:"+name);
            return null;
        }
        return col.getValueNumber();
    }
     *
     */
    
    /** <CODE>getNumber</CODE>
     * gets a specific SQLTagsColumn value as a Number based on Column Name
     * @return SQLTagsColumn.value corresponding to name parameter
     * @param name name of column
     * @param arrayIndex array index of value within SQLTagsColumn value array
     */
    public Number getNumber(String name, String arrayIndex) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getNumber:can't find column:"+name);
            return null;
        }
        return col.getValueNumber(arrayIndex);
    }
    /** <CODE>setNumber</CODE>
     * sets a specific SQLTagsColumn value as a Number based on Column Name
     * @return none
     * @param name name of column
     * @param value of number to be set
     */
    /**
    public void setNumber(String name, Number value) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:setNumber:can't find column:"+name);
            return;
        }
        col.setValue(value);
    }
     *
     */
    /** <CODE>setNumber</CODE>
     * sets a specific SQLTagsColumn value as a Number based on Column Name
     * @return none
     * @param name name of column
     * @param value of number to be set
     * @param arrayIndex array index of value within SQLTagsColumn value array
     */
    public void setNumber(String name, Number value, String arrayIndex) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:setNumber:can't find column:"+name);
            return;
        }
        col.setValue(value,arrayIndex);
    }
    
    /** <CODE>getDate</CODE>
     * gets a specific SQLTagsColumn value as a Date based on Column Name
     * @return SQLTagsColumn.value corresponding to name parameter
     * @param name name of column
     */
    /**
    public java.util.Date getDate(String name) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getDate:can't find column:"+name);
            return null;
        }
        return col.getValueDate();
    }
     *
     */
    
    /** <CODE>getDate</CODE>
     * gets a specific SQLTagsColumn value as a Date based on Column Name
     * @return SQLTagsColumn.value corresponding to name parameter
     * @param name name of column
     * @param arrayIndex array index of value within SQLTagsColumn value array
     */
    public java.util.Date getDate(String name, String arrayIndex) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getDate:can't find column: "+name);
            return null;
        }
        return col.getValueDate(arrayIndex);
    }
    /** <CODE>setDate</CODE>
     * sets a specific SQLTagsColumn value as a Date based on Column Name
     * @return none
     * @param name name of column
     */
    /**
    public void setDate(String name, java.util.Date value) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:setDate:can't find column: "+name);
            return ;
        }
        col.setValue(value);
    }
     *
     */
    /** <CODE>setDate</CODE>
     * sets a specific SQLTagsColumn value as a Date based on Column Name
     * @return none
     * @param name name of column
     * @param arrayIndex array index of value within SQLTagsColumn value array
     */
    public void setDate(String name, java.util.Date value, String arrayIndex) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:setDate:can't find column: "+name);
            return ;
        }
        col.setValue(value,arrayIndex);
    }
    
    
    /** <CODE>getDateField</CODE>
     * gets a specific SQLTagsColumn Date Field based on Column Name
     * @return String representation of date field
     * @param name name of column
     * @param field Date field based on java.util.text.SimpleDateFormat date format strings.
     */
    /**
    public String getDateField(String name, String field) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getDateField:can't find column:"+ name);
            return null;
        }
        return col.getValueDateField(field);
    }
     *
     */
    
    /** <CODE>getDateField</CODE>
     * gets a specific SQLTagsColumn Date Field based on Column Name
     * @return String representation of date field
     * @param name name of column
     * @param field name of date field to retrieve
     * @param arrayIndex array index of value within SQLTagsColumn value array
     */
    public String getDateField(String name, String field, String arrayIndex) {
        SQLTagsColumn col = get(name);
        if(col==null) {
            log.warning("SQLTagsColumns:getDateField:can't find Column:"+name);
            return null;
        }
        return col.getValueDateField(field,arrayIndex);
    }
    
    /** NOT IMPLEMENTED YET **/
    /**
    public void setDateField(String name, String field, String value) {
        log.severe("SQLTagsColumns::setDateField: NOT YET IMPLEMENTED!");
    }
     *
     */
    /** NOT IMPLEMENTED YET **/
    public void setDateField(String name, String field, String value, String arrayIndex) {
        log.severe("SQLTagsColumns::setDateField: NOT YET IMPLEMENTED!");
    }
    
    /** <CODE>set</CODE>
     * <P>set values based upon input resultSet</P>
     * @param resultSet from java.sql.resultSet
     */
    public void set(ResultSet rs, String arrayIndex) {
        log.finer("SQLTagsColumns::set(rs,"+arrayIndex+")");
        if(rs==null) {
            log.warning("set::parameter is null");
            return;
        }
        try {
            ResultSetMetaData md = null;
            log.finer("checking MetaData() ... ");
            md=rs.getMetaData();
            if(md==null) {
                log.warning("SQLTagsColumns:set(rs,arrayIndex):null resultSet.MetaData");
                return;
            }
            //
            // cannot clear from sqlFetch() !!!!!!!
            //
            // clearValues(); // perhaps shold do this inside the for loop on index==1
            
            // Gonna need some placeholders ...
            
            for(int i=1; i<=md.getColumnCount();i++) {
                String name = md.getColumnName(i).toUpperCase();
                log.finest("name="+name);
                
                String key = name.toUpperCase();
                SQLTagsColumn col = get(key);
                if( col == null) {
                    // select-list item is not already in SQLTagsColumns
                    // gotta create one
                    col = new SQLTagsColumn( key   // name
                                            ,""    // value-- placeholder will be changed
                                            ,arrayIndex // arrayIndex
                                            ,md.getColumnTypeName(i) // type
                                            ,md.getColumnType(i) // sqlType
                                            ,""+md.getColumnDisplaySize(i) // size
                                            ,""    // format
                                            ,"?"   // bindFormat
                                            ,key   // selectFormat
                                            ,false // baseTable
                                            );
                }
                // OK, now we've got a valid SQLTagsColumn ...
                int iType = md.getColumnType(i);
                log.finest("set::checking type# " + md.getColumnTypeName(i) );
                if(    iType== Types.BIGINT || iType==Types.TINYINT || iType==Types.SMALLINT
                    || iType==Types.DECIMAL || iType==Types.DOUBLE  || iType==Types.FLOAT
                    || iType==Types.INTEGER || iType==Types.NUMERIC || iType==Types.REAL) 
                {
                    log.finest("SQLTagsColumns::set:name="+name+":NUMBER:Type="+ md.getColumnTypeName(i)+"/"+iType+":scale="+md.getScale(i));
                    col.setType("NUMBER");
                    col.setValue((Number)rs.getBigDecimal(i),arrayIndex);
                    log.finest("SQLTagsColumns::done getting Number.");
                } else if(iType==Types.DATE) {
                    log.finest("SQLTagsColumns::set:name="+name+":DATE");
                    col.setType("DATE");
                    col.setValue( (java.util.Date)rs.getTimestamp(i),arrayIndex);
                    log.finest("SQLTagsColumns::set:value="+col.getValue());
                } else if(iType==Types.TIME) {
                    col.setType("TIME");
                    col.setValue((java.util.Date)rs.getTimestamp(i),arrayIndex);
                } else if(iType==Types.TIMESTAMP) {
                    col.setType("TIMESTAMP");
                    col.setValue((java.util.Date)rs.getTimestamp(i),arrayIndex);
                } else if(iType==Types.BLOB || iType==Types.LONGVARBINARY ) {
                    log.finest("set:: setting BLOB/LONGCARBINARY type ... ");
                    col.setType( md.getColumnTypeName(i).toUpperCase());
                    log.finest("using BinaryStream for: " + col.getType() );
                    try {
                        col.setValue( rs.getBinaryStream(i), arrayIndex);
                    } catch( IOException io) {
                        log.severe("SQLTagsColumns:get(rs,arrayIndex):getBinaryStream failed:"+io);
                    }
                    col.setObject(rs.getObject(i));
                } else if(iType==Types.CLOB || iType==Types.LONGVARCHAR) {
                    log.finest("set:: setting CLOB/LONGCARCHAR type ... ");
                    col.setType( md.getColumnTypeName(i).toUpperCase());
                    log.finest("using CharacterStream for: " + col.getType() );
                    try{
                        col.setValue( rs.getCharacterStream(i), arrayIndex);
                    } catch( IOException io) {
                        log.severe("SQLTagsColumns:get(rs,arrayIndex):getCharacterStream failed:"+io);
                    }
                    col.setObject(rs.getObject(i));
                } else {
                    log.finest("set:: setting STRING" );
                    col.setType("STRING");
                    col.setValue( rs.getString(i), arrayIndex);
                }
                add(col);
            }
        } catch( SQLException e) {
            log.severe("SQLTagsColumns:set(rs,arrayIndex):"+e);
            log.severe("Exception cause: " +e.getCause() );
            return;
        }
        log.finer("set:: done.");
        return;
    }
    /** <CODE>bind</CODE>
     * <P>binds values from BindVector into preparedStatement using SQLTagsColumns</P>
     * @param ps is a PerparedStatement from java.sql
     * @param bv is a Vector of names of bind variables (really should be a Vector of SQLTagsColumn)
     */
    /**
     * Still not ready for this ... one ... 
    public void bind(PreparedStatement ps, Vector bv, String arrayIndex) throws SQLException {
        bind(ps,bv,arrayIndex,"false");
    }
    public void bind(PreparedStatement ps, Vector bv, String arrayIndex, String bindStrings) throws SQLException {
        if(bv == null) {
            log.fine("bind: null BindVector, done.");
            return;
        }
        return;
    }
     *
     */
    
    public String toString(){
        return "SQLTagsColumns:toString():columns" + columnHash ;
    }
    
    /** <CODE>main</CODE>
     * main method for testing purposes
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SQLTagsColumns cols = new SQLTagsColumns();
        // SQLTagsColumn( name,  value,  arrayIndex,  type)
        cols.add( new SQLTagsColumn("col1","val1","0","STRING",Types.VARCHAR));
        cols.add( new SQLTagsColumn("col2","val2","0","STRING",Types.VARCHAR));
        Enumeration e = cols.keys();
        while( e.hasMoreElements() ){
            SQLTagsColumn col = cols.get((String)e.nextElement());
            System.out.println(col);
        }
        System.exit(0);
    }
}
