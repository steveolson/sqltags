/* $Id: SQLTagsGeneratorTable.java,v 1.44 2003/11/18 14:45:50 solson Exp $
 * $Log: SQLTagsGeneratorTable.java,v $
 * Revision 1.44  2003/11/18 14:45:50  solson
 * support running javac under path with spaces from web app
 * deals with databases that return table names in lower case
 *
 * Revision 1.43  2003/11/17 16:43:40  solson
 * fixed check for built-in classes
 *
 * Revision 1.42  2003/11/17 13:56:51  solson
 * added jarFilename as tablib-uri attribute so that generated taglibs do not need to
 * be registered in the web.xml deployment descriptor.  The default taglib uri is now
 * the jarFilename without the "/WEB-INF/lib" prefix.
 *
 * Revision 1.41  2003/10/20 16:49:10  solson
 * consolidated calls to load() and load(tab) into generate() ... for consistency
 *
 * Revision 1.40  2003/10/20 12:30:27  solson
 * cleanup
 * improved error handling and reporting
 * improved output messages
 * checking for empty packagename
 * append ".jar" to jarFilename if not present
 *
 * Revision 1.39  2003/10/20 02:31:00  solson
 * added servletRoot and servletJar properties to deal with web-based generation.
 * cleanup of code (just started!) ...
 * changed output scheme to use sendOutput to either printStream or Writer, so
 *   output can be sent to either System.out or JspWriter depending out interface.
 *
 * Revision 1.38  2003/10/17 19:21:14  solson
 * interim changes; working but in need of major overhaul
 *
 * Revision 1.37  2003/09/17 14:00:49  solson
 * Enhanced schemaName property to allow for the following syntax
 * SchemaNamePattern <dot> tableNamePattern <space> tableType <comma> tableType <comma> ...
 * For example: for only VIEWS in SCOTT schema
 *     SCOTT.% VIEW
 * for Tables & views starting with A in SCOTT Schema
 *     SCOTT.A% TABLE,VIEW
 * for all TABLES and VIEWS in the SCOTT schema: (as before)
 *     SCOTT
 * In order to restrict TableTypes the tablename pattern is required.
 *
 * Revision 1.36  2003/09/17 13:08:46  solson
 * fixed isTableNameValid() didn't have the not operator ... works now
 *
 * Revision 1.35  2003/09/17 12:50:42  solson
 * modified isTableValid (renamed to isTableNameValid, and re-wrote implementation)
 * not based on isJavaIdentifier() calls.
 *
 * Revision 1.34  2003/06/17 02:41:57  solson
 * made jspversion 1.2 the default version ...
 *
 * Revision 1.33  2003/05/17 03:22:34  solson
 * Major rewrite to support replacement of ColumnProperties with SQLTagsColumns;
 * which now supports native DATE, TIME, TIMESTAMP, and NUMBER conversions
 * in Java and not in the database queries.
 *
 * Revision 1.32  2002/09/10 19:24:58  jpoon
 * added jspversion to generator
 * need jspversion in properties file
 * "jspversion=1.1"
 * or
 * "jspversion=1.2"
 *
 * Revision 1.31  2002/07/05 18:22:33  lindahl
 * Made compatible with updated CreateTLD interface
 *
 * Revision 1.30  2002/05/23 15:49:42  solson
 * removed xml type defaulting feature
 *
 * Revision 1.29  2002/04/24 15:05:33  booker
 * Added a check to remove System Tables from
 * db generation.
 *
 * Revision 1.28  2002/04/23 16:41:48  booker
 * Fixed dr$
 *
 * Revision 1.27  2002/04/15 11:21:26  booker
 * Modified time and who turns the buildMenu back on after
 * the generation has been completed.
 *
 * Revision 1.26  2002/04/15 11:10:16  booker
 * Changed scope of textArea and buildMenu. Added
 * methods to reflect new behavior.
 *
 * Revision 1.25  2002/04/12 12:24:04  booker
 * Added Scrolling ability to the textarea.
 *
 * Revision 1.24  2002/04/10 17:39:10  booker
 * Added functionality to read in default values for
 * the column properties type fields.
 *
 * Revision 1.23  2002/03/15 14:23:47  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.generator;
// import com.aitworks.sqltags.utilities.BindReader;
import com.aitworks.sqltags.utilities.CreateJar;
import com.aitworks.sqltags.utilities.Utilities;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;
import java.io.InputStream;
//import javax.swing.JMenuItem;
//import javax.swing.JTextArea;

public class SQLTagsGeneratorTable{
   //*************************************************************************** 
   // Class Variables
   //***************************************************************************
   private String tableName = null;
   private boolean haveTables=false;
   private String startTime="";
   private StringBuffer tld=new StringBuffer();
   // private SQLTagsGeneratorTable classInstance;
   private Hashtable columnHash = new Hashtable();
   private Vector primaryKeyVector = new Vector();
   private Hashtable tableNameHash=new Hashtable();
   private Hashtable importedForeignKeyHash = new Hashtable();
   private Hashtable exportedForeignKeyHash = new Hashtable() ;
   private Properties properties = null;
   private static String DEFAULT_PROPERTIES_FILE = "SQLTagsGeneratorTable.properties";
   private String propertiesFile = DEFAULT_PROPERTIES_FILE;
   private String schemaName=null;
   private String urlString = null;
   private String userName = null;
   private String password = null;
   private String jspversion = "1.2";
   private Connection connection=null;
   private DatabaseMetaData metaData = null;
   private PrintStream outStream = System.out;
   private Writer outWriter = null;
   
//   private String selectBindDefaults;
   //*************************************************************************** 
   // Class Constructor 
   //***************************************************************************
   /**  
    * <code>Class Constructor</code>  
    * <p>  Instantiates the with default properties file
    * </p>  
    * @param none <code>none</code> none
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------  
   public SQLTagsGeneratorTable(){
       this( DEFAULT_PROPERTIES_FILE );
   }//Constructor() ENDS
   
   /**  
    * <code>Class Constructor</code>  
    * <p>  
    * Builds and displays the GUI
    * </p>  
    * @param none <code>none</code> none
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------  
   public SQLTagsGeneratorTable(String pFile) {
       setPropertiesFile(pFile);
       loadProperties();
       generate();
   }
   
   /**  
    * <code>Class Constructor</code>  
    * <p>  
    * Builds and displays the GUI
    * </p>  
    * @param none <code>none</code> none
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------  
   public SQLTagsGeneratorTable(Properties properties){
       this( properties, System.out);
   }//Constructor() ENDS
   
   //---------------------------------------------------------------------------  
   public SQLTagsGeneratorTable(Properties p, PrintStream s){
       this.properties=p;
       setOut(s);
       generate();
   }
   //---------------------------------------------------------------------------  
   public SQLTagsGeneratorTable(Properties p, Writer w){
       this.properties=p;
       setOut(w);
       generate();
   }
   
   /**  
    * <code>Class Constructor</code>  
    * <p>  
    * Builds and displays the GUI
    * </p>  
    * @param tableName <code>String</code> table to build.
    * @param propertiesFile <code>String</code> database connection properties.
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------  
   public SQLTagsGeneratorTable(String tableName, String propertiesFile){
       setPropertiesFile(propertiesFile);
       loadProperties();
       generate(tableName);
       
   }//Constructor ENDS
   public void generate(){
       generate("");
   }
   //---------------------------------------------------------------------------  
   public void generate(String tableName){
   //---------------------------------------------------------------------------  
       startTime=Calendar.getInstance().getTime().toString();
       sendOutput("Generator started.\n");
       if( ! setConnection() ) {
           return;
       }
       createDirectories();
       if(tableName !=null && tableName.length()>0){
           load(tableName);
       } else {
           createTableHash();
           load();
       }
       
       if(GeneratorGUI.getTextArea()!=null)
           GeneratorGUI.setBuildMenuEnabled(true);
   }
    
   //*************************************************************************** 
   //Finalizer Method
   //***************************************************************************
   /**  
    * This is the finalizer method for this class  
    * @author  Booker Northington II  
    * @version 1.0  
    * @param   none  
    * @return  none  
    * @since   JDK1.3  
    */  
   //---------------------------------------------------------------------------  
   protected void finalize() throws Throwable{  
   //---------------------------------------------------------------------------  
      super.finalize();  
   }// finalizer() ENDS  

   //*************************************************************************** 
   //Public Method
   //***************************************************************************
   public static void main(String args[] ){
      SQLTagsGeneratorTable generatorTable=null;
      
       if(args.length==0)
        generatorTable=new SQLTagsGeneratorTable();
       else{
           generatorTable = new SQLTagsGeneratorTable(args[0]);
           /*
            *
            Utilities utilities=new Utilities();
            InputStream inputStream=utilities.getInputStream(args[0]);
            
            if(inputStream!=null)
                generatorTable=new SQLTagsGeneratorTable(inputStream);
            *
            */
        }
           
   }// main() ENDS
   
   /**  
    * <code>createDirectories</code>  
    * <p>  
    * This methods create the package name work directories
    * </p>  
    * @param none <code>none</code> none
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------  
   private void createDirectories(){
   //---------------------------------------------------------------------------  
        String packagePath = getPropertyValue("tmpWorkDir","")
                          + File.separator
                          + getPropertyValue("packageName","").replace('.',File.separatorChar)
                          ;
        File packageFile = new File ( packagePath );
        packageFile.mkdirs();
        
        // Just in case both tmpWorkDir and packageName are empty!!!
        if( !packagePath.equals(File.separator) ) {
            // Cleanup old files from previous run is important when tables are dropped!
            // Maybe a good idea to filter for *.class and *.java ... 
            // may also be a good idea to have a flag in UI that controls this ... 
            File[] fileList = packageFile.listFiles();
            for( int i = 0; i< fileList.length; i++) {
                // System.out.println("Deleting file: " + fileList[i].getName() );
                fileList[i].delete();
            }
        }
        properties.setProperty("outputDirectory",packagePath);
   }//createDirectories() END

   public String toString() {
     return "Table: "+ getTableName()
             + " \n\tColumns: " + columnHash
             + " \n\tPK: "+ primaryKeyVector
             + " \n\tExported Keys: " + exportedForeignKeyHash
             + " \n\tImported Keys: " + importedForeignKeyHash
             ;
   }

   //*************************************************************************** 
   //Friendly Methods
   //***************************************************************************
   //---------------------------------------------------------------------------  
   String getPropertyValue(String name){
   //---------------------------------------------------------------------------  
       if(properties!=null)
           return properties.getProperty(name,"");
       return "";
    }
   //---------------------------------------------------------------------------  
   String getPropertyValue(String name, String defaultValue){
   //---------------------------------------------------------------------------  
       if(properties!=null)
           return properties.getProperty(name,defaultValue);
       return defaultValue;
    }
   
   //---------------------------------------------------------------------------  
   Enumeration getColumns(){
   //---------------------------------------------------------------------------  
      return columnHash.keys();
   }

   //---------------------------------------------------------------------------  
   SQLTagsGeneratorColumn getColumn(String columnName) {
   //---------------------------------------------------------------------------  
      return (SQLTagsGeneratorColumn) columnHash.get(columnName);
   }

   //---------------------------------------------------------------------------  
   Enumeration getPrimaryKeys() {
   //---------------------------------------------------------------------------  
      return primaryKeyVector.elements();
   }

   //---------------------------------------------------------------------------  
   Enumeration getImportedForeignKeys() {
   //---------------------------------------------------------------------------  
      return importedForeignKeyHash.keys();
   }

   //---------------------------------------------------------------------------  
   SQLTagsGeneratorForeignKey getImportedForeignKey(String foreignKey) {
   //---------------------------------------------------------------------------  
      return (SQLTagsGeneratorForeignKey)importedForeignKeyHash.get(foreignKey);
   }

   //---------------------------------------------------------------------------  
   Enumeration getExportedForeignKeys() {
   //---------------------------------------------------------------------------  
      return exportedForeignKeyHash.keys();
   }

   //---------------------------------------------------------------------------  
   SQLTagsGeneratorForeignKey getExportedForeignKey(String foreignKey) {
   //---------------------------------------------------------------------------  
      return (SQLTagsGeneratorForeignKey)exportedForeignKeyHash.get(foreignKey);
   }

   //---------------------------------------------------------------------------  
   void setPropertiesFile(String propertiesFile){
   //---------------------------------------------------------------------------  
      this.propertiesFile=propertiesFile;
   }

   //---------------------------------------------------------------------------  
   String getPropertiesFile(){
   //---------------------------------------------------------------------------  
      return propertiesFile;
   }
   
   //---------------------------------------------------------------------------  
   Properties getPropertiesObject(){
   //---------------------------------------------------------------------------  
      return properties;
   }

   //---------------------------------------------------------------------------  
   String getUrlString() {
   //---------------------------------------------------------------------------  
      return urlString;
   }    

   //---------------------------------------------------------------------------  
   void setUrlString(String urlString) {
   //---------------------------------------------------------------------------  
      this.urlString=urlString;
   }

   //---------------------------------------------------------------------------  
   String getUserName() {
   //---------------------------------------------------------------------------  
      return this.userName;
   }

   //---------------------------------------------------------------------------  
   void setUserName(String userName) {
   //---------------------------------------------------------------------------  
      this.userName = userName;
   }

   //---------------------------------------------------------------------------  
   String getPassword() {
   //---------------------------------------------------------------------------  
      return this.password;
   }

   //---------------------------------------------------------------------------  
   void setPassword(String password) {
   //---------------------------------------------------------------------------  
      this.password = password;
   }

   //---------------------------------------------------------------------------  
   void setConnection(Connection connection){
   //---------------------------------------------------------------------------  
      this.connection=connection;
   }

   //---------------------------------------------------------------------------  
   public boolean setConnection() {
   //---------------------------------------------------------------------------  
     if(connection != null) {
         return true;
     }

     setJspversion(getPropertyValue("jspversion"));
     setUrlString(getPropertyValue("urlString"));
     setUserName(getPropertyValue("userName"));
     setPassword(getPropertyValue("password"));
     try{
        Class.forName(getPropertyValue("databaseDriver"));
         connection=DriverManager.getConnection(getUrlString(),getUserName(),getPassword());
         metaData = connection.getMetaData();
      } 
     catch(ClassNotFoundException e){
         sendOutput("Exception: ClassNotFound: " +e);
         return false;
     }
     catch( SQLException e) {
         sendOutput("SQL Exception: " + e);
         return false;
     }
     catch (Exception e) {
         sendOutput("Exception: " +e);
         return false;
     }
     this.connection = connection;
     return true;
   }

   //---------------------------------------------------------------------------  
   String getTableName() {
   //---------------------------------------------------------------------------  
       if(tableNameHash==null)
           return tableName.toUpperCase();
       return (String)tableNameHash.get(tableName);
   }
   
   String getTableName(String t){
       return t;
   }

   //---------------------------------------------------------------------------  
   void setTableName(String tableName) {
   //---------------------------------------------------------------------------  
      this.tableName = tableName;
   }

   //---------------------------------------------------------------------------  
   Hashtable getExportedForeignKeyHash(){
   //---------------------------------------------------------------------------  
   return exportedForeignKeyHash;
   }//getExportedForeignKeyHash() ENDS

   //---------------------------------------------------------------------------  
   Hashtable getImportedForeignKeyHash(){
   //---------------------------------------------------------------------------  
   return importedForeignKeyHash;
   }//getImportedForeignKeyHash() ENDS

   //---------------------------------------------------------------------------  
   Vector getPrimaryKeyVector(){
   //---------------------------------------------------------------------------  
   return primaryKeyVector;
   }//getPrimaryKeyVector() ENDS

   Hashtable getColumnHash(){
     return columnHash;
   }

   //---------------------------------------------------------------------------  
   void resetBuffers(){
   //---------------------------------------------------------------------------  
      primaryKeyVector.setSize(0);
      importedForeignKeyHash=new Hashtable();
      exportedForeignKeyHash=new Hashtable();
      columnHash=new Hashtable();
   }

   //*************************************************************************** 
   //Private Methods
   //***************************************************************************
   //---------------------------------------------------------------------------  
   private void createTableHash(){
   //---------------------------------------------------------------------------  
      try{
         haveTables=false;
         String tableWildCard = "%";
         String [] tableTypes = {"TABLE", "VIEW"};
         schemaName=properties.getProperty("metadataSchema");
         
         if(schemaName != null) {
             // OK, here goes: Enhancement to schemaName meaning:
             // SCHEMA <dot> TABLE PATTERN <sp> TABLE TYPE <comma> TABLE TYPE <comma> TABLE TYPE ...
             int dotIndex = schemaName.indexOf(".");
             if( dotIndex>0 ) {
                 String buf = schemaName;
                 schemaName = schemaName.substring(0,dotIndex);
                 
                 int spaceIndex = buf.indexOf(" ");
                 if( spaceIndex>dotIndex) {
                     tableWildCard = buf.substring(dotIndex+1,spaceIndex);
                     // Ok, we may have table types .. 
                     tableTypes = buf.substring(spaceIndex+1).split("[, ]");
                 }
                 else {
                     // Ok, no types, just a table wildcard
                     tableWildCard = buf.substring(dotIndex+1);
                 }
             }
         }
         
         if( schemaName!=null && schemaName.equalsIgnoreCase("null"))
             schemaName=null;
         
         DatabaseMetaData dbMetaData= connection.getMetaData(); 
         ResultSet resultSet=dbMetaData.getTables(null,schemaName,tableWildCard,tableTypes);
         tableNameHash.clear();

          while(resultSet.next()){
            haveTables=true;
            String tableName=resultSet.getString(3);

            if(isTableNameValid(tableName))
               tableNameHash.put(tableName,tableName.toUpperCase());
         }       
      }
      catch(SQLException ignore){
      }
   }//createTableHash() ENDS

   private boolean isTableNameValid(String table){
       if(table == null || table.length()==0) {
           return false;
       }
       
       Character c = new Character( table.charAt(0));
       if( !Character.isJavaIdentifierStart(table.charAt(0)) ){
           return false;
       }
       for( int i=0; i<table.length(); i++) {
           if( !Character.isJavaIdentifierPart(table.charAt(i)) ){
               return false;
           }
       }
       if( table.toUpperCase().startsWith("DR$")) {
           // Ok, hard coded-- for OracleText Indexes :(
           return false;
       }
       return true;
       /*
       boolean returnValue=true;
       if(table.indexOf(IGNORE1)>=0||
          table.indexOf(IGNORE2)>=0||
          table.indexOf(IGNORE3)>=0||
          table.indexOf(IGNORE4)>=0||
          table.indexOf(IGNORE5)>=0||
          table.indexOf(IGNORE6)>=0||
          table.indexOf(IGNORE7)>=0||
          table.indexOf(IGNORE8)>=0||
          table.indexOf(IGNORE9)>=0||
          table.indexOf(IGNORE10)>=0||
          table.indexOf(IGNORE11)>=0
         )
          returnValue=false;
       return returnValue;
        *
        */
   }//isTableNameValid() ENDS
   
   //*************************************************************************** 
   // Private Methods
   //***************************************************************************
   private void load(){
       primaryKeyVector.setSize(0);
       importedForeignKeyHash=new Hashtable();
       exportedForeignKeyHash=new Hashtable();
       columnHash=new Hashtable();
       Enumeration enum=tableNameHash.keys();
       String packageName=getPropertyValue("packageName");
       if( packageName.length()==0) {
           sendOutput("Error: Empty package name, quitting.");
           return;
       }
       String includeBuiltinTags = getPropertyValue("includeClasses","true");
       // making sure jarFilename ends with ".jar" 
       String jarFilename = getPropertyValue("jarFilename");
       if(jarFilename!=null&&jarFilename.trim().length()>0){
           if( ! jarFilename.endsWith(".jar") && ! jarFilename.endsWith(".JAR")) {
               jarFilename = jarFilename + ".jar";
               properties.setProperty("jarFilename", jarFilename);
           }
       }
       String tagliburi = getPropertyValue("jarFilename","http://sqltags.org/tags");
       CreateTLD createTLD=new CreateTLD("sqltags",packageName,jspversion,includeBuiltinTags.equalsIgnoreCase("true"),jarFilename);
       /*
       CreateTLD createTLD=null;
       if( includeBuiltinTags.equalsIgnoreCase("false")){
           createTLD=new CreateTLD("taglib",packageName, jspversion, false);
       } else {
           createTLD=new CreateTLD("taglib",packageName, jspversion, true);
       }
        */
       
       String outputTagName=schemaName;
       
       if(outputTagName==null)
           outputTagName=userName;
       
       try{
           //sendMessageToGUI("<"+outputTagName+">\n");
           //sendMessageToGUI("     <tables>\n");
           

           for(;enum.hasMoreElements();){
            String tableName=(String)enum.nextElement();
            setTableName(tableName);
            ResultSet rsColumns=metaData.getColumns(null,schemaName,getTableName(tableName),"%");

            while(rsColumns.next()) {
               SQLTagsGeneratorColumn col = new SQLTagsGeneratorColumn(
                  rsColumns.getString("COLUMN_NAME").toUpperCase()
                  ,rsColumns.getString("TYPE_NAME")
                  ,rsColumns.getInt("ORDINAL_POSITION")
                  ,rsColumns.getInt("COLUMN_SIZE")
                  ,rsColumns.getInt("COLUMN_SIZE")
                  ,rsColumns.getInt("DECIMAL_DIGITS")
                  ,rsColumns.getInt("DATA_TYPE")
               );
               columnHash.put
                (rsColumns.getString("COLUMN_NAME").toUpperCase(), col);
            }

            rsColumns.close();

            // Primary KEYS
            ResultSet pkColumns = metaData.getPrimaryKeys(null,schemaName,getTableName(tableName));
            while(pkColumns.next()) {
               primaryKeyVector.addElement(pkColumns.getString("COLUMN_NAME").toUpperCase());
            }
            pkColumns.close();

            // Imported KEYS
            ResultSet rsIK = metaData.getImportedKeys(null,schemaName,getTableName(tableName));

            while(rsIK.next()){
               SQLTagsGeneratorForeignKey ifk=(SQLTagsGeneratorForeignKey) 
                  importedForeignKeyHash.get
                    (rsIK.getString("FK_NAME").toUpperCase());

               if( ifk== null) {
                  ifk = new SQLTagsGeneratorForeignKey(
                          rsIK.getString("FK_NAME").toUpperCase(),
                          rsIK.getString("FKTABLE_NAME"),
                          rsIK.getString("PKTABLE_NAME")
                      );
                  importedForeignKeyHash.put( rsIK.getString("FK_NAME").toUpperCase(), ifk);
               }

               ifk.addJoinPair(rsIK.getString("FKCOLUMN_NAME").toUpperCase(),
                  rsIK.getString("PKCOLUMN_NAME").toUpperCase());
            }
            rsIK.close();

            // Exported KEYS
            ResultSet rsEK = metaData.getExportedKeys(null,schemaName,getTableName(tableName));

            while(rsEK.next()){
               SQLTagsGeneratorForeignKey efk = (SQLTagsGeneratorForeignKey) 
                  exportedForeignKeyHash.get(rsEK.getString("FK_NAME").toUpperCase());

               if( efk== null) {
                  efk = new SQLTagsGeneratorForeignKey(
                          rsEK.getString("FK_NAME").toUpperCase()
                         ,rsEK.getString("FKTABLE_NAME")
                         ,rsEK.getString("PKTABLE_NAME")
                     );

                  exportedForeignKeyHash.put(rsEK.getString("FK_NAME").toUpperCase(), efk);
               }
                  efk.addJoinPair(rsEK.getString("FKCOLUMN_NAME").toUpperCase(),
                     rsEK.getString("PKCOLUMN_NAME").toUpperCase());
            }
            rsEK.close();
            createFKTag(tableName,createTLD);
            new ClassBuilder(this);
         }
            if(haveTables){
                StringBuffer classPathBuf = new StringBuffer("CLASSPATH=" + System.getProperty("java.class.path"));
                if( !getPropertyValue("servletRoot").equals("") ) {
                    File webInfLib = new File( getPropertyValue("servletRoot")+ java.io.File.separator + "WEB-INF" + java.io.File.separator + "lib" );
                    File [] jarFiles = webInfLib.listFiles();
                    if( jarFiles != null ) {
                        for( int i=0; i<jarFiles.length; i++) {
                            String jarFile = jarFiles[i].toString();
                            if( jarFile.endsWith(".jar") ) {
                                classPathBuf.append(java.io.File.pathSeparator);
                                classPathBuf.append(jarFile);
                            }
                        }
                    }
                }
                if( !getPropertyValue("servletJar").equals("") ) {
                    classPathBuf.append(java.io.File.pathSeparator);
                    classPathBuf.append( getPropertyValue("servletJar") );
                }
                // sendMessageToGUI("     </tables>\n\n");
                String outputDirectory=getPropertyValue("outputDirectory");
                String [] classPath = new String[] {
                    classPathBuf.toString()
                };
                // System.out.println("javac " + outputDirectory + " " + "*.java " + classPath[0] );
                //sendMessageToGUI("compile\n"); 
                sendOutput("Compiling ... ");
                // boolean errorsFound=forkProcess("javac "+outputDirectory+ java.io.File.separator+"*.java",classPath);
                boolean errorsFound=forkProcess("javac "+getPropertyValue("packageName","").replace('.',File.separatorChar)+ File.separator+"*.java",classPath, getPropertyValue("tmpWorkDir"));
                sendOutput("done.\n");

                if(!errorsFound){
                    createTLD.cleanUp();  
                    String taglibName=getPropertyValue("tmpWorkDir")+
                        java.io.File.separator+GeneratorProperties.TagLibName;

                    writeFile(taglibName,createTLD.getTagLib());     
                    // sendMessageToGUI(""+taglibName+" created"); 
     
                    // String jarFilename=getPropertyValue("jarFilename");
                    
                    if(jarFilename!=null&&jarFilename.trim().length()>0){
                        /** moved to beginning of method ... 
                        if( ! jarFilename.endsWith(".jar") && ! jarFilename.endsWith(".JAR")) {
                            jarFilename = jarFilename + ".jar";
                            properties.setProperty("jarFilename", jarFilename);
                        }
                         */
                        // sendMessageToGUI("     <jar>\n"); 
                        sendOutput("Building " + jarFilename + " ... ");
                        CreateJar createJar=new CreateJar(properties);
                        sendOutput("done.\n");
                        // sendMessageToGUI(properties.getProperty("jarFilename")+" created\n"); 
                        // sendMessageToGUI("     </jar>\n\n"); 
                    } else {
                        sendOutput("Warning: missing or empty JAR filename.\n");
                    }
                }
            }
            else{
                // sendMessageToGUI("          No tables found in "+schemaName+". ");
                // sendMessageToGUI("Hint, the database metadata schema name could ");
                // sendMessageToGUI("be mispelled or should\n     ");
                // sendMessageToGUI("     be in uppercase.\n");
                // sendMessageToGUI("     </tables>\n\n");
            }
      } 
      catch( SQLException e) {
        System.out.println("SQLError: "+e);
      }
       String endTime=Calendar.getInstance().getTime().toString();
       // sendMessageToGUI("     <runtime>\n");
       // sendMessageToGUI("          Runtime: "+startTime+" - "+endTime +"\n");
       // sendMessageToGUI("\n     </runtime>\n");
       // sendMessageToGUI("</"+outputTagName+">\n");
       sendOutput("Generate complete.\n");
   }


   private void createFKTag(String tableName,CreateTLD createTLD){
       Enumeration enum=columnHash.keys();
       Vector optionalAttributes = new Vector();

       for(;enum.hasMoreElements();){
           String name=(String)enum.nextElement();
           optionalAttributes.add(name);
           optionalAttributes.add(name+"_SELECT");
           optionalAttributes.add(name+"_WHERE");
           optionalAttributes.add(name+"_BIND");
           optionalAttributes.add(name+"_FORMAT");
       }

       createTLD.initializeTLD(getTableName(),getPropertyValue("packageName"),optionalAttributes);  
    }

   private void load(String tableName){
      tableNameHash.clear();
      tableNameHash.put(tableName,tableName.toUpperCase());
      loadProperties();
      load();
   }//load() ENDS

   private void loadProperties(){
       InputStream is=SQLTagsGeneratorTable.class.getResourceAsStream(getPropertiesFile());
       loadPropertiesStream(is);
   }
   
   private void loadPropertiesStream(InputStream is){
      try{
         properties = new Properties();
         if(is!=null && properties!=null)
            properties.load(is);
         else {
             sendOutput("Failed to load properties from: " + getPropertiesFile());
         }
      }        
      catch( IOException e) {
          sendOutput("Error: "+ e);
      }
   }

   /**
    * method: writeFile
    * usage: this method writes the generated java file to
    * disk.
    * @param fileName the name of the file were writing.
    * @param outputFile the actual data were writing. */   
   //---------------------------------------------------------------------------  
   void writeFile(String fileName, StringBuffer outputFile){
   //---------------------------------------------------------------------------  
      try{  
         java.io.FileWriter writer=new java.io.FileWriter(fileName);   
         writer.write((outputFile.toString()).toCharArray());  
         writer.close();  
      }  
      catch(IOException exception){  
         sendOutput("SQLTagsGeneratorTable.writeFile: "+exception);  
      }  
   }  //writeFile() ENDS
   
   //---------------------------------------------------------------------------  
   private synchronized boolean forkProcess(String cmd, String[] env, String workingDir){  
   //---------------------------------------------------------------------------  
      boolean errorsFound=false;  
  
      try{  
          File cwd = new File(workingDir);
        Process proc=Runtime.getRuntime().exec(cmd,env,cwd);
        InputStream errorStream=proc.getErrorStream();
        InputStreamReader errorStreamReader=new InputStreamReader(errorStream);
        BufferedReader errorOutput=new BufferedReader(errorStreamReader);
        InputStream inputStream=proc.getInputStream();
        InputStreamReader inputStreamReader=new InputStreamReader(inputStream);
        BufferedReader processOutput=new BufferedReader(inputStreamReader);        
        String line=null;
        StringBuffer errorBuffer=new StringBuffer();
        StringBuffer processOutputBuffer=new StringBuffer();
        
        while ((line=errorOutput.readLine())!=null)
            errorBuffer.append(line);
        
        while ((line=processOutput.readLine())!=null)
            processOutputBuffer.append(line);

        if(errorBuffer.length()>0){
            errorsFound=true;
            StringBuffer infoBuffer=new StringBuffer();
            int size=errorBuffer.length();
            sendOutput("errors: \n");
            sendOutput(cmd+"\n");
            sendOutput(errorBuffer.toString()+"\n");
            }
        
        /*
        if(processOutputBuffer.length()>0){
            sendMessageToGUI("output:\n");
            sendMessageToGUI(""+errorBuffer.toString()+"\n");
        }
         */

        proc.waitFor();
       }  
      catch(InterruptedException exception){ 
          exception.printStackTrace();
          sendOutput("Interrupted Exception: " + exception);
      }      
      catch(SecurityException exception){  
           exception.printStackTrace();
           sendOutput("Security Exception: " + exception);
      }  
      catch(IOException exception){  
          exception.printStackTrace();
          sendOutput("IO Exception: " + exception);
      }  
  
      return errorsFound;  
   }//forkProcess() ENDS
   
   void sendMessageToGUI(String message){
      if(GeneratorGUI.getTextArea()!=null)
           GeneratorGUI.setTextArea(message);
      else sendOutput(message);
   }
   
   public void setOut( Writer out ) {
       outWriter = out;
       outStream = null;
   }
   public void setOut( PrintStream out) {
       outStream = out;
       outWriter = null;
   }
   public void sendOutput( String output ) {
       if( outStream!=null)
           outStream.print(output);
       if( outWriter!=null) {
           try {
               outWriter.write(output);
               outWriter.write("<br>");
           } catch (IOException i) {
               System.out.println(output);
           }
       }
       if(GeneratorGUI.getTextArea()!=null){
           GeneratorGUI.setTextArea(output);
       }
   }
   
   /** Getter for property jspversion.
    * @return Value of property jspversion.
    */
   public String getJspversion() {
       return this.jspversion;
   }
   
   /** Setter for property jspversion.
    * @param jspversion New value of property jspversion.
    */
   public void setJspversion(String jspversion) {
       this.jspversion = jspversion;
   }

}//SQLTagsGeneratorTable() ENDS