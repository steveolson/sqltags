/* $Id: SQLTagsGeneratorColumn.java,v 1.5 2003/05/17 03:22:34 solson Exp $
 * $Log: SQLTagsGeneratorColumn.java,v $
 * Revision 1.5  2003/05/17 03:22:34  solson
 * Major rewrite to support replacement of ColumnProperties with SQLTagsColumns;
 * which now supports native DATE, TIME, TIMESTAMP, and NUMBER conversions
 * in Java and not in the database queries.
 *
 * Revision 1.4  2002/03/15 14:23:45  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.generator;

public class SQLTagsGeneratorColumn {
   //***************************************************************************  
   // Class Constructors  
   //***************************************************************************  
   //---------------------------------------------------------------------------
   public SQLTagsGeneratorColumn() {
   //---------------------------------------------------------------------------
   }

   //---------------------------------------------------------------------------
   public SQLTagsGeneratorColumn(String columnName, String dataType, int keySeq, int size) 
   {
       this(columnName, dataType,keySeq,size,0,0,0);
   }
   
   public SQLTagsGeneratorColumn(String columnName,String dataType, int keySeq, int size, int precision, int scale, int sqlType) 
   {
      setColumnName(columnName);
      setDataType(dataType);
      setSize(size);
      setKeySeq(keySeq);
      setPrecision(precision);
      setScale(scale);
      setSqlType(sqlType);
   }
       

   //***************************************************************************  
   //Public Methods
   //***************************************************************************  
   //---------------------------------------------------------------------------
   public String toString() {
   //---------------------------------------------------------------------------
      return   "["+getColumnName() +", type="+getDataType()+", seq="+getKeySeq()
         +", size="+getSize() +"]";
   } 

   //***************************************************************************  
   // Friendly Methods
   //***************************************************************************  
   //---------------------------------------------------------------------------
   String getColumnName() {
   //---------------------------------------------------------------------------
      return this.columnName;
   }    

   //---------------------------------------------------------------------------
   void setColumnName(String columnName) {
   //---------------------------------------------------------------------------
      this.columnName = columnName;
   }

   //---------------------------------------------------------------------------
   String getDataType() {
   //---------------------------------------------------------------------------
      return this.dataType;
   }

   //---------------------------------------------------------------------------
   void setDataType(String dataType) {
   //---------------------------------------------------------------------------
      this.dataType = dataType;
   }

   //---------------------------------------------------------------------------
   int getKeySeq() {
   //---------------------------------------------------------------------------
      return this.keySeq;
   }

   //---------------------------------------------------------------------------
   void setKeySeq(int keySeq) {
   //---------------------------------------------------------------------------
      this.keySeq = keySeq;
   }

   //---------------------------------------------------------------------------
   int getSize() {
   //---------------------------------------------------------------------------
      return this.size;
   }

   //---------------------------------------------------------------------------
   void setSize(int size) {
   //---------------------------------------------------------------------------
      this.size = size;
   }

   /** Getter for property scale.
    * @return Value of property scale.
    *
    */
   public int getScale() {
       return this.scale;
   }
   
   /** Setter for property scale.
    * @param scale New value of property scale.
    *
    */
   public void setScale(int scale) {
       this.scale = scale;
   }
   
   /** Getter for property precision.
    * @return Value of property precision.
    *
    */
   public int getPrecision() {
       return this.precision;
   }
   
   /** Setter for property precision.
    * @param precision New value of property precision.
    *
    */
   public void setPrecision(int precision) {
       this.precision = precision;
   }
   
   /** Getter for property sqlType.
    * @return Value of property sqlType.
    *
    */
   public int getSqlType() {
       return this.sqlType;
   }
   
   /** Setter for property sqlType.
    * @param sqlType New value of property sqlType.
    *
    */
   public void setSqlType(int sqlType) {
       this.sqlType = sqlType;
   }
   
   //***************************************************************************  
   // Class Constructors  
   //***************************************************************************  
   private String columnName = null;
   private String dataType = null;
   private int keySeq;
   private int size;
   
   /** Holds value of property scale. */
   private int scale;
   
   /** Holds value of property precision. */
   private int precision;
   
   /** Holds value of property sqlType. */
   private int sqlType;
   
}//SQLTagsGeneratorColumn() ENDS