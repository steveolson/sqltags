/* $Id: ClassHelperMethods.java,v 1.12 2003/11/13 03:40:51 solson Exp $
 * $Log: ClassHelperMethods.java,v $
 * Revision 1.12  2003/11/13 03:40:51  solson
 * changed initializeHashTables from private to protected
 *
 * Revision 1.11  2003/11/13 01:30:13  solson
 * modifed initializeHashTables .. made public to match default method in sqltags.
 *
 * Revision 1.10  2003/05/17 03:22:33  solson
 * Major rewrite to support replacement of ColumnProperties with SQLTagsColumns;
 * which now supports native DATE, TIME, TIMESTAMP, and NUMBER conversions
 * in Java and not in the database queries.
 *
 * Revision 1.9  2003/01/20 22:10:01  solson
 * added methods to support setBeanProperties() within doStart from generated base
 * table classes.
 *
 * Revision 1.8  2002/05/23 15:49:42  solson
 * removed xml type defaulting feature
 *
 * Revision 1.7  2002/04/12 12:24:05  booker
 * Added Scrolling ability to the textarea.
 *
 * Revision 1.6  2002/04/10 17:39:10  booker
 * Added functionality to read in default values for
 * the column properties type fields.
 *
 * Revision 1.5  2002/04/03 14:49:59  booker
 * Worked on adding Object to ColumnProperties.
 *
 * Revision 1.4  2002/03/15 14:23:45  solson
 * added License, ID, and Log
 *
 * ====================================================================
 *
 * Applied Information Technologies, Inc.
 * Steve A. Olson
 *
 * Copyright (c) 2002 Applied Information Technologies, Inc.  
 * Copyright (c) 2002 Steve A. Olson
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by 
 *    Applied Information Technologies, Inc. (http://www.ait-inc.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Applied Information Technologies, Inc.", "AIT", "AITWorks", 
 *    "SQLTags", and "<SQLTags:>" must not be used to endorse or promote 
 *    products derived from this software without prior written permission. 
 *    For written permission, please contact support@ait-inc.com.
 *
 * 5. Products derived from this software may not be called "SQLTags" or
 *    "<SQLTags:>" nor may "SQLTags" or "<SQLTags:>" appear in their 
 *    names without prior written permission of the Applied Information 
 *    Technologies, Inc..
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL APPLIED INFORMATION TECHNOLOGIES, 
 * INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of Applied Information Technologies, Inc.  For more
 * information on Applied Information Technologies, Inc., please see
 * <http://www.ait-inc.com/>.
 *
 */
package com.aitworks.sqltags.generator;
// import com.aitworks.sqltags.utilities.BindReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.logging.Logger;
/**
 * <code>ClassHelperMethods</code>  
 * <p>  
 * This class is responsible for creating the base table class helper methods.
 * </p>  
 * @param  <code>none</code>  
 * @return <code>none</code>
 */
public class ClassHelperMethods{
    //***************************************************************************
    // Class Variables
    //***************************************************************************
    private static Logger log = Logger.getLogger("com.aitworks.sqltags.generator.ClassHelperMethods");
    private StringBuffer buffer;
    private HeaderDefinition header;
    private String spacer="   //---------------------------------------------------------------------------\n";
    private SQLTagsGeneratorTable sqlTagsGeneratorTable;
    private String tableName;
    
   //***************************************************************************  
   // Class Constructors  
   //***************************************************************************  
   /**  
    * <code>ClassHelperMethods</code>  
    * <p>  
    * Class constructor. Responsible for controlling creation of accessors.
    * </p>  
    * @param sqlTagsGeneratorTable<code>SQLTagsGeneratorTable</code>table data.
    */  
   //---------------------------------------------------------------------------
   public ClassHelperMethods(SQLTagsGeneratorTable sqlTagsGeneratorTable){
      this.sqlTagsGeneratorTable=sqlTagsGeneratorTable;
      this.tableName=sqlTagsGeneratorTable.getTableName();
      createClassHelperMethods();
   }// ClassHelperMethods() ENDS

   //***************************************************************************  
   // Public Methods  
   //***************************************************************************  
   /**  
    * <code>main</code>  
    * <p>  
    * This method will create the class helper methods.  
    * </p>  
    * @param <code>none</code>  
    */  
   //---------------------------------------------------------------------------
   public static void main(String args[]){
       SQLTagsGeneratorTable sqlTagsGeneratorTable=new SQLTagsGeneratorTable();
       ClassHelperMethods classHelperMethods=
       new ClassHelperMethods(sqlTagsGeneratorTable);
       System.out.println(classHelperMethods.getClassHelperMethods());
   }//main() ENDS

   /**  
    * <code>toString</code>  
    * <p>  
    * This method returns the class structure.
    * </p>  
    * @param  <code>none</code>  
    * @return  buff<code>String</code>class variable information.
    */  
   //---------------------------------------------------------------------------
   public String toString(){
       StringBuffer buff=new StringBuffer("\n*****ClassHelperMethods: ");
       buff.append("\tbuffer="+buffer.toString());
       buff.append("\theaderDefinition="+header);
       buff.append("\tsqlTagsGeneratorTable="+sqlTagsGeneratorTable);
       buff.append("\ttableName="+tableName);
       return buff.toString();
   }// toString()

   //***************************************************************************  
   // Friendly Methods  
   //***************************************************************************  
   /**  
    * <code>getClassHelperMethods</code>  
    * <p>  
    * This method returns the methods created. 
    * </p>  
    * @param <code>none</code>  
    */  
   //---------------------------------------------------------------------------
   String getClassHelperMethods(){
       return buffer.toString();
   }//getClassHelperMethods() ENDS


   //***************************************************************************  
   // Private Methods
   //***************************************************************************  
   /**  
    * <code>createClassSQLContract</code>  
    * <p>  
    * this method controls the creation of the helper methods.
    * </p>  
    * @param  <code>none</code>
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------
   private void createClassHelperMethods(){
       buffer=new StringBuffer();
       createInitialize();
       createSetBeanProperties();
       createSQLTagsColumns();
       // createInitializeColumnPropertiesHash();
       createInitializeHashtables();
       createInitializePrimaryKeyVector();
   }//createClassHelperMethods() ENDS

   /**  
    * <code>createInitialize</code>  
    * <p>  
    * This method creates the initializet method.
    * </p>  
    * @param  <code>none</code>
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------
   private void createInitialize(){
      Enumeration enum=sqlTagsGeneratorTable.getPrimaryKeys();
      StringBuffer primaryKeyList=new StringBuffer();
      StringBuffer ifString=new StringBuffer();
      StringBuffer columnValueBuffer=new StringBuffer();

      for(;enum.hasMoreElements();){
         String name=(String)enum.nextElement();
         primaryKeyList.append("String "+name+",");
         ifString.append(name+".equals(\"\")||");
         columnValueBuffer.append("setString(\""+name+"\","+name+");\n");
      }

      if(primaryKeyList.toString().trim().length()>0){
      buffer.append("   /**\n");
      buffer.append("    * <code>initialize</code>\n");
      buffer.append("    * <p>\n");
      buffer.append("    * This initialize method creates an instance ");
      buffer.append("of "+tableName.toLowerCase()+" based on the \n");
      buffer.append("    * primary key and the depth.\n");
      buffer.append("    * </p>\n");
      buffer.append("    * @param depth <code>int</code> The number of ");
      buffer.append("layers to be initialize.\n");
      buffer.append("    * @return none <code></code> \n");
      buffer.append("    */\n");
      buffer.append(spacer);
      buffer.append("   private void initialize("+primaryKeyList.toString());
      buffer.append("int depth){\n");
      buffer.append(spacer);
      buffer.append("      if("+ifString.toString()+"depth<0){\n");
      buffer.append("         new "+tableName+"();\n");
      buffer.append("         return;\n");
      buffer.append("      }\n\n");
      buffer.append("      "+columnValueBuffer.toString());
      buffer.append("      initialize(depth);\n");
      buffer.append("   }// initialize() ENDS\n\n");
      }
   }//createInitialize() ENDS

   /**  
    * <code>createSQLTagsColumns</code>  
    * <p>  
    * This method creates the initial createSQLTagsColumns.
    * </p>  
    * @param  <code>none</code>
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------
   private void createSQLTagsColumns(){
   //---------------------------------------------------------------------------
      buffer.append("   /**\n");
      buffer.append("    * <code>initSQLTagsColumns</code>\n");
      buffer.append("    * <p>\n");
      buffer.append("    * This method holds all the information about ");
      buffer.append("a column.\n");
      buffer.append("    * </p>\n");
      buffer.append("    * @param none <code>none</code> none.\n");
      buffer.append("    * @return none <code>none</code> none.\n");
      buffer.append("    */\n");
      buffer.append(spacer);
      buffer.append("   private void initSQLTagsColumns(){\n");
      buffer.append(spacer);

      Hashtable columnHash=sqlTagsGeneratorTable.getColumnHash();
      Enumeration enum=columnHash.keys();
      
      for(;enum.hasMoreElements();){
         String[] bindArray=null;
         Object key=enum.nextElement();
         SQLTagsGeneratorColumn column=(SQLTagsGeneratorColumn)
            columnHash.get(key);
         String name=column.getColumnName();
         String type=column.getDataType();
         String size=column.getSize()+"";
         int scale = column.getScale();
         int sqlType = column.getSqlType();
         
         String format = "";
         if(scale>0){
             StringBuffer sb = new StringBuffer("#,##0");
             sb.append(".");
             for(int j=0; j<scale;j++) {
                 sb.append("0");
             }
             format = sb.toString();
         }
         
         // String bindFormat="?";
         // String selectFormat=name;
         buffer.append("      getSQLTagsColumns().add( new SQLTagsColumn(\""+name+"\",\"\",\"0\",\""+type+"\","+Integer.toString(sqlType)+",\""+size+"\",\""+format+"\"));\n");
      }
      buffer.append("   }// initSQLTagsColumns() ENDS}\n\n");
   }//createInitializeColumnPropertiesHash() ENDS
   
   
   /**  
    * <code>createSetBeanProperties</code>  
    * <p>  
    * This method creates the setBeanProperties() method.  SetBeanProperties() 
    * is used to associate a tag with an existing JavaBean found within the 
    * servlet context using findAttribute().  Thus is a tag is used that has a
    * matching JavaBean in context they will be connected.
    * </p>  
    * @param  <code>bean</code>
    * @return  <code>void</code> 
    */  
   //---------------------------------------------------------------------------
   private void createSetBeanProperties(){
      buffer.append("   /**\n");
      buffer.append("    * <code>setBeanProperties(Object bean)</code>\n");
      buffer.append("    * <p>\n");
      buffer.append("    * This method overrides the default setBeanProperties ");
      buffer.append("from SQLTags.\n");
      buffer.append("    * </p>\n");
      buffer.append("    * @param bean <code>Object bean</code> .\n");
      buffer.append("    * @return void <code>void</code> \n");
      buffer.append("    */\n");
      buffer.append(spacer);
      buffer.append("   public void setBeanProperties(Object bean){\n");
      buffer.append(spacer);
      buffer.append("      if(bean==null) return;\n");
      buffer.append("      if(bean instanceof "+tableName+") {\n");
      buffer.append("         " + tableName + " t = (" + tableName + ") bean;\n" );
      // buffer.append("         setColumnPropertiesHash(t.getColumnPropertiesHash());\n");
      buffer.append("         setSQLTagsColumns(t.getSQLTagsColumns());\n");
      
      Enumeration enum=sqlTagsGeneratorTable.getImportedForeignKeys();
      while( enum.hasMoreElements() ) {
          
          // SQLTagsGeneratorForeignKey fk = (SQLTagsGeneratorForeignKey) enum.nextElement();
          String fkName = (String) enum.nextElement();
          buffer.append("         set" + fkName + "_PARENT( t.get" + fkName + "_PARENT());\n");
      }
      
      buffer.append("      }\n");
      buffer.append("   }// setBeanProperties() ENDS\n\n");
   }//createInitializeHashtables() ENDS
   

   /**  
    * <code>createInitializeHashtables</code>  
    * <p>  
    * This method creates the initializeHashtables() method
    * </p>  
    * @param  <code>none</code>
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------
   private void createInitializeHashtables(){
      buffer.append("   /**\n");
      buffer.append("    * <code>initializeHashTables</code>\n");
      buffer.append("    * <p>\n");
      buffer.append("    * This method initializes all the hashtables ");
      buffer.append("associated with this class.\n");
      buffer.append("    * </p>\n");
      buffer.append("    * @param none <code>none</code> none.\n");
      buffer.append("    * @return none <code>none</code> none\n");
      buffer.append("    */\n");
      buffer.append(spacer);
      buffer.append("   protected void initializeHashTables(){\n");
      buffer.append(spacer);
      buffer.append("      tableName = \""+tableName + "\";\n");
      buffer.append("      initSQLTagsColumns();\n");
      buffer.append("      initializePrimaryKeyVector();\n");
      buffer.append("   }// initializeHashTables() ENDS\n\n");
   }//createInitializeHashtables() ENDS



   /**  
    * <code>createInitializePrimaryKeyVector</code>  
    * <p>  
    * This method creates the initializeHashtables() method
    * </p>  
    * @author  Booker Northington II  
    * @version 1.0  
    * @since   1.3  
    * @param  <code>none</code>
    * @return  <code>none</code> 
    */  
   //---------------------------------------------------------------------------
   private void createInitializePrimaryKeyVector(){
   //---------------------------------------------------------------------------
      Enumeration enum=sqlTagsGeneratorTable.getPrimaryKeys();
      buffer.append("   /**\n");
      buffer.append("    * <code>initializePrimaryKeyVector</code>\n");
      buffer.append("    * <p>\n");
      buffer.append("    * This method initializes a vector which contains\n");
      buffer.append("    * the primary keys for this table.\n");
      buffer.append("    * </p>\n");
      buffer.append("    * @param none <code></code> \n");
      buffer.append("    * @return none <code>none</code> none.\n");
      buffer.append("    */\n");
      buffer.append(spacer);
      buffer.append("   private void initializePrimaryKeyVector(){\n");
      buffer.append(spacer);

      for(;enum.hasMoreElements();){
         String name=(String)enum.nextElement();
         buffer.append("      primaryKeyVector.add(\""+name+"\");\n");
      }

      buffer.append("   }// initializePrimaryKeyVector() ENDS\n\n");
   }//createInitializePrimaryKeyVector() ENDS

}// ClassHelperMethods ENDS
